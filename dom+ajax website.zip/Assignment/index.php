<?php
include('header.php');
?>

<head>
    <title>Home Page</title>
</head>
<body>
<?php
  //Security measure which restricts who can access the page
  if (isset($_SESSION['userID'])) {
  ?>
    <div class="w3-container w3-content w3-padding-64" style="max-width:700px" id="contact">
        <h2 class="w3-wide w3-center">Please select an option!</h2>
    </div>
    <div class="w3-wide w3-center">
        <button onclick="window.location.href='courseInfo.php';" class="w3-container w3-content w3-padding-64" style="max-width:700px">Course Info</button>
        <button onclick="window.location.href='topicInfo.php';" class="w3-container w3-content w3-padding-64" style="max-width:700px">Topic Info</button>
    </div>
</body>
</html>

<?php
//Error handler if the user isnt logged in
//Sends user back to login screen
} else {
    header("Location: login.php");
}

include('footer.html');
?>
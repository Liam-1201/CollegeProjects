<?php
// unsets all session variables which is necessary for security
// it prevents directly accessing pages once a user has logged out.
session_start();
unset($_SESSION["userID"]);
?>
<html>
<head>
<meta charset="utf-8">
<title>Logout</title>
<?php
echo '<script type="text/javascript">';
echo ' alert("Logout Successful")';  //not showing an alert box.
echo '</script>';
header("Location:login.php");
?>
</head>

<body>
</body>
</html>
<?php
include("header.php");
?>

<!-- javascript file courseInfo.js is used -->
<script src="courseInfo.js"></script>
<head>
    <title>Course Information</title>
</head>
<body>
<?php
  //Security measure which restricts who can access the page
  if (isset($_SESSION['userID'])) {
  ?>
<div class="w3-container w3-content w3-padding-64" style="max-width:700px" id="contact">
    <!-- Table for course info is made -->
  <!-- <p id="CourseInfo">
  </p> -->
  <div class="grid-item_topic">
  <h2>HND: Software Development Course Information</h2>
    <!-- button to load Software Development information -->
    <button onclick="loadXMLDoc('softDevUnits.xml')" id="SDBut">Course Information</button> 
  </div>
  <div class="grid-item_topic">
    <h2>HND: Networking Course Information</h2>
    <div id="Networking">
    </div>
    <!-- button to load Networking information -->
    <button onclick="loadXMLDoc('networkingUnits.xml')" id="NetBut">Course Information</button>
  </div>

  <div class="grid-item_topic">
  <h2>HND: Technical Support Course Information</h2>
    <div id="TechSupp">
    </div>
    <!-- button to load Tech Support information -->
    <button onclick="loadXMLDoc('techSuppUnits.xml')" id="TechBut">Course Information</button> 
  </div> 
</div>
</body>
</html>

<?php
//Error handler if the user isnt logged in
//Sends user back to login screen
} else {
  header("Location: login.php");
}

include('footer.html');
?>
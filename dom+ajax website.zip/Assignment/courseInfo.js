// Function for creating a new object for our request
function createXMLHttpRequestObject() {
    var ajaxObject = false; 
    if (window.XMLHttpRequest) { 
      ajaxObject = new XMLHttpRequest();
    } else if (window.ActiveXObject) { 
      try { 
        ajaxObject = new ActiveXObject("Msxml.XMLHTTP");
      } catch (e) { 
        try { 
          ajaxObject = new ActiveXObject("Microsoft.XMLHTTP");
        } catch (e) { 
          ajaxObject = false;
        }
      }
    }
    return ajaxObject;
  }

// Function for loading the desired file and opening it
function loadXMLDoc(file) {
    var isAjax = createXMLHttpRequestObject();
    // If the object is successfully created, then call the getCurrentState function
    if (isAjax) { 
      isAjax.onreadystatechange = function () { 
        getCurrentState(isAjax);
      };
      isAjax.open("GET", file, true); 
      isAjax.send(null); 
    }
  
}

// Function to get the current state of the file, and if the status is either 200 or 340, create the table
function getCurrentState(thisFile) { 
    if (thisFile.readyState == 4) { 
      if (thisFile.status == 200 || thisFile.status == 340) { 
        createTable(thisFile);
      }
    }
}

// Function for creating the table, will take the file and align it into appropriate columns
function createTable(thisFile) { 

    var i; 
    var xmlDoc = thisFile.responseXML;
    var x = xmlDoc.getElementsByTagName("unit");
    var para = document.createElement("p");
    para.setAttribute("id", "CourseInfo");
    var testDiv = document.getElementById("contact");

    for (i = 0; i < x.length; i++) { 
      var unitNumber = "";
      var title = "";
      var creditValue = "";
      unitNumber += "Unit Number: " +
      x[i].getElementsByTagName("unitnumber")[0].childNodes[0].nodeValue;
      para.append(unitNumber);
      para.append(document.createElement("br"));
      title += "Title: " +
      x[i].getElementsByTagName("title")[0].childNodes[0].nodeValue;
      para.append(title);
      para.append(document.createElement("br"));
      creditValue += "Credit Value: " +
      x[i].getElementsByTagName("creditvalue")[0].childNodes[0].nodeValue;
      para.append(creditValue);
      para.append(document.createElement("br"));
      para.append(document.createElement("br"));
    }

    if (document.body.contains(document.getElementById("CourseInfo"))) {
      testDiv.removeChild(testDiv.lastElementChild);
      testDiv.appendChild(para);
    } else {
      testDiv.appendChild(para);
    }
}
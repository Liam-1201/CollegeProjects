// Function to add or remove information within the MVC div
function changeMVCInfo(){

    var para = document.createElement("p");
    para.setAttribute("id", "moreMVCInfo");
    var txt = document.createTextNode("The Model just holds pure application data; no logic explaining how to show the data to a user is included. The View shows the user the models data. The view understands how to get to the data in the models, but it has no idea what that data represents or what the user can do with it. Between the view and the model is the Controller. It listens for events that are triggered by the view (or another external source) and responds appropriately. In most circumstances, the response is to invoke a model method. The result of this action is automatically reflected in the view because the view and the model are connected via a notification system.");
    var testdiv = document.getElementById("MVCInfo");
    var mvcDiv = document.getElementById("MVC");
    

    if (document.body.contains(document.getElementById("moreMVCInfo"))) {
        var moreBtn = document.createElement("button");
        moreBtn.id = "MVCAdditionalBut"
        moreBtn.innerHTML = "Read More";
        moreBtn.onclick = changeMVCInfo;
        testdiv.removeChild(testdiv.lastElementChild);
        mvcDiv.removeChild(mvcDiv.lastElementChild);
        mvcDiv.appendChild(moreBtn);
    } else {
        var lessBtn = document.createElement("button");
        lessBtn.innerHTML = "Read Less";
        lessBtn.onclick = changeMVCInfo;
        para.appendChild(txt);
        testdiv.appendChild(para);
        mvcDiv.removeChild(mvcDiv.lastElementChild);
        mvcDiv.appendChild(lessBtn);
    }
}

// Function to add or remove information within the Security div
function changeSecurityInfo(){
    var para = document.createElement("p");
    para.setAttribute("id", "moreSecurityInfo");
    var txt = document.createTextNode("Instead of string concatenation within the query, most occurrences of SQL injection can be avoided by utilising parameterized queries (also known as prepared statements). Any circumstance where untrusted input appears as data within the query, such as the WHERE clause and values in an INSERT or UPDATE statement, can benefit from parameterized queries. They can't be used to deal with untrustworthy input in other portions of the query, including table or column names or the ORDER BY clause. To deliver the desired behaviour, application functionality that places untrusted data into particular areas of the query will need to adopt a different approach, such as white-listing acceptable input values or using different logic.");
    var testdiv = document.getElementById("SecurityInfo");
    var secDiv = document.getElementById("Security");

    if (document.body.contains(document.getElementById("moreSecurityInfo"))) {
        var moreBtn = document.createElement("button");
        moreBtn.id = "SecurityAdditionalBut"
        moreBtn.innerHTML = "Read More";
        moreBtn.onclick = changeSecurityInfo;
        testdiv.removeChild(testdiv.lastElementChild);
        secDiv.removeChild(secDiv.lastElementChild);
        secDiv.appendChild(moreBtn);
    } else {
        var lessBtn = document.createElement("button");
        lessBtn.innerHTML = "Read Less";
        lessBtn.onclick = changeSecurityInfo;
        para.appendChild(txt);
        testdiv.appendChild(para);
        secDiv.removeChild(secDiv.lastElementChild);
        secDiv.appendChild(lessBtn);
    }
}

// Function to add or remove information within the Templating div
function changeTemplatingInfo(){
    var para = document.createElement("p");
    para.setAttribute("id", "moreTemplatingInfo");
    var txt = document.createTextNode("Static content is supported by web templates, which provide basic structure and style. Templates from content management systems, web application frameworks, and HTML editors can be used by developers.");
    var testdiv = document.getElementById("TemplateInfo");
    var tempDiv = document.getElementById("Templating");

    if (document.body.contains(document.getElementById("moreTemplatingInfo"))) {
        var moreBtn = document.createElement("button");
        moreBtn.id = "TemplateAdditionalBut"
        moreBtn.innerHTML = "Read More";
        moreBtn.onclick = changeTemplatingInfo;
        testdiv.removeChild(testdiv.lastElementChild);
        tempDiv.removeChild(tempDiv.lastElementChild);
        tempDiv.appendChild(moreBtn);
    } else {
        var lessBtn = document.createElement("button");
        lessBtn.innerHTML = "Read Less";
        lessBtn.onclick = changeTemplatingInfo;
        para.appendChild(txt);
        testdiv.appendChild(para);
        tempDiv.removeChild(tempDiv.lastElementChild);
        tempDiv.appendChild(lessBtn);
    }
}
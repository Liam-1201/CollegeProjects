<?php
session_start();
require('database.php');
?>

<!DOCTYPE html>
<html>
<head>
<title>Advanced Web</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel='stylesheet' href='styles.css'/>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Inconsolata">
</head>
<body>
<?php
  //Security measure which restricts who can access the page
  //If the user hasnt logged in, display error message
  if (isset($_SESSION['userID'])) {
  ?>
<!-- Links (sit on top) -->
<div class="w3-top">
  <div class="w3-row w3-padding w3-black">
    <div class="w3-col s3">
      <a href="index.php" class="w3-button w3-block w3-black">HOME</a>
    </div>
    <div class="w3-col s3">
      <a href="courseInfo.php" class="w3-button w3-block w3-black">COURSE INFORMATION</a>
    </div>
    <div class="w3-col s3">
      <a href="topicInfo.php" class="w3-button w3-block w3-black">TOPIC INFORMATION</a>
    </div>
    <div class="w3-col s3">
      <a href="logout.php" class="w3-button w3-block w3-black">LOGOUT</a>
    </div>
  </div>
</div>
<?php
  //Error handler if the user isnt logged in
  } else {
    echo "<h1>You must log in first!</h1>";
  }
  ?>
</body>
<!-- </html> -->
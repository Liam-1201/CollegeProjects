<?php
include("header.php");
?>


<script src="topicInfo.js"></script>
<head>
    <title>Topic Information</title>
</head>
<body>
<?php
  //Security measure which restricts who can access the page
  if (isset($_SESSION['userID'])) {
  ?>
<div class="w3-container w3-content w3-padding-64" style="max-width:700px" id="contact">
  <div class="grid-item_topic">
    <div id="MVC">
      <!-- MVC Information -->
      <h2>Model View Controller</h2>
      <p id="MVCInfo">
          A data model, presentation information, and control information are all included in the Model View Controller (MVC) design pattern. Each of them must be divided into separate items according to the pattern.
          MVC is an architectural pattern, not a full-fledged programme. MVC is primarily concerned with an application's user interface (UI) and interaction layer. You'll need a business logic layer, possibly a service layer, and a data access layer.
      </p>
      <!-- Button to display more information -->
      <button onclick="changeMVCInfo()" id="MVCAdditionalBut" >Read More</button>
    </div>
  </div>

  <div class="grid-item_topic">
    <div id="Templating">
      <!-- Templating Information -->
      <h2>Templating</h2>
      <p id="TemplateInfo">In web publishing, a web template system allows web designers and developers to work with web templates to automatically generate specific web pages, such as search results. This saves time by reusing static web page elements and defining dynamic elements based on web request parameters.</p>
      <!-- Button to display more information -->
      <button id="TemplateAdditionalBut" onclick="changeTemplatingInfo();">Read More</button>
    </div>
  </div>

  <div class="grid-item_topic">
    <div id="Security">
      <!-- Security Information -->
      <h2>Security</h2>
      <p id="SecurityInfo">SQL injection is a type of web security flaw that allows an attacker to interfere with a web application's database queries. It allows an attacker to see data that they wouldn't ordinarily be able to see. This could include data belonging to other users or any other information that the app has access to. In many circumstances, an attacker can alter or remove this data, causing the application's content or behaviour to be permanently altered.
      </p>
      <!-- Button to display more information -->
      <button onclick="changeSecurityInfo()" id="SecurityAdditionalBut">Read More</button>  
    </div>
  </div> 
</div>
</body>
</html>
<?php
    //Error handler if the user isnt logged in
    //Sends user back to login screen
    } else {
        header("Location: login.php");
    }
    include('footer.html');
?>
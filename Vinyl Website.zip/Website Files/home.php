<html>
<head>
    <link rel="stylesheet" type="text/css" href="home.css"/>
</head>
<body>
<div id="homePage">
<!-- HTML to display the home page to the user -->
    <div class="pageHeadline"> 
        <p id="pageTitle">Welcome to the vinyl store!
        <p id="pageMessage">Please either login or register to use this service!
    </div>
    
    <div class="pageContent">        
        <a href="login.php">
            <button type="button" class="buttonHolder">Login</button>
        </a>

       <div class="imageHolder">
       <img id="vinylImage" src="https://www.furnacemfg.com/wp-content/uploads/2018/12/black_vinyl.jpg" alt="Vinyl Disc">
       </div>
       <a href="register.php">
            <button type="button" class="buttonHolder">Register</button>
        </a>
    </div>
</div>
</body>
</html>
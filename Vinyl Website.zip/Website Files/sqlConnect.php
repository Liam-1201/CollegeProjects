<?php
    //define login info as constant so that they can't be changed later in the script

    define('USERNAME', 's1013498'); //your phpmyadmin username
    define('PWRD', 'rVTLHPsT'); //your phpmyadmin password
    define('HOSTNAME', 'localhost');
    define('DBNAME', 's1013498_vinyl'); //full name including s1013498_

    //database connection

    $dbConnect = @mysqli_connect(HOSTNAME, USERNAME, PWRD, DBNAME) OR die('Count not connect to db'. mysqli_connect_error());

?>
<?php
// unsets all session variables which is necessary for security
// it prevents directly accessing pages once a user has logged out.
session_start();
unset($_SESSION["username"]);
unset($_SESSION["user"]);
unset($_SESSION["userLevel"]);
unset($_SESSION["adminLevel"]);
?>

<html>

<head>
    <meta charset="utf-8">
    <title>Logout</title>
    <?php
    echo '<script type="text/javascript">';
    echo ' alert("Logout Successful")';
    echo '</script>';
    header("Location:home.php");
    ?>
</head>

<body>
</body>

</html>
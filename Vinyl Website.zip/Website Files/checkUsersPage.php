<?php
// start new session 
session_start();
// include the admin header file
include('adminHeader.php');
?>



<html>

<head>
    <link rel="stylesheet" type="text/css" href="checkUsersPage.css" />

</head>

<body style="background-color:lightsalmon;">
    <div id="checkUsersPage">

        <?php
        // User must be logged in as an admin user to access this page
        if (isset($_SESSION['adminLevel'])) {
        ?>
            <?php

            $pageTitle = "Users";
            // connection to the database must be established
            require('sqlConnect.php');

            // Query to get all users from the Users table
            $query = "SELECT * FROM Users ORDER BY userID";

            // Result to store all values from the query
            $result = @mysqli_query($dbConnect, $query);

            if ($result) // if the query runs successfully
            {

                echo '<p style="font-size:300%; text-decoration: underline;">User Information</p>';

                echo '<table width="90%">';
                echo '<thead>';
                echo '<tr><th align="left">user ID</th><th align="left">First Name</th><th align="left">Last Name</th><th align="left">Address</th><th align="left">Phone Number</th><th align="left">Email</th><th align="left">Username</th><th align="left">Password</th><th align="left">Account Type</th><th align="left">User Type</th></tr>';
                echo '</thead>';

                echo '<tbody>';
                // loop for displaying all users
                while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                    $accountType = $row['isRetailer'];
                    if ($accountType == "1") {
                        $type = "Personal";
                    } else if ($accountType == "2") {
                        $type = "Retailer";
                    }

                    $userType = $row['isAdmin'];
                    if ($userType == "0") {
                        $isAdmin = "User";
                    } else if ($userType == "1") {
                        $isAdmin = "Admin";
                    }

                    echo '<tr><td align="left">' . $row['userID'] . '</td><td align="left">' . $row['firstName'] . '</td><td align="left">' . $row['lastName'] . '</td><td align="left">' . $row['address1'] . '</td><td align="left">' . $row['phone'] . '</td><td align="left">' . $row['email'] . '</td><td align="left">' . $row['username'] . '</td><td align="left">' . $row['pass'] . '</td><td align="left">' . $type . '</td><td align="left">' . $isAdmin . '</td><td align="left"><a href="editUser.php?userID=' . $row['userID'] . '">Edit</a></td><td align="left"><a href="deleteUser.php?userID=' . $row['userID'] . '">Delete</a></td></tr>';
                }

                echo '</tbody>';
                echo '</table>';
                mysqli_free_result($result);
            } else {
                // Returns an error message if the query was unsuccessful
                echo '<p> error </p>';
                echo '<p>' . mysqli_error($dbConnect) . '</p>';
            }
            // Close the database
            mysqli_close($dbConnect);
            ?>
        <?php
        } else {
            // Sends the user to the home page if they arent an admin
            header("Location: home.php");
        }
        // includes the footer file
        include('footer.html');
        ?>
    </div>
    </form>
</body>

</html>
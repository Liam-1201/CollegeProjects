<?php
// if a submit request has been made
if (isset($_POST['submit'])){
    // setting variables from the $_FILES built in functions.
    $file = $_FILES['VinylImage'];
    $fileName = $_FILES['VinylImage']['name'];
    $fileTmpName = $_FILES['VinylImage']['tmp_name'];
    $fileSize = $_FILES['VinylImage']['size'];
    $fileError = $_FILES['VinylImage']['error'];
    $fileType = $_FILES['VinylImage']['type'];

    $fileExt = explode('.', $fileName);
    $fileActualExt = strtolower(end($fileExt));
    // image extensions that are allowed to be entered
    $allowed = array('jpg', 'jpeg', 'png', 'pdf');

    if (in_array($fileActualExt, $allowed)){
        if($fileError === 0){
            // Check if the file size is appropriate
            if($fileSize < 1000000) {
                // give the file name a unique id
                $fileNameNew = uniqid('', true).".".$fileActualExt;
                // file destination stores the file path of the file
                $fileDestination = 'uploadedImages/' .$fileNameNew;
                // transfer the file to the server
                move_uploaded_file($fileTmpName, $fileDestination);
                // save file destination in a session variable so that it can be used to stored into the database
                $_SESSION['var'] = $fileDestination;
            } 
        }
    }
}
?>
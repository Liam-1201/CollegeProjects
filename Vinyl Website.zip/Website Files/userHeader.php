<!DOCTYPE html>
<html>
<head>
<title>Vinyl Store</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel='stylesheet' href='styles.css'/>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Inconsolata">
</head>
<body style="background-color:burlywood">
<?php
  //Security measure which restricts who can access the page
  //If the user hasnt logged in, display error message
  if (isset($_SESSION['user'])) {
  ?>
<!-- Links (sit on top) -->
<div class="w3-top">
  <div class="w3-row w3-padding w3-black">
    <div class="w3-col s3">
      <a href="searchPage.php" class="w3-button w3-block w3-black">VINYL SEARCH</a>
    </div>
    <div class="w3-col s3">
      <a href="addPage.php" class="w3-button w3-block w3-black">ADD A VINYL</a>
    </div>
    <div class="w3-col s3">
      <a href="userListings.php" class="w3-button w3-block w3-black">EDIT A VINYL</a>
    </div>
    <div class="w3-col s3">
      <a href="logout.php" class="w3-button w3-block w3-black">LOGOUT</a>
    </div>
  </div>
</div>
<br>
<br>
<br>
<?php
  //Error handler if the user isnt logged in
  } else {
    header("Location: home.php");
  }
  include('footer.html');
  ?>
</body>

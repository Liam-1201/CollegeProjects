<?php
// Start new session
session_start();
// Database connection must be established
require('sqlConnect.php');
?>

<html>

<head>
    <link rel="stylesheet" type="text/css" href="addPage.css" />
</head>

<body>
    <div id="addPage">
        <div class="pageContent">
            <?php
            // User must be logged in to access this page
            if (isset($_SESSION['user'])) {
                // if the user is an admin then include the admin header
                if (isset($_SESSION['adminLevel'])) {
                    include('adminHeader.php');
                    // if the user is a standard user then include the user header
                } else if (isset($_SESSION['userLevel'])) {
                    include('userHeader.php');
                }
            ?>
                <?php
                // if GET vinylID is set and is numeric
                if (isset(($_GET['vinylID'])) && (is_numeric($_GET['vinylID']))) {
                    // then set it to the vinylID variable
                    $vinylID = $_GET['vinylID'];

                    // else if it is POST
                } elseif (isset(($_POST['vinylID'])) && (is_numeric($_POST['vinylID']))) {
                    // then set it to the vinylID variable
                    $vinylID = $_POST['vinylID'];
                } else {
                    // if no request is made then display an error
                    echo '<p>Error, this page should not be accessed directly</p>';
                    exit();
                }
                // if a post request is made then execute code
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    $errors = [];

                    // checks for artist, if no artist is found then display an error message to the user
                    if (empty($_POST['artist'])) {
                        $errors[] = "You need to enter the name of the artist";
                    } else {
                        $artist = mysqli_real_escape_string($dbConnect, $_POST['artist']);
                    }
                    // Same as above but for title.
                    if (empty($_POST['title'])) {
                        $errors[] = "You need to enter a title";
                    } else {
                        $title = mysqli_real_escape_string($dbConnect, $_POST['title']);
                    }
                    // Same as above but for genre.
                    if (empty($_POST['genre'])) {
                        $errors[] = "You need to enter a genre";
                    } else {
                        $genre = mysqli_real_escape_string($dbConnect, $_POST['genre']);
                    }
                    // Same as above but for price.
                    if (empty($_POST['price'])) {
                        $errors[] = "You need to enter a price";
                    } else {
                        $price = mysqli_real_escape_string($dbConnect, $_POST['price']);
                    }
                    // Same as above but for vinyl type.
                    if (empty($_POST['VinylType'])) {
                        $errors[] = "You need to add a vinyl type";
                    } else {
                        $vinylType = mysqli_real_escape_string($dbConnect, $_POST['VinylType']);
                    }

                    if (empty($errors)) // If no errors are found
                    {

                        if (is_uploaded_file($_FILES['VinylImage']['tmp_name'])) {
                            // setting variables from the $_FILES built in functions.
                            $file = $_FILES['VinylImage'];
                            $fileName = $_FILES['VinylImage']['name'];
                            $fileTmpName = $_FILES['VinylImage']['tmp_name'];

                            $fileExt = explode('.', $fileName);
                            $fileActualExt = strtolower(end($fileExt));

                            // give the file name a unique id
                            $fileNameNew = uniqid('', true) . "." . $fileActualExt;
                            // file destination stores the file path of the file
                            $fileDestination = 'uploadedImages/' . $fileNameNew;
                            // move uploaded file used to send the file to the server
                            move_uploaded_file($fileTmpName, $fileDestination);

                            // Query made to update the vinyl if an image is selected
                            $updateQuery = "UPDATE Vinyl SET artist='$artist', title='$title', genre='$genre', price='$price', images='$fileDestination', VinylType='$vinylType' WHERE vinylID='$vinylID'";
                        } else {
                            // Query made to update the vinyl if no image is selected, retaining the previously uploaded file for this vinyl
                            $updateQuery = "UPDATE Vinyl SET artist='$artist', title='$title', genre='$genre', price='$price', VinylType='$vinylType' WHERE vinylID='$vinylID'";
                        }
                        $result = @mysqli_query($dbConnect, $updateQuery);

                        if (mysqli_affected_rows($dbConnect) == 1) // if the query runs
                        {
                            // Print confirmation to user
                            echo '<p>Details updated</p>';
                        } else {
                            // print error to user
                            echo '<p>Error, did not update details</p>';
                            echo mysqli_error($dbConnect);
                        }
                    }
                }
                ?>
                <div class="pageHeadline">
                    <p id="pageTitle">Please fill out the required information!
                </div>
                <?php

                // Query to retrieve the information on the chosen vinyl
                $selectUser = "SELECT vinylID, artist, title, genre, price, images, VinylType FROM Vinyl WHERE vinylID=$vinylID";

                $result = @mysqli_query($dbConnect, $selectUser);

                if (mysqli_num_rows($result) == 1) // result found
                {

                    $row = mysqli_fetch_array($result, MYSQLI_NUM);
                    // HTML code to display the chosen vinyls current information into the fields
                    echo '
        <form action="editListing.php" method="POST" enctype="multipart/form-data">
            
                <p>Genre: <input type="text" name="genre" placeholder="Enter Genre" value="' . $row[3] . '">
                <p>Enter a title: <input type="text" name="title" placeholder="Enter Title" value="' . $row[2] . '">
                <p>Enter an artist: <input type="text" name="artist" placeholder="Enter Artist" value="' . $row[1] . '">
                <p>Enter an image: <input type="file" class="buttonHolder" name="VinylImage">
                <p>Insert price: <input type="text" name="price" placeholder="Enter Price" value="' . $row[4] . '">
                <div class="u-form-group u-form-radiobutton u-form-group-7">
                <div class="u-form-radio-button-wrapper">
                  <br>
                  <label class="u-label" for="radiobutton">Type Of Vinyl</label>
                  <br>
                  <input type="radio" name="VinylType" value="Album">
                  <label class="u-label" for="radiobutton">Album</label>
                  <br>
                  <input type="radio" name="VinylType" value="Single">
                  <label class="u-label" for="radiobutton">Single</label>
                  <br>
                  <input type="radio" name="VinylType" value="EP">
                  <label class="u-label" for="radiobutton">EP</label>
                  <br>
                </div>
              </div>
                    <input type="hidden" name="vinylID" value="' . $vinylID . '">
                <p><input type="submit" value="Edit Vinyl" name="submit" />
                <p><a href="deleteVinyl.php?vinylID=' . $vinylID . '">Delete</a>
                
            </div>

    </div>
    </form>
    ';
                } else {
                    // error message returned to the user
                    echo '<p>Unable to edit!</p>';
                }
                mysqli_close($dbConnect);
                ?>
            <?php
            } else {
                // sends the user back to the home page if they arent logged in
                header("Location: home.php");
            }
            // includes the footer file
            include('footer.html');
            ?>
</body>

</html>
<?php
// start a new session
session_start();
include('adminHeader.php');
?>

<?php
// User must be logged in as an admin user to access this page
if (isset($_SESSION['adminLevel'])) {
?>
    <html>

    <head>
        <link rel="stylesheet" type="text/css" href="addPage.css" />
    </head>

    <body>
        <div class="pageContent">

            <?php
            // set the page title 
            $pageTitle = 'Edit User ';

            // main header for the file
            echo '<h1>Edit User Record</h1>';

            // if the GET userID is set and it is numeric
            if (isset(($_GET['userID'])) && (is_numeric($_GET['userID']))) {
                // then set it to the userID variable
                $userID = $_GET['userID'];
                // else if it is POST
            } elseif (isset(($_POST['userID'])) && (is_numeric($_POST['userID']))) {
                // then set it to the userID variable
                $userID = $_POST['userID'];
            } else {
                // Error message displayed to the user
                echo '<p>Error, this page should not be accessed directly</p>';
                exit();
            }
            // connect to the data base
            require('sqlConnect.php');
            // if the request method is a POST
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                $errors = [];

                //check for a first name
                if (empty($_POST['firstName'])) {
                    $errors[] = "You need to enter a first name";
                } else {
                    // mysqli_real_escape_string escapes special characters in a string which may interfere with a sql query
                    $firstName = mysqli_real_escape_string($dbConnect, $_POST['firstName']);
                }
                // check for last name
                if (empty($_POST['lastName'])) {
                    $errors[] = "You need to enter a last name";
                } else {
                    $lastName = mysqli_real_escape_string($dbConnect, $_POST['lastName']);
                }
                // check for address
                if (empty($_POST['address1'])) {
                    $errors[] = "You need to enter an address";
                } else {
                    $address = mysqli_real_escape_string($dbConnect, $_POST['address1']);
                }
                // check for phone number
                if (empty($_POST['phone'])) {
                    $errors[] = "You need to enter a phone number";
                } else {
                    $phone = mysqli_real_escape_string($dbConnect, $_POST['phone']);
                }
                // check for email
                if (empty($_POST['email'])) {
                    $errors[] = "You need to enter an email address";
                } else {
                    $email = mysqli_real_escape_string($dbConnect, $_POST['email']);
                }
                // check for password
                if (empty($_POST['pass'])) {
                    $errors[] = "You need to enter a password";
                } else {
                    $pass = mysqli_real_escape_string($dbConnect, password_hash($_POST['pass'], PASSWORD_DEFAULT));
                }
                // check for account type
                if (empty($_POST['isRetailer'])) {
                    $errors[] = "You need to select user type";
                } else {
                    $TypeOfAccount = mysqli_real_escape_string($dbConnect, $_POST['isRetailer']);
                }

                if (empty($errors)) // if there are no errors reported
                {
                    // query to check if the email entered is the same as another registered user
                    $selectQuery = "SELECT email FROM Users  WHERE email='$email' AND userID !='$userID'";

                    $result = @mysqli_query($dbConnect, $selectQuery);
                    if (mysqli_num_rows($result) == 0) {
                        $updateQuery = "UPDATE Users SET firstName='$firstName', lastName='$lastName', address1='$address', phone='$phone', email='$email', pass='$pass', isRetailer='$TypeOfAccount' WHERE userID='$userID'";
                        $result = @mysqli_query($dbConnect, $updateQuery);

                        if (mysqli_affected_rows($dbConnect) == 1) // if query ran okay
                        {
                            // Confirmation is displayed to the user
                            echo '<p>Details updated</p>';
                        } else {
                            // error message is displayed to the user
                            echo '<p>Error, did not update details</p>';
                            echo mysqli_error($dbConnect);
                        }
                    } else {
                        // display error message if the email is already in use
                        echo '<p>This email is already in use</p>';
                    }
                } else {
                    // displays all the errors found
                    echo "<p>The following errors occurred:";
                    foreach ($errors as $message) {
                        echo "$message<br>";
                    }
                    echo "</p>";
                }
            }

            // Query to retrieve the fields for that user from the Users table in the database
            $selectUser = "SELECT * FROM Users WHERE userID=$userID";

            $result = @mysqli_query($dbConnect, $selectUser);

            if (mysqli_num_rows($result) == 1) // if a result is found
            {
                $row = mysqli_fetch_array($result, MYSQLI_NUM);

                // HTML to display the information on the user with each field pre populated with the chosen users information
                echo '<form action="editUser.php" method="POST">
            <p>First Name: <input type="text" name="firstName" size="20" maxlength="25" value="' . $row[6] . '"></p>
            <p>Last Name: <input type="text" name="lastName" size="20" maxlength="25" value="' . $row[7] . '"></p>
            <p>Address: <input type="text" name="address1" size="50" maxlength="100" value="' . $row[5] . '"></p>
            <p>Phone Number: <input type="text" name="phone" size="20" maxlength="25" value="' . $row[4] . '"></p>
            <p>Email: <input type="text" name="email" size="50" maxlength="100" value="' . $row[3] . '"></p>
            <p>Username: <input type="text" name="pass" size="30" maxlength="50" value="' . $row[1] . '"></p>
            <p>Password: <input type="text" name="pass" size="30" maxlength="50" value="' . $row[2] . '"></p>
            <p>Type Of User: <input type="radio" id="personal" name="isRetailer" value="1">Personal Account  <input type="radio" id="retail" name="isRetailer" value="2">Retail Account</p>
            
            <p><input type="hidden" name="userID" value="' . $userID . '">
            
            <input type="submit" name="submit" value="Update User"></p></form>';
            } else {
                // error message is displayed to the user
                echo '<p>There has been an error</p>';
            }


            mysqli_close($dbConnect);
            ?>

        </div>
    </body>
<?php
} else {
    // sends the user to the home page if they arent logged in
    header("Location: home.php");
}
// footer file is included
include('footer.html');
?>
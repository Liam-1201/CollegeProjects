<?php
// start new session
session_start();
?>
<?php
// User must be logged in to access this page
if (isset($_SESSION['user'])) {
    if (isset($_SESSION['adminLevel'])) {
        // Include the admin header if the user is an admin
        include('adminHeader.php');
    } else if (isset($_SESSION['userLevel'])) {
        // Include the user header if the user is a standard user
        include('userHeader.php');
    }
?>

    <html>

    <head>
        <link rel="stylesheet" type="text/css" href="addPage.css" />
    </head>

    <body>
        <div class="pageContent">

            <?php
            $pageTitle = "Delete Vinyl";

            echo '<h1>Delete a Vinyl</h1>';
            // if the GET vinylID is set and it is numeric
            if (isset(($_GET['vinylID'])) && (is_numeric($_GET['vinylID']))) {
                // then set it to the vinylID variable
                $vinylID = $_GET['vinylID'];
                // else if it is POST  
            } elseif (isset(($_POST['vinylID'])) && (is_numeric($_POST['vinylID']))) {
                // then set it to the vinylID variable
                $vinylID = $_POST['vinylID'];
            } else {
                // Error message if user attempts to view this page without selecting a vinyl to delete
                echo '<p>Error, this page should not be accessed directly</p>';
                exit();
            }
            // connect to database 
            require('sqlConnect.php');
            // if the request method is a POST
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                if ($_POST['accepted'] == 'yes') {
                    // Perform the query to delete the vinyl from the Vinyl table.
                    $deleteQuery = "DELETE FROM Vinyl WHERE vinylID=$vinylID LIMIT 1";
                    // result variable stores the result of the query into the database
                    $result = @mysqli_query($dbConnect, $deleteQuery);

                    if (mysqli_affected_rows($dbConnect) == 1) {
                        // if the deletion was successful.
                        echo '<p>Listing deleted</p>';
                    } else {
                        // Error message returned if unsuccessful
                        echo '<p>Something went wrong, Listing not deleted.</p>';
                        echo '<p>Error: ' . mysqli_error($dbConnect) . '</p>';
                    }
                } else {
                    echo '<p>Listing not deleted</p>';
                }
            } else {
                // Query to get the artist and title of the chosen vinyl
                $selectQuery = "SELECT artist, title FROM Vinyl WHERE vinylID=$vinylID";
                $result = @mysqli_query($dbConnect, $selectQuery);

                // if the query was successful then ask user if they wish to delete the vinyl
                if (mysqli_num_rows($result) == 1) {
                    $row = mysqli_fetch_array($result, MYSQLI_NUM);

                    echo "<h3>Name: $row[0] </h3>";
                    echo '<p>Are you sure you want to delete this Vinyl?</p>';

                    echo '<form action="deleteVinyl.php" method="POST">
            <input type="radio" name="accepted" value="yes"> Yes
            <input type="radio" name="accepted" value="no"> No
            <input type="Submit" name="Submit" value="Submit"> 
            <input type="hidden" name="vinylID" value=" ' . $vinylID . '"> 
            </form>';
                } else {
                    echo '<p>Error - there is nothing to delete</p>';
                }
            }
            //  closes the database
            mysqli_close($dbConnect);
            ?>
        </div>
    </body>
<?php
} else {
    // Sends the user to the home page if they arent logged in
    header("Location: home.php");
}
// includes the footer file into the page
include('footer.html');
?>
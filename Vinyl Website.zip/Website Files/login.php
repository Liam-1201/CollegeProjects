<?php
// session is made
session_start();
// Database connection is established
require('sqlConnect.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $errors = [];
    // Check if user has entered an ID
    if (empty($_POST['username'])) {
        $errors[] = "Unknown username!";
    } else {
        $username = mysqli_real_escape_string($dbConnect, $_POST['username']);
    }

    if (empty($_POST['pass'])) {
        $errors[] = "Please enter a password!";
    } else {
        $password = mysqli_real_escape_string($dbConnect, $_POST['pass']);
    }
    // Prepared statements are made
    if (empty($errors)) {
        $stat = $dbConnect->prepare("SELECT username, pass, userID, isAdmin FROM Users WHERE username = ?");

        if ($stat) {
            $stat->bind_param('s', $username);

            $stat->execute();

            $stat->bind_result($username, $hash, $userID, $isAdmin);

            $stat->store_result();

            $stat->fetch();
            // verifies users credentials and logs in if true
            if (password_verify($password, $hash) && $isAdmin == 0) {
                $_SESSION['username'] = $username;
                $_SESSION['user'] = $userID;
                $_SESSION['userLevel'] = $isAdmin;
                header("Location: userMenu.php");
                die;
            } else if (password_verify($password, $hash) && $isAdmin == 1) {
                $_SESSION['username'] = $username;
                $_SESSION['user'] = $userID;
                $_SESSION['adminLevel'] = $isAdmin;
                header("Location: adminMenu.php");
                die;
            } else {
?>
                <meta name="viewport" content="width=device-width, initial-scale=1">
                <div class="alert">
                    <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span>
                    <strong>Invalid Login!</strong> Please try again!
                </div>
<?php
            }
        }
    }

    $stat->close();
    $dbConnect->close();
}

?>
<!DOCTYPE html>
<html>

<head>
    <title>Music Online</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel='stylesheet' href='styles.css' />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Inconsolata">
</head>

<body>
    <div class="w3-container w3-content w3-padding-64" style="max-width:700px" id="contact">
        <h2 class="w3-wide w3-center">Sign In</h2>
        <p class="w3-opacity w3-center"><i>Fill in form below</i></p>
        <div class="w3-row w3-padding-32" style="margin:20px -16px 8px 225px">
            <div class="w3-col m6">
                <form action="login.php" method="POST">
                    <div class="w3-row-padding" style="margin:0 -16px 8px -16px">
                        <p><input class="w3-input w3-padding-16 w3-border" type="text" placeholder="Username" required name="username"></p>
                        <p><input class="w3-input w3-padding-16 w3-border" type="password" placeholder="Password" required name="pass"></p>
                        <p><button class="w3-button w3-black" type="submit">LOGIN</button></p>
                </form>
            </div>
        </div>
</body>

</html>
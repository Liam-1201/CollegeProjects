<?php
// start new session 
session_start();
// include the admin header file
include('adminHeader.php');
?>

<html>

<head>
    <link rel="stylesheet" type="text/css" href="adminMenu.css" />
</head>

<body>
    <?php
    // User must be logged in as an admin user to access this page
    if (isset($_SESSION['adminLevel'])) {
    ?>
        <!-- HTML for the admin page -->
        <div id="adminMenuPage">

            <div class="pageHeadline">
                <p id="pageTitle">Welcome to the vinyl store!
                <p id="pageMessage">Would you like to check vinyls on sale or
                    <br>check registered user accounts?
            </div>

            <div class="pageContent">
                <a href="adminVinyls.php">
                    <button type="button" class="buttonHolder">Check vinyls on sale</button>
                </a>
                <a href="checkUsersPage.php">
                    <button type="button" class="buttonHolder">Check user accounts</button>
                </a>
            </div>
        </div>


    <?php
        // Send the user back to the home page if they arent an admin
    } else {
        header("Location: home.php");
    }
    // Include the header file and require the database
    require('sqlConnect.php');
    include('footer.html');
    ?>

</body>

</html>
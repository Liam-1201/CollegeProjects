<?php
// start new session 
session_start();
// include the admin header file
include('adminHeader.php');
?>
<?php
// User must be logged in as an admin user to access this page
if (isset($_SESSION['adminLevel'])) {
?>
<?php

    $pageTitle = "Vinyls";
    // Connection to the database must be established
    require('sqlConnect.php');

    // Query to retrieve all listings from the vinyl table
    $query = "SELECT * FROM Vinyl";

    // Result to store all values from the query
    $result = @mysqli_query($dbConnect, $query);

    if ($result) // if the query runs successfully
    {
        echo '<p style="font-size:300%;text-decoration: underline;">Vinyl Information</p>';
        echo '<table width="90%">';
        echo '<thead>';
        echo '<tr><th align="left">Vinyl ID</th><th align="left">Artist</th><th align="left">Title</th><th align="left">Genre</th><th align="left">Price</th><th align="left">Vinyl Image</th><th align="left">Vinyl Type</th><th align="left">userID</th></tr>';
        echo '</thead>';

        echo '<tbody>';
        // loop for displaying all the vinyls
        while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {

            echo '<tr><td align="left">' . $row['vinylID'] . '</td><td align="left">' . $row['artist'] . '</td><td align="left">' . $row['title'] . '</td><td align="left">' . $row['genre'] . '</td><td align="left">' . "£" . $row['price'] . '</td><td align="left">' . '<img src="' . $row['images'] . '" style="width:50px;height:50px;">' . '</td><td align="left">' . $row['VinylType'] . '</td><td align="left">' . $row['userID'] . '</td><td align="left"><a href="editListing.php?vinylID=' . $row['vinylID'] . '">Edit</a></td><td align="left"><a href="deleteVinyl.php?vinylID=' . $row['vinylID'] . '">Delete</a></td></tr>';
        }


        echo '</tbody>';
        echo '</table>';
        mysqli_free_result($result);
        echo '<br>';
        echo '<br>';
        echo '<br>';
        echo '<br>';
    } else {
        // Returns an error message if the query was unsuccessful
        echo '<p> error </p>';
        echo '<p>' . mysqli_error($dbConnect) . '</p>';
    }

    // Close the database
    mysqli_close($dbConnect);
?>
<?php
    // Sends the user to the home page if they arent an admin
} else {
    header("Location: home.php");
}
// includes the footer file
include('footer.html');
?>
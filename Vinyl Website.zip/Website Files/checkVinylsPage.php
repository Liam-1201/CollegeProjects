<?php
// start new session
session_start();
// database connection must be established
require('sqlConnect.php');
// include the user header file
include('userHeader.php');
?>

<html>

<head>
  <link rel="stylesheet" type="text/css" href="checkVinylsPage.css" />

</head>

<body>
  <div class="pageContent">
    <?php
    // User must be logged in to access this page
    if (isset($_SESSION['user'])) {
    ?>
      <?php
      // if the GET vinylID is set and it is numeric
      if (isset(($_GET['vinylID'])) && (is_numeric($_GET['vinylID']))) {
        // then set it to the vinylID variable
        $vinylID = $_GET['vinylID'];
        // else if it is POST rather than a GET method 
      } elseif (isset(($_POST['vinylID'])) && (is_numeric($_POST['vinylID']))) {
        $vinylID = $_POST['vinylID'];
      } else // return an error message to the user
      {
        echo '<p>Error, this page should not be accessed directly</p>';
        exit();
      }

      //get vinyl info from the Vinyl table
      $selectUser = "SELECT vinylID, artist, title, genre, price, images, VinylType FROM Vinyl WHERE vinylID=$vinylID";

      $result = @mysqli_query($dbConnect, $selectUser);

      if (mysqli_num_rows($result) == 1) // if the result is found
      {
        $row = mysqli_fetch_array($result, MYSQLI_NUM);
        // Vinyl is displayed
        echo '<img id="vinylImage" src="' . $row[5] . '" alt="Product Image" style="height:200px; width:200px">
                <p> Artist: ' . $row[1] . '</p>
                <p> Title: ' . $row[2] . '</p>
                <p> Genre: ' . $row[3] . '</p>
                <p>Price: £ ' . $row[4] . '</p>
                <p>Vinyl Type: ' . $row[6] . '</p>
              </div>';
      } else {
        // return an error message to the user
        echo '<p>There has been an error</p>';
      }
      mysqli_close($dbConnect);
      ?>
      </form>
    <?php
    } else {
      // Send the user back to the home page if they arent an admin
      header("Location: home.php");
    }
    // Include the footer page into the file
    include('footer.html');
    ?>
</body>

</html>
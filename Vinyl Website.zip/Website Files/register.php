<!DOCTYPE html>
<html style="font-size: 16px;">

<head>

</head>

<body class="u-body u-xl-mode">

    <?php
    // Establish connection to the database
    require('sqlConnect.php');

    // Check that a POST request has been made
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $errors = [];


        //check for a username
        if (empty($_POST['username'])) {
            $errors[] = "You need to a enter a username!";
        } else {
            $username = mysqli_real_escape_string($dbConnect, $_POST['username']);
        }
        //check for a password
        if (empty($_POST['password'])) {
            $errors[] = "You need to create a password";
        } else {
            // password is hashed when being saved
            $password = mysqli_real_escape_string($dbConnect, password_hash($_POST['password'], PASSWORD_DEFAULT));
        }
        //check for a phone number
        if (empty($_POST['phoneNumber'])) {
            $errors[] = "You need to enter a valid phone number!";
        } else {
            $phone = mysqli_real_escape_string($dbConnect, $_POST['phoneNumber']);
        }
        //check for a first name
        if (empty($_POST['firstName'])) {
            $errors[] = "You need to enter a first name!";
        } else {
            $firstName = mysqli_real_escape_string($dbConnect, $_POST['firstName']);
        }
        //check for a last name
        if (empty($_POST['lastName'])) {
            $errors[] = "You need to enter a last name!";
        } else {
            $lastName = mysqli_real_escape_string($dbConnect, $_POST['lastName']);
        }
        //check for an address
        if (empty($_POST['address'])) {
            $errors[] = "You need to enter an address!";
        } else {
            $address = mysqli_real_escape_string($dbConnect, $_POST['address']);
        }
        //check for an email
        if (empty($_POST['email'])) {
            $errors[] = "You need to enter an email!";
        } else {
            $email = mysqli_real_escape_string($dbConnect, $_POST['email']);
        }
        // check for account type
        if (empty($_POST['isRetailer'])) {
            $errors[] = "You need to select user type";
        } else {
            $TypeOfAccount = mysqli_real_escape_string($dbConnect, $_POST['isRetailer']);
        }
        if (empty($errors)) // if there are no errors 
        {

            // query to insert new user into the database in the Users table
            $userInsertQuery = "INSERT INTO Users (username, pass, email, phone, address1, firstName, lastName, isRetailer, isAdmin) VALUES ('$username', '$password', '$email', '$phone', '$address', '$firstName', '$lastName', $TypeOfAccount, 1)";

            $result = @mysqli_query($dbConnect, $userInsertQuery);
            
            // if the query was successful
            if ($result) {
                // Send user to the login screen
                echo '<h1>Success</h1>';
                header('Location: login.php');
            } else {
                // Display error message to the user
                echo '<h1>Failed</h1>';
                echo mysqli_error($dbConnect);
            }
            // close the database
            mysqli_close($dbConnect);
        } else {
            // Display each error to the user
            echo "<p>The following errors occurred:";
            foreach ($errors as $message) {
                echo "$message<br>";
            }
            echo "</p>";
        }
    }
    ?>

<head>
    <link rel="stylesheet" type="text/css" href="register.css"/>
</head>
<body>
    <!-- HTML for displaying the page and sending the POST request -->
<div id="registerPage">

    <div class="pageHeadline"> 
        <p id="pageTitle">Welcome to the vinyl store!
        <p id="pageMessage">Please enter the details you would like to register with!
    </div>
    
    <form action="register.php" method="POST">
    <div class="pageContent">
        <p>
        First Name: <input type="text" name="firstName" placeholder="First Name" value="<?php if (isset($_POST['firstName'])) echo $_POST['firstName']; ?>">
        Address: <input type="text" name="address" placeholder="Address" value="<?php if (isset($_POST['address'])) echo $_POST['address']; ?>">
        <p>Last Name: <input type="text" name="lastName" placeholder="Last Name" value="<?php if (isset($_POST['lastName'])) echo $_POST['lastName']; ?>">
        Phone: <input type="text" name="phoneNumber" placeholder="Phone Number" value="<?php if (isset($_POST['phoneNumber'])) echo $_POST['phoneNumber']; ?>">
        <p>Username: <input type="text" name="username" placeholder="Username" value="<?php if (isset($_POST['username'])) echo $_POST['username']; ?>">
        Password: <input type="password" name="password" placeholder="Password" value="<?php if (isset($_POST['password'])) echo $_POST['password']; ?>">   
        <p>Email: <input type="text" name="email" placeholder="Email" value="<?php if (isset($_POST['email'])) echo $_POST['email']; ?>">
        <p>Type Of User: <input type="radio" id="personal" name="isRetailer" value="1">Personal Account  <input type="radio" id="retail" name="isRetailer" value="2">Retail Account</p>
        <p>      
        <a href="userMenu.php">
            <input type="submit" value="Submit" name="submit">
        </a>
    </div>
</div>
</form>
</body>
</html>
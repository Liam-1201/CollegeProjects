<?php
//Starts a php session on the page. This allows me to use session variables from other pages.
session_start();
include('userHeader.php');
?>

<html>

<head>
  <link rel="stylesheet" type="text/css" href="addPage.css" />
</head>

<body>
  <div id="addPage">

    <?php
    // User must be logged in to access this page
    if (isset($_SESSION['user'])) {
    ?>

      <?php
      // requires the database file and include the image upload file.
      require('sqlConnect.php');
      include('imageUpload.php');

      // if a post is made from the form then execute this code inside.
      if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $errors = [];

        // checks for an artist, if the artist field is empty then return an error message
        if (empty($_POST['Artist'])) {
          $errors[] = "You need to enter the name of the artist";
        } else {
          $Artist = mysqli_real_escape_string($dbConnect, $_POST['Artist']);
        }
        // Same as above but for title.
        if (empty($_POST['Title'])) {
          $errors[] = "You need to enter a title";
        } else {
          $Title = mysqli_real_escape_string($dbConnect, $_POST['Title']);
        }
        // Same as above but for genre.
        if (empty($_POST['Genre'])) {
          $errors[] = "You need to enter a genre";
        } else {
          $Genre = mysqli_real_escape_string($dbConnect, $_POST['Genre']);
        }
        // Same as above but for price.
        if (empty($_POST['Price'])) {
          $errors[] = "You need to enter a price";
        } else {
          $Price = mysqli_real_escape_string($dbConnect, $_POST['Price']);
        }
        // Same as above but for vinyl type.
        if (empty($_POST['VinylType'])) {
          $errors[] = "You need to add a vinyl type";
        } else {
          $VinylType = mysqli_real_escape_string($dbConnect, $_POST['VinylType']);
        }
        // variable is created to retrieve the file path from imageUploader.php then passed through images column on database.
        $path = $_SESSION['var'];
        // variable is created so that the userID can be saved in the vinyl
        $user = $_SESSION['user'];

        if (empty($_POST['VinylImage'])) {
          $VinylImage = $path;
        } else {
          $errors[] = "You need to add an image";
        }

        if (empty($errors)) // if there are no errors, execute code
        {

          // sql query that is inserting all data into the vinyl table
          $userInsertQuery = "INSERT INTO Vinyl (title, price, genre, VinylType, artist, images, userID) VALUES ('$Title', '$Price', '$Genre', '$VinylType', '$Artist', '$VinylImage', $user)";
          // connects to the database and inserts the query
          $result = @mysqli_query($dbConnect, $userInsertQuery);
          // if the result was successful
          if ($result) {
            // Take the user to the userMenu page
            header("Location: userMenu.php");
          } else {
            // Alert the user that their request has failed
            echo '<h1>Failed</h1>';
            echo mysqli_error($dbConnect);
          }
          // close connection to the database
          mysqli_close($dbConnect);
        } else { // if errors were reported.
          echo "<p>The following errors occurred:";
          foreach ($errors as $message) {
            echo "$message<br>";
          }
          echo "</p>";
        }
      }
      ?>
      <div class="pageHeadline">
        <p id="pageTitle">Please fill out the required information!
      </div>

      <!-- Section for the form to submit the vinyl -->
      <form action="addPage.php" method="POST" enctype="multipart/form-data">
        <div class="pageContent">
          <p>Genre: <input type="text" name="Genre" placeholder="Enter Genre" value="<?php if (isset($_POST['Genre'])) echo $_POST['Genre']; ?>">
          <p>Enter a title: <input type="text" name="Title" placeholder="Enter Title" value="<?php if (isset($_POST['Title'])) echo $_POST['Title']; ?>">
          <p>Enter an artist: <input type="text" name="Artist" placeholder="Enter Artist" value="<?php if (isset($_POST['Artist'])) echo $_POST['Artist']; ?>">
          <p>Enter an image: <input type="file" class="buttonHolder" name="VinylImage">
          <p>Insert price: <input type="text" name="Price" placeholder="Enter Price" value="<?php if (isset($_POST['Price'])) echo $_POST['Price']; ?>">
          <div>
            <div>
              <br>
              <label for="radiobutton">Type Of Vinyl</label>
              <br>
              <input type="radio" name="VinylType" value="Album" <?php if (isset($_POST['VinylType'])) echo $_POST['VinylType']; ?>>
              <label for="radiobutton">Album</label>
              <br>
              <input type="radio" name="VinylType" value="Single" <?php if (isset($_POST['VinylType'])) echo $_POST['VinylType']; ?>>
              <label for="radiobutton">Single</label>
              <br>
              <input type="radio" name="VinylType" value="EP" <?php if (isset($_POST['VinylType'])) echo $_POST['VinylType']; ?>>
              <label for="radiobutton">EP</label>
              <br>
            </div>
          </div>
          <p><input type="submit" value="Submit Sale" name="submit" />
        </div>

        <div class="logoutButton">
          <a href="home.php">
            <button type="button" class="logoutButtonSize">Logout</button>
          </a>
        </div>

  </div>
  </form>
<?php
      // Send the user back to the home page if they arent logged in
    } else {
      header("Location: home.php");
    }
    // Include footer to the page
    include('footer.html');
?>
</body>

</html>
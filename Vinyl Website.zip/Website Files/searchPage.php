<?php
// starts a new session
session_start();
// Database connection is established
require('sqlConnect.php');
// User header file is included
include('userHeader.php');
?>

<html>

<head>
  <link rel="stylesheet" type="text/css" href="searchPage.css" />
</head>

<body style="background-color:burlywood">
  <?php
  // User must be logged in to access this page
  if (isset($_SESSION['user'])) {
  ?>
    <div id="searchPage">
      <div class="filters">
        <form action="results.php" method="POST" style="text-align: center; height: 90px;">
          <br>
          <br>
          <input type="search" style="font-size: 16px; color: black;" float="center" name="search">
          <button class="u-search-button u-custom-font u-font-playfair-display u-grey-50 u-hover-grey-30 u-text-custom-color-1 u-text-hover-grey-90" type="submit">Search</button>
        </form>
      </div>
      <?php
      // Query to find all vinyls
      $query = "SELECT DISTINCT images, artist, title, vinylID FROM Vinyl ORDER BY RAND()";
      // Contacts the database and sends the query
      $result = @mysqli_query($dbConnect, $query);
      // if the query contains results.
      if ($result) {
        // Populate the page with the results found
        while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
          echo '<div id="tour">
                <div class="w3-container w3-content w3-padding-64" style="max-width:300px">
                <div class="w3-row-padding w3-padding-32" style="margin:0 -16px">
                <div class="w3-third w3-margin-bottom">
                <div class="w3-row-padding w3-padding-32" style="margin:0 -16px">
        <div class="w3-third w3-margin-bottom">
          <img id="vinylImage" src="' . $row['images'] . ' ">
          <div class="w3-container">
          <p>' . $row['title'] . '</p>
            <a class="w3-button w3-black w3-margin-bottom" href="checkVinylsPage.php?vinylID=' . $row['vinylID'] . '">More Information</a>
          </div>
        </div>
        </div>
        </div>
        </div>
        </div>';
        }
        mysqli_free_result($result);
      } else {
        // Error message if there is an error
        echo '<p> error </p>';
        echo '<p>' . mysqli_error($dbConnect) . '</p>';
      }
      // close database
      mysqli_close($dbConnect);
      ?>
    </div>
  <?php
  } else {
    // return the user to the home page if they arent logged in
    header("Location: home.php");
  }
  // footer page is included
  include('footer.html');
  ?>
</body>

</html>
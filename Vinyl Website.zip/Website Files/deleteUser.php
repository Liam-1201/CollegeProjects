<?php
// start new session 
session_start();
// include the admin header file
include('adminHeader.php');
?>

<html>

<head>
    <link rel="stylesheet" type="text/css" href="addPage.css" />
</head>

<body>
    <div class="pageContent">
        <?php
        // User must be logged in as an admin user to access this page
        if (isset($_SESSION['adminLevel'])) {
        ?>
            <?php
            $pageTitle = "Delete User";

            echo '<h1>Delete a User</h1>';
            // if the GET userID is set and it is numeric
            if (isset(($_GET['userID'])) && (is_numeric($_GET['userID']))) {
                // then set it to the userID variable
                $userID = $_GET['userID'];
            }
            // else if it is POST 
            elseif (isset(($_POST['userID'])) && (is_numeric($_POST['userID']))) {
                // then set it to the userID variable
                $userID = $_POST['userID'];
            } else {
                // Error message displayed to the user
                echo '<p>Error, this page should not be accessed directly</p>';
                exit();
            }
            // database connection must be established
            require('sqlConnect.php');
            // if the request method is a POST
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                if ($_POST['accepted'] == 'yes') {
                    // Perform the query to delete the user from the database.
                    $deleteQuery = "DELETE FROM Users WHERE userID=$userID LIMIT 1";
                    // result variable stores the result of the query into the database
                    $result = @mysqli_query($dbConnect, $deleteQuery);
                    if (mysqli_affected_rows($dbConnect) == 1) {
                        // if the deletion was successful.
                        echo '<p>User deleted</p>';
                    } else {
                        // Error message returned to the user if not successful
                        echo '<p>Something went wrong, user not deleted.</p>';
                        echo '<p>Error: ' . mysqli_error($dbConnect) . '</p>';
                    }
                } else {
                    echo '<p>User not deleted</p>';
                }
            } else {
                // Query to return the first and last name of the chosen user
                $selectQuery = "SELECT firstName, lastName FROM Users WHERE userID=$userID";
                $result = @mysqli_query($dbConnect, $selectQuery);
                // if the query was successful then ask user if they want to delete that user
                if (mysqli_num_rows($result) == 1) {
                    $row = mysqli_fetch_array($result, MYSQLI_NUM);

                    echo "<h3>Name: $row[0] </h3>";
                    echo '<p>Are you sure you want to delete this user?</p>';

                    echo '<form action="deleteUser.php" method="POST">
            <input type="radio" name="accepted" value="yes"> Yes
            <input type="radio" name="accepted" value="no"> No
            <input type="Submit" name="Submit" value="Submit"> 
            <input type="hidden" name="userID" value=" ' . $userID . '"> 
            </form>';
                } else {
                    echo '<p>Error - there is nothing to delete</p>';
                }
            }
            //  closes the database
            mysqli_close($dbConnect);
            ?>

    </div>
</body>
<?php
        } else {
            // Send the user back to the home page if they arent an admin
            header("Location: home.php");
        }
        // Includes the footer file into the page
        include('footer.html');
?>
<?php
// starts a new session
session_start();
// Database connection is established
require('sqlConnect.php');
// user header is included
include('userHeader.php');
?>

<html>

<head>
    <link rel="stylesheet" type="text/css" href="userMenu.css" />
</head>

<body>
    <div id="userMenuPage">
        <?php
        // User must be logged in to access this page
        if (isset($_SESSION['user'])) {
        ?>
            <div class="pageHeadline">
                <p id="pageTitle">Welcome to the vinyl store!
                <p id="pageMessage">Would you like to search for a vinyl
                    <br>or update/add a vinyl for sale?
            </div>

            <div class="pageContent">
                <a href="searchPage.php">
                    <button type="button" class="buttonHolder">Search for a vinyl</button>
                </a>
                <a href="addPage.php">
                    <button type="button" class="buttonHolder">Add a vinyl for sale</button>
                </a>
                <a href="userListings.php">
                    <button type="button" class="buttonHolder">Edit a vinyl for sale</button>
                </a>
            </div>

    </div>


<?php
        } else {
            // user is sent to the home page if they arent logged in
            header("Location: home.php");
        }
        // footer is included
        include('footer.html');
?>

</body>

</html>
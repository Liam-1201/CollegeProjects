package helpers;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

/**
 * @author: Liam Irvine
 * The Class FileHelper.
 */
public class FileHelper {
	
	/** The file path. */
		private String filePath;
		
		/**
		 * Instantiates a new file helper.
		 *
		 * @param filePath the file path
		 */
		public FileHelper(String filePath) {
			this.filePath = filePath;
		}
		
		/**
		 * Save to file.
		 *
		 * @param <T> the generic type
		 * @param arrayList the array list
		 */
		public <T> void saveToFile(ArrayList<T> arrayList) {
			try {
				FileOutputStream file = new FileOutputStream(filePath);
				ObjectOutputStream out = new ObjectOutputStream(file);
				
				out.writeObject(arrayList);
				
				out.close();
				file.close();
				
			} catch(IOException e) {
				e.printStackTrace();
			}
		}
}

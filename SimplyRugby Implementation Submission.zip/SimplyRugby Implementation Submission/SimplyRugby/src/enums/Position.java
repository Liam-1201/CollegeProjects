package enums;


/**
 * @author: Liam Irvine
 * The Enum Position.
 */
public enum Position {
	
	/** The Full back. */
	FullBack, 
	/** The Wing. */
	Wing, 
	/** The Centre. */
	Centre, 
	/** The Fly half. */
	FlyHalf, 
	/** The Scrum half. */
	ScrumHalf, 
	/** The Hooker. */
	Hooker, 
	/** The Prop. */
	Prop, 
	/** The Second row. */
	SecondRow, 
	/** The Back row. */
	BackRow
}

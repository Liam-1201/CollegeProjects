package enums;

/**
 * @author: Liam Irvine
 * The Enum SquadCategory.
 */
public enum SquadCategory {
	
	/** The junior. */
	junior, 
	/** The senior. */
	senior
}

package models;

import java.io.Serializable;
import java.util.ArrayList;

import enums.SquadCategory;

/**
 * @author: Liam Irvine
 * The Class Squad.
 * Implements the Serializable interface.
 */
public class Squad implements Serializable{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	
	/** The squad name. */
	private String squadName;
	
	/** The player list. */
	private ArrayList<Player> playerList;
	
	/** The coach. */
	private Member coach;
	
	/** The squad category. */
	private SquadCategory squadCategory;
	
	/**
	 * Instantiates a new squad.
	 */
	public Squad(String squadName, ArrayList<Player> playerList, Member coach, SquadCategory squadCategory) {
		this.squadName = squadName;
		this.coach = coach;
		this.squadCategory = squadCategory;
		this.playerList = new ArrayList<Player>();
	}
	
	/**
	 * Gets the squad name.
	 *
	 * @return the squad name
	 */
	public String getSquadName() {
		return this.squadName;
	}
	
	/**
	 * Gets the player list.
	 *
	 * @return the player list
	 */
	public ArrayList<Player> getPlayerList() {
		return this.playerList;
	}
	
	/**
	 * Gets the coach.
	 *
	 * @return the coach
	 */
	public Member getCoach() {
		return this.coach;
	}
	
	/**
	 * Gets the squad category.
	 *
	 * @return the squad category
	 */
	public SquadCategory getSquadCategory() {
		return this.squadCategory;
	}
	
	/**
	 * Sets the squad name.
	 *
	 * @param squadName the new squad name
	 */
	public void setSquadName(String squadName) {
		this.squadName = squadName;
	}
	
	/**
	 * Sets the player list.
	 *
	 * @param playerList the new player list
	 */
	public void setPlayerList(ArrayList<Player> playerList) {
		this.playerList = playerList;
	}
	
	/**
	 * Sets the coach.
	 *
	 * @param coach the new coach
	 */
	public void setCoach(Member coach) {
		this.coach = coach;
	}
	
	/**
	 * Sets the squad category.
	 *
	 * @param squadCategory the new squad category
	 */
	public void setSquadCategory(SquadCategory squadCategory) {
		this.squadCategory = squadCategory;
	}
	
	/**
	 * Adds the player to list.
	 *
	 * @param newPlayer the new player
	 */
	public void addPlayerToList(Player newPlayer) {
		this.playerList.add(newPlayer);
	}
	
	/**
	 * Edits the player to list.
	 *
	 * @param i the i counter
	 * @param editPlayer the player to edit
	 */
	public void editPlayerToList(int i, Player editPlayer) {
		this.playerList.set(i, editPlayer);
	}
	
	/**
	 * Delete player from list.
	 *
	 * @param i the i counter
	 */
	public void deletePlayerFromList(int i) {
		this.playerList.remove(i);
	}
	
	/**
	 * To string.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return this.getSquadName();
	}
}

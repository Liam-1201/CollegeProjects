package models;

import java.io.Serializable;

/**
 * @author: Liam Irvine
 * The Class Skill.
 * Implements the Serializable interface.
 */
public class Skill implements Serializable{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	
	/** The skill name. */
	String skillName;
	
	/** The rating. */
	int rating;
	
	/**
	 * Instantiates a new skill.
	 */
	public Skill(String skillName, int rating) {
		this.skillName = skillName;
		this.rating = rating;
	}
	
	/**
	 * Gets the skill name.
	 *
	 * @return the skill name
	 */
	public String getSkillName() {
		return this.skillName;
	}
	
	/**
	 * Gets the rating.
	 *
	 * @return the rating
	 */
	public int getRating() {
		return this.rating;
	}
	
	
	/**
	 * Sets the skill name.
	 *
	 * @param skillName the new skill name
	 */
	public void setSkillName(String skillName) {
		this.skillName = skillName;
	}
	
	/**
	 * Sets the rating.
	 *
	 * @param rating the new rating
	 */
	public void setRating(int rating) {
		this.rating = rating;
	}
}

package models;

import java.time.LocalDate;
import java.util.ArrayList;

import enums.Position;
import enums.SquadCategory;

/**
 * @author: Liam Irvine
 * The Class JuniorPlayer.
 * Inherits from Player class.
 */
public class JuniorPlayer extends Player {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	
	/** The guardian 1. */
	private String guardian1;
	
	/** The relationship 1. */
	private String relationship1;
	
	/** The address 1. */
	private String address1;
	
	/** The guardian phone 1. */
	private String guardianPhone1;
	
	/** The guardian 2. */
	private String guardian2;
	
	/** The relationship 2. */
	private String relationship2;
	
	/** The address 2. */
	private String address2;
	
	/** The guardian phone 2. */
	private String guardianPhone2;
	
	/** The doctor address. */
	private String doctorAddress;
	
	/**
	 * Instantiates a new junior player.
	 */
	public JuniorPlayer(String firstname, String surname, String username, String password, boolean isAdmin,
			String postCode, String address, LocalDate dateOfBirth,
			String email, String phone, String SRUNumber, boolean coach, Squad squad, ArrayList<SkillCategory> skills,
			String nextOfKin, String NOKPhone, String doctor, String docPhone, String healthIssues, Position position, SquadCategory squadCat,
			String guardian1, String relationship1, String address1, String guardianPhone1,
			String guardian2, String relationship2, String address2, String guardianPhone2, String doctorAddress) {
		super(firstname, surname, null, null, false, postCode, address, dateOfBirth, email, phone, SRUNumber, 
				false, squad, skills, nextOfKin, NOKPhone, doctor, docPhone,
				healthIssues, position, squadCat);
		this.guardian1 = guardian1;
		this.relationship1 = relationship1;
		this.address1 = address1;
		this.guardianPhone1 = guardianPhone1;
		this.guardian2 = guardian2;
		this.relationship2 = relationship2;
		this.address2 = address2;
		this.guardianPhone2 = guardianPhone2;
		this.doctorAddress = doctorAddress;
	}
	
	/**
	 * Gets the guardian 1.
	 *
	 * @return the guardian 1
	 */
	public String getGuardian1() {
		return this.guardian1;
	}
	
	/**
	 * Gets the relationship 1.
	 *
	 * @return the relationship 1
	 */
	public String getRelationship1() {
		return this.relationship1;
	}
	
	/**
	 * Gets the address 1.
	 *
	 * @return the address 1
	 */
	public String getAddress1() {
		return this.address1;
	}
	
	/**
	 * Gets the guardian phone 1.
	 *
	 * @return the guardian phone 1
	 */
	public String getGuardianPhone1() {
		return this.guardianPhone1;
	}
	
	/**
	 * Gets the guardian 2.
	 *
	 * @return the guardian 2
	 */
	public String getGuardian2() {
		return this.guardian2;
	}
	
	/**
	 * Gets the relationship 2.
	 *
	 * @return the relationship 2
	 */
	public String getRelationship2() {
		return this.relationship2;
	}
	
	/**
	 * Gets the address 2.
	 *
	 * @return the address 2
	 */
	public String getAddress2() {
		return this.address2;
	}
	
	/**
	 * Gets the guardian phone 2.
	 *
	 * @return the guardian phone 2
	 */
	public String getGuardianPhone2() {
		return this.guardianPhone2;
	}
	
	/**
	 * Gets the doctor address.
	 *
	 * @return the doctor address
	 */
	public String getDoctorAddress() {
		return this.doctorAddress;
	}
	
	/**
	 * Sets the guardian 1.
	 *
	 * @param guardian1 the new guardian 1
	 */
	public void setGuardian1(String guardian1) {
		this.guardian1 = guardian1;
	}
	
	/**
	 * Sets the relationship 1.
	 *
	 * @param relationship1 the new relationship 1
	 */
	public void setRelationship1(String relationship1) {
		this.relationship1 = relationship1;
	}
	
	/**
	 * Sets the address 1.
	 *
	 * @param address1 the new address 1
	 */
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	
	/**
	 * Sets the guardian phone 1.
	 *
	 * @param guardianPhone1 the new guardian phone 1
	 */
	public void setGuardianPhone1(String guardianPhone1) {
		this.guardianPhone1 = guardianPhone1;
	}
	
	/**
	 * Sets the guardian 2.
	 *
	 * @param guardian2 the new guardian 2
	 */
	public void setGuardian2(String guardian2) {
		this.guardian2 = guardian2;
	}
	
	/**
	 * Sets the relationship 2.
	 *
	 * @param relationship2 the new relationship 2
	 */
	public void setRelationship2(String relationship2) {
		this.relationship2 = relationship2;
	}
	
	/**
	 * Sets the address 2.
	 *
	 * @param address2 the new address 2
	 */
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	
	/**
	 * Sets the guardian phone 2.
	 *
	 * @param guardianPhone2 the new guardian phone 2
	 */
	public void setGuardianPhone2(String guardianPhone2) {
		this.guardianPhone2 = guardianPhone2;
	}
	
	/**
	 * Sets the doctor address.
	 *
	 * @param doctorAddress the new doctor address
	 */
	public void setDoctorAddress(String doctorAddress) {
		this.doctorAddress = doctorAddress;
	}
}

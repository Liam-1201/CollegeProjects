package models;

import java.io.Serializable;
import java.time.LocalDate;


/**
 * @author: Liam Irvine
 * The Class Member.
 * Implements Serializable interface.
 */
public class Member implements Serializable{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	
	/** The firstname. */
	private String firstname;
	
	/** The surname. */
	private String surname;
	
	/** The username. */
	private String username;
	
	/** The password. */
	private String password;
	
	/** is admin check. */
	private boolean isAdmin;
	
	/** The address. */
	private String address;
	
	/** The post code. */
	private String postCode;
	
	/** The date of birth. */
	private LocalDate dateOfBirth;
	
	/** The email. */
	private String email;
	
	/** The phone. */
	private String phone;
	
	/** The SRU number. */
	private String SRUNumber;
	
	/** The coach. */
	private boolean coach;
	
	/** The squad. */
	private Squad squad;
	
	/**
	 * Instantiates a new member.
	 */
	public Member (String firstname, String surname, String username, String password, boolean isAdmin,
			String postCode, String address, LocalDate dateOfBirth,
			String email, String phone, String SRUNumber, boolean coach, Squad squad) {
		this.firstname = firstname;
		this.surname = surname;
		this.username = username;
		this.password = password;
		this.isAdmin = isAdmin;
		this.address = address;
		this.postCode = postCode;
		this.dateOfBirth = dateOfBirth;
		this.email = email;
		this.phone = phone;
		this.SRUNumber = SRUNumber;
		this.coach = coach;
		this.squad = squad;
	}
	
	/**
	 * Gets the firstname.
	 *
	 * @return the firstname
	 */
	public String getFirstname() {
		return this.firstname;
	}
	
	/**
	 * Gets the surname.
	 *
	 * @return the surname
	 */
	public String getSurname() {
		return this.surname;
	}
	
	/**
	 * Gets the username.
	 *
	 * @return the username
	 */
	public String getUsername() {
		return this.username;
	}
	
	/**
	 * Gets the password.
	 *
	 * @return the password
	 */
	public String getPassword() {
		return this.password;
	}
	
	/**
	 * Gets the checks if is admin.
	 *
	 * @return the checks if is admin
	 */
	public boolean getIsAdmin() {
		return this.isAdmin;
	}
	
	/**
	 * Gets the address.
	 *
	 * @return the address
	 */
	public String getAddress() {
		return this.address;
	}
	
	/**
	 * Gets the post code.
	 *
	 * @return the post code
	 */
	public String getPostCode() {
		return this.postCode;
	}
	
	/**
	 * Gets the date of birth.
	 *
	 * @return the date of birth
	 */
	public LocalDate getDateOfBirth() {
		return this.dateOfBirth;
	}
	
	/**
	 * Gets the email.
	 *
	 * @return the email
	 */
	public String getEmail() {
		return this.email;
	}
	
	/**
	 * Gets the phone.
	 *
	 * @return the phone
	 */
	public String getPhone() {
		return this.phone;
	}
	
	/**
	 * Gets the SRU number.
	 *
	 * @return the SRU number
	 */
	public String getSRUNumber() {
		return this.SRUNumber;
	}
	
	/**
	 * Gets the coach.
	 *
	 * @return the coach
	 */
	public boolean getCoach() {
		return this.coach;
	}
	
	/**
	 * Gets the squad.
	 *
	 * @return the squad
	 */
	public Squad getSquad() {
		return this.squad;
	}
	
	/**
	 * Sets the firstname.
	 *
	 * @param firstname the new firstname
	 */
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	
	/**
	 * Sets the surname.
	 *
	 * @param surname the new surname
	 */
	public void setSurname(String surname) {
		this.surname = surname;
	}
	
	/**
	 * Sets the username.
	 *
	 * @param username the new username
	 */
	public void setUsername(String username) {
		this.username = username;
	}
	
	/**
	 * Sets the password.
	 *
	 * @param password the new password
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	
	/**
	 * Sets the checks if is admin.
	 *
	 * @param isAdmin the new checks if is admin
	 */
	public void setIsAdmin(boolean isAdmin) {
		this.isAdmin = isAdmin;
	}
	
	/**
	 * Sets the address.
	 *
	 * @param address the new address
	 */
	public void setAddress(String address) {
		this.address = address;
	}
	
	/**
	 * Sets the post code.
	 *
	 * @param postCode the new post code
	 */
	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}
	
	/**
	 * Sets the date of birth.
	 *
	 * @param dateOfBirth the new date of birth
	 */
	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	
	/**
	 * Sets the email.
	 *
	 * @param email the new email
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	
	/**
	 * Sets the phone.
	 *
	 * @param phone the new phone
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	/**
	 * Sets the SRU number.
	 *
	 * @param SRUNumber the new SRU number
	 */
	public void setSRUNumber(String SRUNumber) {
		this.SRUNumber = SRUNumber;
	}
	
	/**
	 * Sets the coach.
	 *
	 * @param coach the new coach
	 */
	public void setCoach(boolean coach) {
		this.coach = coach;
	}
	
	/**
	 * Sets the squad.
	 *
	 * @param squad the new squad
	 */
	public void setSquad(Squad squad) {
		this.squad = squad;
	}
	
	/**
	 * To string.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return this.getFirstname() + " " + this.getSurname();
	}
}

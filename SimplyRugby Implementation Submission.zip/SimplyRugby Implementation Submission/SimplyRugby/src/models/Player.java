package models;

import java.time.LocalDate;
import java.util.ArrayList;

import enums.Position;
import enums.SquadCategory;

/**
 * @author: Liam Irvine
 * The Class Player.
 * Inherits from Member class.
 */
public class Player extends Member {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	
	/** The skills. */
	private ArrayList<SkillCategory> skills;
	
	/** The next of kin. */
	private String nextOfKin;
	
	/** The NOK phone. */
	private String NOKPhone;
	
	/** The doctor. */
	private String doctor;
	
	/** The doc phone. */
	private String docPhone;
	
	/** The health issues. */
	private String healthIssues;
	
	/** The position. */
	private Position position;
	
	/** The squad cat. */
	private SquadCategory squadCat;
	
	/**
	 * Instantiates a new player.
	 */
	public Player(String firstname, String surname, String username, String password, boolean isAdmin,
			String postCode, String address, LocalDate dateOfBirth, String email, 
			String phone, String SRUNumber, boolean coach, Squad squad,
			ArrayList<SkillCategory> skills, String nextOfKin, String NOKPhone,
			String doctor, String docPhone, String healthIssues, Position position, SquadCategory squadCat) {
		super(firstname, surname, null, null, false, postCode, address, dateOfBirth, email, phone, SRUNumber, false, squad);
		this.skills = new ArrayList<SkillCategory>();
		this.nextOfKin = nextOfKin;
		this.NOKPhone = NOKPhone;
		this.doctor = doctor;
		this.docPhone = docPhone;
		this.healthIssues = healthIssues;
		this.position = position;
		this.squadCat = squadCat;
	}
	
	/**
	 * Adds the skill category.
	 *
	 * @param skillCategory the skill category
	 */
	public void addSkillCat(SkillCategory skillCategory) {
		this.skills.add(skillCategory);
	}
	
	/**
	 * Clear skills.
	 */
	public void clearSkills() {
		this.skills.clear();
	}
	
	/**
	 * Gets the skills.
	 *
	 * @return the skills
	 */
	public ArrayList<SkillCategory> getSkills() {
		return this.skills;
	}
	
	
	/**
	 * Gets the next of kin.
	 *
	 * @return the next of kin
	 */
	public String getNextOfKin() {
		return this.nextOfKin;
	}
	
	/**
	 * Gets the next of kin phone.
	 *
	 * @return the next of kin phone
	 */
	public String getNextOfKinPhone() {
		return this.NOKPhone;
	}
	
	/**
	 * Gets the doctor.
	 *
	 * @return the doctor
	 */
	public String getDoctor() {
		return this.doctor;
	}
	
	/**
	 * Gets the doctor phone.
	 *
	 * @return the doctor phone
	 */
	public String getDoctorPhone() {
		return this.docPhone;
	}
	
	/**
	 * Gets the health issues.
	 *
	 * @return the health issues
	 */
	public String getHealthIssues() {
		return this.healthIssues;
	}
	
	/**
	 * Gets the position.
	 *
	 * @return the position
	 */
	public Position getPosition() {
		return this.position;
	}
	
	/**
	 * Gets the squad cat.
	 *
	 * @return the squad cat
	 */
	public SquadCategory getSquadCat() {
		return this.squadCat;
	}
	
	/**
	 * Sets the skills.
	 *
	 * @param skills the new skills
	 */
	public void setSkills(ArrayList<SkillCategory> skills) {
		this.skills = skills;
	}
	
	/**
	 * Sets the next of kin.
	 *
	 * @param nextOfKin the new next of kin
	 */
	public void setNextOfKin(String nextOfKin) {
		this.nextOfKin = nextOfKin;
	}
	
	/**
	 * Sets the next of kin phone.
	 *
	 * @param NOKPhone the new next of kin phone
	 */
	public void setNextOfKinPhone(String NOKPhone) {
		this.NOKPhone = NOKPhone;
	}
	
	/**
	 * Sets the doctor.
	 *
	 * @param doctor the new doctor
	 */
	public void setDoctor(String doctor) {
		this.doctor = doctor;
	}
	
	/**
	 * Sets the doctor phone.
	 *
	 * @param docPhone the new doctor phone
	 */
	public void setDoctorPhone(String docPhone) {
		this.docPhone = docPhone;
	}
	
	/**
	 * Sets the health issues.
	 *
	 * @param healthIssues the new health issues
	 */
	public void setHealthIssues(String healthIssues) {
		this.healthIssues = healthIssues;
	}
	
	/**
	 * Sets the position.
	 *
	 * @param position the new position
	 */
	public void setPosition(Position position) {
		this.position = position;
	}
	
	/**
	 * Sets the squad cat.
	 *
	 * @param squadCat the new squad cat
	 */
	public void setSquadCat(SquadCategory squadCat) {
		this.squadCat = squadCat;
	}
}
package models;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * @author: Liam Irvine
 * The Class SkillCategory.
 * Implements the Serializable interface.
 */
public class SkillCategory implements Serializable{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	
	/** The category name. */
	private String categoryName;
	
	/** The skills. */
	private ArrayList<Skill> skills = new ArrayList<Skill>();
	
	/** The notes. */
	private String notes;
	
	
	/**
	 * Adds the skill to list.
	 *
	 * @param skill the skill
	 */
	public void addSkillToList(Skill skill) {
		this.skills.add(skill);
	}
	
	/**
	 * Gets the category name.
	 *
	 * @return the category name
	 */
	public String getCategoryName() {
		return this.categoryName;
	}
	
	/**
	 * Gets the skill rating.
	 *
	 * @param skillName the skill name
	 * @return the skill rating
	 */
	public int getSkillRating(String skillName) {
		for (Skill skill: this.skills) {
			if (skill.getSkillName().equals(skillName)) {
				return skill.getRating();
			}
		}
		return 1;
	}
	
	/**
	 * Gets the skills.
	 *
	 * @return the skills
	 */
	public ArrayList<Skill> getSkills() {
		return this.skills;
	}
	
	/**
	 * Gets the notes.
	 *
	 * @return the notes
	 */
	public String getNotes() {
		return this.notes;
	}
	
	/**
	 * Sets the category name.
	 *
	 * @param categoryName the new category name
	 */
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	
	/**
	 * Sets the skills.
	 *
	 * @param skills the new skills
	 */
	public void setSkills(ArrayList<Skill> skills) {
		this.skills = skills;
	}
	
	/**
	 * Sets the notes.
	 *
	 * @param notes the new notes
	 */
	public void setNotes(String notes) {
		this.notes = notes;
	}
}

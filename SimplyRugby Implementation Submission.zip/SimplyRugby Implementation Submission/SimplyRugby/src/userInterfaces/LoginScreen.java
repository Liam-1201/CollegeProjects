package userInterfaces;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.JPasswordField;
/**
 * 
 * @author Liam Irvine
 * The class LoginScreen, inherits JFrame
 */
public class LoginScreen extends JFrame {

	private JPanel contentPane;
	private JTextField txtUsername;
	private Controller myController;
	private JLabel lblUsername;
	private JLabel lblNewLabel;
	private JPasswordField txtPassword;

	/**
	 * Create the frame.
	 */
	public LoginScreen(Controller newController) {
		myController = newController;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 746, 541);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JLabel lblWelcome = new JLabel("Welcome to the Simply Rugby Application!");
		lblWelcome.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblWelcome.setBounds(89, 79, 573, 116);
		contentPane.add(lblWelcome);
		
		txtUsername = new JTextField();
		txtUsername.setBounds(286, 237, 163, 32);
		contentPane.add(txtUsername);
		txtUsername.setColumns(10);
		
		JButton btnLogin = new JButton("Login!");
		btnLogin.addActionListener(new ActionListener() {
			/**
			 * Method to login when button is pressed
			 */
			public void actionPerformed(ActionEvent e) {
				
				boolean result = validateInput();
				if(result) {
					boolean retVal = myController.performLoginRequest(txtUsername.getText(), txtPassword.getText());
					
					if(retVal) {
						dispose();
					} else {
						displayMessage("Login Failed - try again!");
						txtUsername.setText("");
						txtPassword.setText("");
					}
				} else {
					displayMessage("You must enter a username and password!");
				}
			}
		});
		btnLogin.setBounds(286, 350, 163, 32);
		contentPane.add(btnLogin);
		
		lblUsername = new JLabel("Username");
		lblUsername.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblUsername.setBounds(331, 210, 72, 32);
		contentPane.add(lblUsername);
		
		lblNewLabel = new JLabel("Password");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel.setBounds(331, 286, 72, 23);
		contentPane.add(lblNewLabel);
		
		txtPassword = new JPasswordField();
		txtPassword.setBounds(286, 307, 163, 32);
		contentPane.add(txtPassword);
	}
	
	/**
	 * Validate input.
	 *
	 * @return true, if successful
	 */
	private boolean validateInput() {
		boolean retVal = true;
		
		if(txtUsername.getText().equals("") || txtPassword.getText().equals("")) {
			retVal = false;
		}
		
		return retVal;
	}
	
	/**
	 * Display message.
	 *
	 * @param message the message
	 */
	private void displayMessage(String message) {
		JOptionPane.showMessageDialog(this, message);
	}
}

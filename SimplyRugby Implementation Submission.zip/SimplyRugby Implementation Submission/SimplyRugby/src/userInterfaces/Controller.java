package userInterfaces;

import java.time.LocalDate;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import enums.Position;
import enums.SquadCategory;
import models.JuniorPlayer;
import models.Member;
import models.Player;
import models.SkillCategory;
import models.Squad;
import services.JuniorService;
import services.MemberService;
import services.PlayerService;
import services.SquadService;


/**
 * @author Liam Irvine
 * The Class Controller.
 */
public class Controller {
	
	/** The login screen. */
	LoginScreen loginScreen;
	
	/** The player service. */
	PlayerService playerService;
	
	/** The member service. */
	MemberService memberService;
	
	/** The junior service. */
	JuniorService juniorService;
	
	/** The squad service. */
	SquadService squadService;
	
	/** The admin screen. */
	AdminScreen adminScreen;
	
	/** The coach screen. */
	CoachScreen coachScreen;
	
	/** The logged coach. */
	Member loggedCoach;
	
	
	/**
	 * Instantiates a new controller.
	 */
	public Controller() {
		loginScreen = new LoginScreen(this);
		loginScreen.setVisible(true);
		playerService = new PlayerService();
		memberService = new MemberService();
		juniorService = new JuniorService();
		squadService = new SquadService();
	}
	
	/**
	 * Perform login request.
	 *
	 * @param username the username
	 * @param password the password
	 * @return true, if successful
	 */
	public boolean performLoginRequest(String username, String password) {
		boolean result = false;
		
		try {
			Member loginMember = memberService.login(username, password);
			
			if(loginMember.getIsAdmin()) {
				result = true;
				JFrame f = new JFrame();
				JOptionPane.showMessageDialog(f, "Login Successful!");
				adminScreen = new AdminScreen(this);
				adminScreen.setVisible(true);
			} else if (!loginMember.getIsAdmin()) {
				result = true;
				this.loggedCoach = loginMember;
				JFrame f = new JFrame();
				JOptionPane.showMessageDialog(f, "Login Successful!");
				coachScreen = new CoachScreen(this);
				coachScreen.setVisible(true);
			}
		} catch (NullPointerException e1) {
			result = false;
			return result;
		}
		
		
		
		return result;
		
	}
	
	/**
	 * Logout.
	 * Display login screen.
	 */
	public void logout() {
		try {
			adminScreen.dispose();
		} catch (NullPointerException e1) {
			coachScreen.dispose();
			this.loggedCoach = null;
		}
		
		try {
			coachScreen.dispose();
			this.loggedCoach = null;
		} catch (NullPointerException e1) {
			adminScreen.dispose();
		}
		
		loginScreen = new LoginScreen(this);
		loginScreen.setVisible(true);
	}
	
	/**
	 * Gets the logged coach.
	 *
	 * @return the logged coach
	 */
	public Member getLoggedCoach() {
		return this.loggedCoach;
	}
	
	/**
	 * Creates the new coach.
	 *
	 * @param firstname the firstname
	 * @param surname the surname
	 * @param username the username
	 * @param password the password
	 * @param isAdmin the is admin
	 * @param postCode the post code
	 * @param address the address
	 * @param dateOfBirth the date of birth
	 * @param email the email
	 * @param phone the phone
	 * @param SRUNumber the SRU number
	 * @param coach the coach
	 * @param squad the squad
	 * @return message to user
	 */
	public String createNewCoach(String firstname, String surname, String username, String password, boolean isAdmin,
			String postCode, String address, LocalDate dateOfBirth,
			String email, String phone, String SRUNumber, boolean coach, Squad squad) {
		Member newCoach = new Member(firstname, surname, username, password, false, postCode, address, dateOfBirth,
				email, phone, SRUNumber, true, squad);
		
		boolean result = memberService.createNewCoach(newCoach);
		
		if (result) {
			squadService.addCoach(newCoach);
			return "Coach Created!";
		} else {
			return "Coach Creation Failed! Coach with that SRU Number already exists!";
		}
	}
	
	/**
	 * Edits the coach.
	 *
	 * @param firstname the firstname
	 * @param surname the surname
	 * @param username the username
	 * @param password the password
	 * @param isAdmin the is admin check
	 * @param postCode the post code
	 * @param address the address
	 * @param dateOfBirth the date of birth
	 * @param email the email
	 * @param phone the phone
	 * @param SRUNumber the SRU number
	 * @param coach the coach
	 * @param squad the squad
	 * @return message to user
	 */
	public String editCoach(String firstname, String surname, String username, String password, boolean isAdmin,
			String postCode, String address, LocalDate dateOfBirth,
			String email, String phone, String SRUNumber, boolean coach, Squad squad) {
		Member newCoach = new Member(firstname, surname, username, password, isAdmin, postCode, address, dateOfBirth,
				email, phone, SRUNumber, coach, squad);
		
		boolean result = memberService.editCoach(newCoach);
		
		if (result) {
			squadService.addCoach(newCoach);
			return "Coach Editted!";
		} else {
			return "Coach Edit Failed!";
		}
		
	}
	
	/**
	 * Creates the new junior.
	 *
	 * @param firstname the firstname
	 * @param surname the surname
	 * @param username the username
	 * @param password the password
	 * @param isAdmin the is admin check
	 * @param postCode the post code
	 * @param address the address
	 * @param dateOfBirth the date of birth
	 * @param email the email
	 * @param phone the phone
	 * @param SRUNumber the SRU number
	 * @param coach the coach
	 * @param squad the squad
	 * @param skills the skills
	 * @param nextOfKin the next of kin
	 * @param NOKPhone the NOK phone
	 * @param doctor the doctor
	 * @param docPhone the doc phone
	 * @param healthIssues the health issues
	 * @param position the position
	 * @param squadCat the squad cat
	 * @param guardian1 the guardian 1
	 * @param relationship1 the relationship 1
	 * @param address1 the address 1
	 * @param guardianPhone1 the guardian phone 1
	 * @param guardian2 the guardian 2
	 * @param relationship2 the relationship 2
	 * @param address2 the address 2
	 * @param guardianPhone2 the guardian phone 2
	 * @param doctorAddress the doctor address
	 * @return message to user
	 */
	public String createNewJunior(String firstname, String surname, String username, String password, boolean isAdmin,
			String postCode, String address, LocalDate dateOfBirth,
			String email, String phone, String SRUNumber, boolean coach, Squad squad, ArrayList<SkillCategory> skills,
			String nextOfKin, String NOKPhone, String doctor, String docPhone, String healthIssues, Position position, SquadCategory squadCat,
			String guardian1, String relationship1, String address1, String guardianPhone1,
			String guardian2, String relationship2, String address2, String guardianPhone2, String doctorAddress) {
		JuniorPlayer newJunior = new JuniorPlayer(firstname, surname, null, null, false, postCode, address, dateOfBirth, email, phone, SRUNumber, 
				false, squad, skills, nextOfKin, NOKPhone, doctor, docPhone,
				healthIssues, position, squadCat, guardian1, relationship1, address1, guardianPhone1,
				guardian2, relationship2, address2, guardianPhone2, doctorAddress);
		
		boolean result = juniorService.createNewJunior(newJunior);
		
		if (result) {
			squadService.addPlayer(newJunior);
			return "Player Created!";
		} else {
			return "Player Creation Failed!";
		}
	}
	
	/**
	 * Edits the junior.
	 *
	 * @param firstname the firstname
	 * @param surname the surname
	 * @param username the username
	 * @param password the password
	 * @param isAdmin the is admin check
	 * @param postCode the post code
	 * @param address the address
	 * @param dateOfBirth the date of birth
	 * @param email the email
	 * @param phone the phone
	 * @param SRUNumber the SRU number
	 * @param coach the coach
	 * @param squad the squad
	 * @param skills the skills
	 * @param nextOfKin the next of kin
	 * @param NOKPhone the NOK phone
	 * @param doctor the doctor
	 * @param docPhone the doc phone
	 * @param healthIssues the health issues
	 * @param position the position
	 * @param squadCat the squad cat
	 * @param guardian1 the guardian 1
	 * @param relationship1 the relationship 1
	 * @param address1 the address 1
	 * @param guardianPhone1 the guardian phone 1
	 * @param guardian2 the guardian 2
	 * @param relationship2 the relationship 2
	 * @param address2 the address 2
	 * @param guardianPhone2 the guardian phone 2
	 * @param doctorAddress the doctor address
	 * @return message to user
	 */
	public String editJunior(String firstname, String surname, String username, String password, boolean isAdmin,
			String postCode, String address, LocalDate dateOfBirth,
			String email, String phone, String SRUNumber, boolean coach, Squad squad, ArrayList<SkillCategory> skills,
			String nextOfKin, String NOKPhone, String doctor, String docPhone, String healthIssues, Position position, SquadCategory squadCat,
			String guardian1, String relationship1, String address1, String guardianPhone1,
			String guardian2, String relationship2, String address2, String guardianPhone2, String doctorAddress) {
		JuniorPlayer editJunior = new JuniorPlayer(firstname, surname, null, null, false, postCode, address, dateOfBirth, email, phone, SRUNumber, 
				false, squad, skills, nextOfKin, NOKPhone, doctor, docPhone,
				healthIssues, position, squadCat, guardian1, relationship1, address1, guardianPhone1,
				guardian2, relationship2, address2, guardianPhone2, doctorAddress);
		
		boolean result = juniorService.editJunior(editJunior);
		
		if (result) {
			squadService.editPlayer(editJunior);
			return "Player Editted!";
		} else {
			return "Player Edit Failed!";
		}
	}
	
	
	/**
	 * Creates the new senior.
	 *
	 * @param firstname the firstname
	 * @param surname the surname
	 * @param username the username
	 * @param password the password
	 * @param isAdmin the is admin check
	 * @param postCode the post code
	 * @param address the address
	 * @param dateOfBirth the date of birth
	 * @param email the email
	 * @param phone the phone
	 * @param SRUNumber the SRU number
	 * @param coach the coach
	 * @param squad the squad
	 * @param skills the skills
	 * @param nextOfKin the next of kin
	 * @param NOKPhone the NOK phone
	 * @param doctor the doctor
	 * @param docPhone the doc phone
	 * @param healthIssues the health issues
	 * @param position the position
	 * @param squadCat the squad cat
	 * @return message to user
	 */
	public String createNewSenior(String firstname, String surname, String username, String password, boolean isAdmin,
			String postCode, String address, LocalDate dateOfBirth,
			String email, String phone, String SRUNumber, boolean coach, Squad squad,
			ArrayList<SkillCategory> skills, String nextOfKin, String NOKPhone,
			String doctor, String docPhone, String healthIssues, Position position, SquadCategory squadCat) {
		Player newPlayer = new Player(firstname, surname, null, null, false, postCode, address, dateOfBirth, email, phone, SRUNumber, 
				false, squad, skills, nextOfKin, NOKPhone, doctor, docPhone,
				healthIssues, position, squadCat);
		
		boolean result = playerService.createNewSenior(newPlayer);
		
		if (result) {
			squadService.addPlayer(newPlayer);
			return "Player Created!";
		} else {
			return "Player Creation Failed!";
		}
	}
	
	/**
	 * Edits the senior.
	 *
	 * @param firstname the firstname
	 * @param surname the surname
	 * @param username the username
	 * @param password the password
	 * @param isAdmin the is admin check
	 * @param postCode the post code
	 * @param address the address
	 * @param dateOfBirth the date of birth
	 * @param email the email
	 * @param phone the phone
	 * @param SRUNumber the SRU number
	 * @param coach the coach
	 * @param squad the squad
	 * @param skills the skills
	 * @param nextOfKin the next of kin
	 * @param NOKPhone the NOK phone
	 * @param doctor the doctor
	 * @param docPhone the doc phone
	 * @param healthIssues the health issues
	 * @param position the position
	 * @param squadCat the squad cat
	 * @return message to user
	 */
	public String editSenior(String firstname, String surname, String username, String password, boolean isAdmin,
			String postCode, String address, LocalDate dateOfBirth,
			String email, String phone, String SRUNumber, boolean coach, Squad squad,
			ArrayList<SkillCategory> skills, String nextOfKin, String NOKPhone,
			String doctor, String docPhone, String healthIssues, Position position, SquadCategory squadCat) {
		Player newPlayer = new Player(firstname, surname, null, null, false, postCode, address, dateOfBirth, email, phone, SRUNumber, 
				false, squad, skills, nextOfKin, NOKPhone, doctor, docPhone,
				healthIssues, position, squadCat);
		
		boolean result = playerService.editSenior(newPlayer);
		
		if (result) {
			squadService.editPlayer(newPlayer);
			return "Player Editted!";
		} else {
			return "Player Edit Failed!";
		}
	}
	
	/**
	 * Save senior player skills.
	 *
	 * @param player the player
	 * @param standard the standard skill
	 * @param spin the spin skill
	 * @param pop the pop skill
	 * @param passingNotes the passing notes
	 * @param front the front skill
	 * @param rear the rear skill
	 * @param side the side skill
	 * @param scrabble the scrabble skill
	 * @param tacklingNotes the tackling notes
	 * @param drop the drop skill
	 * @param punt the punt skill
	 * @param grubber the grubber skill
	 * @param goal the goal skill
	 * @param kickingNotes the kicking notes
	 * @return message to user
	 */
	public String saveSeniorPlayerSkills(Player player, int standard, int spin, int pop, String passingNotes, int front,
			int rear, int side, int scrabble, String tacklingNotes, int drop, int punt, int grubber, int goal,
			String kickingNotes) {
		boolean result = playerService.savePlayerSkills(player, standard, spin, pop, passingNotes, front, rear,
				side, scrabble, tacklingNotes, drop, punt, grubber, goal, kickingNotes);

		if (result) {
			return "Skills Saved!";
		} else {
			return "Skills Saving Failed!";
		}
	}
	
	/**
	 * Save junior player skills.
	 *
	 * @param player the player
	 * @param standard the standard
	 * @param spin the spin
	 * @param pop the pop
	 * @param passingNotes the passing notes
	 * @param front the front
	 * @param rear the rear
	 * @param side the side
	 * @param scrabble the scrabble
	 * @param tacklingNotes the tackling notes
	 * @param drop the drop
	 * @param punt the punt
	 * @param grubber the grubber
	 * @param goal the goal
	 * @param kickingNotes the kicking notes
	 * @return message to user
	 */
	public String saveJuniorPlayerSkills(JuniorPlayer player, int standard, int spin, int pop, String passingNotes, int front,
			int rear, int side, int scrabble, String tacklingNotes, int drop, int punt, int grubber, int goal,
			String kickingNotes) {
		boolean result = juniorService.savePlayerSkills(player, standard, spin, pop, passingNotes, front, rear,
				side, scrabble, tacklingNotes, drop, punt, grubber, goal, kickingNotes);

		if (result) {
			return "Skills Saved!";
		} else {
			return "Skills Saving Failed!";
		}
	}
	
	
	/**
	 * Creates the squad.
	 *
	 * @param squadName the squad name
	 * @param squadCategory the squad category
	 * @return message to user
	 */
	public String createSquad(String squadName, SquadCategory squadCategory) {
		
		Squad newSquad = new Squad(squadName, null, null, squadCategory);
		
		if (squadName == null || squadName == "") {
			return "Please type a name for your squad!";
		} else {
			boolean result = squadService.createSquad(newSquad);
			
			if (result) {
				return "Squad Created!";
			} else {
				return "Squad Creation Failed!";
			}
		}
	}
	
	/**
	 * Delete squad.
	 *
	 * @param selectedSquad the selected squad
	 * @return message to user
	 */
	public String deleteSquad(Squad selectedSquad) {
		boolean result = squadService.deleteSquad(selectedSquad);
		
		if (result) {
			return "Squad Deleted!";
		} else {
			return "Squad Deletion Failed!";
		}
	}
	
	/**
	 * Rename squad.
	 *
	 * @param selectedSquad the selected squad
	 * @param newName the new name
	 * @return message to user
	 */
	public String renameSquad(Squad selectedSquad, String newName) {
		boolean result = squadService.renameSquad(selectedSquad, newName);
		
		if (result) {
			return "Squad Renamed!";
		} else {
			return "Squad Rename Failed!";
		}
	}
	
	/**
	 * Gets the squad object.
	 *
	 * @param coach the coach
	 * @return the squad object
	 */
	public Squad getSquadObject(Member coach) {
		Squad coachSquad = squadService.getSquadObject(coach);
		return coachSquad;
	}
	
	/**
	 * Gets the coach list.
	 *
	 * @return the coach list
	 */
	public ArrayList<Member> getCoachList() {
		ArrayList<Member> coachList = memberService.getCoachList();
		return coachList;
	}
	
	/**
	 * Gets the senior list.
	 *
	 * @return the senior list
	 */
	public ArrayList<Player> getSeniorList() {
		ArrayList<Player> playerList = new ArrayList<Player>();
		playerList = playerService.getSeniorList();
		return playerList;
	}
	
	/**
	 * Gets the junior list.
	 *
	 * @return the junior list
	 */
	public ArrayList<JuniorPlayer> getJuniorList() {
		ArrayList<JuniorPlayer> juniorList = juniorService.getJuniorList();
		return juniorList;
	}
	
	/**
	 * Gets the squad list.
	 *
	 * @return the squad list
	 */
	public ArrayList<Squad> getSquadList() {
		ArrayList<Squad> squadList = squadService.getSquadList();
		return squadList;
	}
	
	/**
	 * Gets the senior squad list.
	 *
	 * @return the senior squad list
	 */
	public ArrayList<Squad> getSeniorSquadList() {
		ArrayList<Squad> squadList = squadService.getSquadList();
		ArrayList<Squad> seniorSquadList = new ArrayList<Squad>();
		
		int i = 0;
		for (Squad squad: squadList) {
			if (squad.getSquadCategory().equals(SquadCategory.senior)) {
				seniorSquadList.add(squad);
			}
			i++;
		}
		return seniorSquadList;
	}
	
	/**
	 * Gets the junior squad list.
	 *
	 * @return the junior squad list
	 */
	public ArrayList<Squad> getJuniorSquadList() {
		ArrayList<Squad> squadList = squadService.getSquadList();
		ArrayList<Squad> juniorSquadList = new ArrayList<Squad>();
		
		int i = 0;
		for (Squad squad: squadList) {
			if (squad.getSquadCategory().equals(SquadCategory.junior)) {
				juniorSquadList.add(squad);
			}
			i++;
		}
		return juniorSquadList;
	}
	
	
}

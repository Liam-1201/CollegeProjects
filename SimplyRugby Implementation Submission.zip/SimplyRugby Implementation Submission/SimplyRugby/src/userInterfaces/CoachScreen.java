package userInterfaces;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;

import enums.Position;
import enums.SquadCategory;
import models.JuniorPlayer;
import models.Member;
import models.Player;
import models.Skill;
import models.SkillCategory;
import models.Squad;

import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;

/**
 * 
 * @author Liam Irvine
 * Class CoachScreen inherits JFrame
 */
public class CoachScreen extends JFrame {

	/**
	 * Initialises variables for each field created.
	 */
	private JPanel contentPane;
	private static Point point = new Point();
	private Squad coachesSquad;
	private Controller myController;
	private ArrayList<Player> seniorList;
	private ArrayList<JuniorPlayer> juniorList;
	private ArrayList<Player> coachesPlayerList;
	private ArrayList<JuniorPlayer> coachesJuniorPlayerList;
	private ArrayList<SkillCategory> skillList;
	private String message;
	private JTextField txtNewJuniorFirstName;
	private JTextField txtNewJuniorLastName;
	private JTextField txtNewJuniorSRUNumber;
	private JTextField txtNewJuniorDOB;
	private JTextField txtNewJuniorPhone;
	private JTextField txtNewJuniorEmail;
	private JTextField txtNewJuniorDoctor;
	private JTextField txtNewJuniorDoctorPhone;
	private JTextField txtNewJuniorGuardian1Name;
	private JTextField txtNewJuniorRelationship1;
	private JTextField txtNewGuardian1Phone;
	private JTextField txtNewJuniorGuardian2Phone;
	private JTextField txtNewJuniorRelationship2;
	private JTextField txtNewJuniorGuardian2Name;
	private JTextField txtNewSeniorFirstName;
	private JTextField txtNewSeniorLastName;
	private JTextField txtNewSeniorSRUNumber;
	private JTextField txtNewSeniorDOB;
	private JTextField txtNewSeniorPhone;
	private JTextField txtNewSeniorEmail;
	private JTextField txtNewSeniorNOKName;
	private JTextField txtNewSeniorNOKPhone;
	private JTextField txtNewSeniorDoctorName;
	private JTextField txtNewSeniorDoctorPhone;
	private JTextField txtEditJuniorFirstName;
	private JTextField txtEditJuniorLastName;
	private JTextField txtEditJuniorSRUNumber;
	private JTextField txtEditJuniorDOB;
	private JTextField txtEditJuniorPhone;
	private JTextField txtEditJuniorEmail;
	private JTextField txtEditJuniorDoctorName;
	private JTextField txtEditJuniorDoctorPhone;
	private JTextField txtEditJuniorGuardian1Name;
	private JTextField txtEditJuniorRelationship1;
	private JTextField txtEditJuniorGuardian1Phone;
	private JTextField txtEditJuniorGuardian2Phone;
	private JTextField txtEditJuniorRelationship2;
	private JTextField txtEditJuniorGuardian2Name;
	private JTextField txtEditSeniorFirstName;
	private JTextField txtEditSeniorLastName;
	private JTextField txtEditSeniorSRUNumber;
	private JTextField txtEditSeniorDOB;
	private JTextField txtEditSeniorPhone;
	private JTextField txtEditSeniorEmail;
	private JTextField txtEditSeniorNOKName;
	private JTextField txtEditSeniorNOKPhone;
	private JTextField txtEditSeniorDoctorName;
	private JTextField txtEditSeniorDoctorPhone;
	private JTextField txtEditSkillFirstName;
	private JTextField txtEditSkillLastName;
	private JTextField txtEditSkillSRUNumber;
	private JTextField txtEditSkillPosition;
	private JTextField txtNewJuniorPostcode;
	private JTextField txtNewSeniorPostcode;
	private JTextField txtEditJuniorPostcode;
	private JTextField txtEditSeniorPostcode;

	/**
	 * Create the frame.
	 */
	public CoachScreen(Controller newController) {
		myController = newController;
		
		DefaultListModel players = new DefaultListModel<>();
		
		this.seniorList = new ArrayList<Player>();
		this.juniorList = new ArrayList<JuniorPlayer>();
		this.seniorList = myController.getSeniorList();
		this.juniorList = myController.getJuniorList();
		this.coachesJuniorPlayerList = new ArrayList<JuniorPlayer>();
		this.coachesPlayerList = new ArrayList<Player>();
		this.skillList = new ArrayList<SkillCategory>();
		Member loggedCoach = myController.getLoggedCoach();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/MM/yyyy");
		seniorList = myController.getSeniorList();
		juniorList = myController.getJuniorList();
		if (loggedCoach.getSquad().getSquadCategory() == SquadCategory.senior) {
			coachesPlayerList = getSeniorCoachesList(coachesPlayerList, loggedCoach);
		} else {
			coachesJuniorPlayerList = getJuniorCoachesList(coachesJuniorPlayerList, loggedCoach);
		}
		
		setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 998, 625);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		ImageIcon background = (new ImageIcon(AdminScreen.class.getResource("/images/background.jpg")));
		Image img = background.getImage();
		Image imgScale = img.getScaledInstance(793, 625, Image.SCALE_SMOOTH);
		ImageIcon scaledIcon = new ImageIcon(imgScale);
		
		JPanel welcomePanel = new JPanel();
		welcomePanel.setBounds(205, 53, 793, 572);
		contentPane.add(welcomePanel);
		welcomePanel.setLayout(null);
		
		JLabel lblBackground = new JLabel("");
		lblBackground.setIcon(scaledIcon);
		lblBackground.setBounds(0, 0, 793, 625);
		welcomePanel.add(lblBackground);
		
		/**
		 * Adds functionality to title bar
		 */
		JPanel titleBar = new JPanel();
		titleBar.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				point.x = e.getX();
                point.y = e.getY();
			}
		});
		titleBar.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseDragged(MouseEvent e) {
				Point p = getLocation();
                setLocation(p.x + e.getX() - point.x, p.y + e.getY() - point.y);
			}
		});
		
		JPanel newJuniorPlayerPanel = new JPanel();
		newJuniorPlayerPanel.setLayout(null);
		newJuniorPlayerPanel.setBounds(205, 53, 793, 572);
		contentPane.add(newJuniorPlayerPanel);
		
		JLabel lblNewLabel_5_2_2 = new JLabel("Add New Player");
		lblNewLabel_5_2_2.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel_5_2_2.setBounds(302, 11, 245, 105);
		newJuniorPlayerPanel.add(lblNewLabel_5_2_2);
		
		JLabel lblNewLabel_6_6 = new JLabel("First Name:");
		lblNewLabel_6_6.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_6.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_6.setBounds(10, 88, 75, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_6);
		
		txtNewJuniorFirstName = new JTextField();
		txtNewJuniorFirstName.setColumns(10);
		txtNewJuniorFirstName.setBounds(95, 96, 143, 20);
		newJuniorPlayerPanel.add(txtNewJuniorFirstName);
		
		JLabel lblNewLabel_6_1_2 = new JLabel("Last Name:");
		lblNewLabel_6_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_1_2.setBounds(10, 127, 75, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_1_2);
		
		txtNewJuniorLastName = new JTextField();
		txtNewJuniorLastName.setColumns(10);
		txtNewJuniorLastName.setBounds(95, 134, 143, 20);
		newJuniorPlayerPanel.add(txtNewJuniorLastName);
		
		JLabel lblNewLabel_6_2_3 = new JLabel("Address:");
		lblNewLabel_6_2_3.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_2_3.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_2_3.setBounds(10, 166, 75, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_2_3);
		
		JTextArea txtNewJuniorAddress = new JTextArea();
		txtNewJuniorAddress.setBorder(UIManager.getBorder("TextField.border"));
		txtNewJuniorAddress.setBounds(95, 171, 143, 105);
		newJuniorPlayerPanel.add(txtNewJuniorAddress);
		
		txtNewJuniorSRUNumber = new JTextField();
		txtNewJuniorSRUNumber.setColumns(10);
		txtNewJuniorSRUNumber.setBounds(342, 95, 143, 20);
		newJuniorPlayerPanel.add(txtNewJuniorSRUNumber);
		
		JLabel lblNewLabel_6_3_5 = new JLabel("SRU Number:");
		lblNewLabel_6_3_5.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_5.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_5.setBounds(223, 88, 109, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_3_5);
		
		txtNewJuniorDOB = new JTextField();
		txtNewJuniorDOB.setColumns(10);
		txtNewJuniorDOB.setBounds(342, 134, 143, 20);
		newJuniorPlayerPanel.add(txtNewJuniorDOB);
		
		JLabel lblNewLabel_6_3_1_2 = new JLabel("Date of Birth:");
		lblNewLabel_6_3_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_1_2.setBounds(223, 127, 109, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_3_1_2);
		
		txtNewJuniorPhone = new JTextField();
		txtNewJuniorPhone.setColumns(10);
		txtNewJuniorPhone.setBounds(614, 93, 143, 20);
		newJuniorPlayerPanel.add(txtNewJuniorPhone);
		
		JLabel lblNewLabel_6_3_2_2 = new JLabel("Phone Number:");
		lblNewLabel_6_3_2_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_2_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_2_2.setBounds(495, 86, 109, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_3_2_2);
		
		txtNewJuniorEmail = new JTextField();
		txtNewJuniorEmail.setColumns(10);
		txtNewJuniorEmail.setBounds(614, 134, 143, 20);
		newJuniorPlayerPanel.add(txtNewJuniorEmail);
		
		JLabel lblNewLabel_6_3_3_2 = new JLabel("E-mail:");
		lblNewLabel_6_3_3_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_3_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_3_2.setBounds(495, 127, 109, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_3_3_2);
		
		JSeparator separator_1_3 = new JSeparator();
		separator_1_3.setBounds(0, 319, 793, 2);
		newJuniorPlayerPanel.add(separator_1_3);
		
		txtNewJuniorDoctor = new JTextField();
		txtNewJuniorDoctor.setColumns(10);
		txtNewJuniorDoctor.setBounds(95, 339, 143, 20);
		newJuniorPlayerPanel.add(txtNewJuniorDoctor);
		
		JLabel lblNewLabel_6_4_2_2 = new JLabel("Doctor:");
		lblNewLabel_6_4_2_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_2_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_2_2.setBounds(-24, 332, 109, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_4_2_2);
		
		JLabel lblNewLabel_6_4_1_1_2 = new JLabel("Tel:");
		lblNewLabel_6_4_1_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_1_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_1_1_2.setBounds(-24, 371, 109, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_4_1_1_2);
		
		txtNewJuniorDoctorPhone = new JTextField();
		txtNewJuniorDoctorPhone.setColumns(10);
		txtNewJuniorDoctorPhone.setBounds(95, 378, 143, 20);
		newJuniorPlayerPanel.add(txtNewJuniorDoctorPhone);
		
		JLabel lblNewLabel_6_2_1_2 = new JLabel("Known Health issues:");
		lblNewLabel_6_2_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_2_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_2_1_2.setBounds(27, 410, 152, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_2_1_2);
		
		JTextArea txtNewJuniorHealthIssues = new JTextArea();
		txtNewJuniorHealthIssues.setBorder(UIManager.getBorder("TextField.border"));
		txtNewJuniorHealthIssues.setBounds(189, 415, 461, 64);
		newJuniorPlayerPanel.add(txtNewJuniorHealthIssues);
		
		JSeparator separator_1_1_2 = new JSeparator();
		separator_1_1_2.setBounds(0, 490, 793, 2);
		newJuniorPlayerPanel.add(separator_1_1_2);
		
		/**
		 * Button to take the user back to the home screen
		 */
		JButton btnNewJuniorCancel = new JButton("Cancel");
		btnNewJuniorCancel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				newJuniorPlayerPanel.setVisible(false);
				welcomePanel.setVisible(true);
			}
		});
		btnNewJuniorCancel.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		btnNewJuniorCancel.setBounds(568, 503, 89, 45);
		newJuniorPlayerPanel.add(btnNewJuniorCancel);
		
		JTextArea txtNewJuniorDoctorAddress = new JTextArea();
		txtNewJuniorDoctorAddress.setBorder(UIManager.getBorder("TextField.border"));
		txtNewJuniorDoctorAddress.setBounds(342, 339, 308, 60);
		newJuniorPlayerPanel.add(txtNewJuniorDoctorAddress);
		
		JLabel lblNewLabel_6_2_3_1 = new JLabel("Address:");
		lblNewLabel_6_2_3_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_2_3_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_2_3_1.setBounds(261, 332, 75, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_2_3_1);
		
		JSeparator separator_1_3_1 = new JSeparator();
		separator_1_3_1.setBounds(241, 166, 552, 2);
		newJuniorPlayerPanel.add(separator_1_3_1);
		
		JSeparator separator_2 = new JSeparator();
		separator_2.setOrientation(SwingConstants.VERTICAL);
		separator_2.setBounds(241, 166, 1, 155);
		newJuniorPlayerPanel.add(separator_2);
		
		txtNewJuniorGuardian1Name = new JTextField();
		txtNewJuniorGuardian1Name.setColumns(10);
		txtNewJuniorGuardian1Name.setBounds(342, 174, 143, 20);
		newJuniorPlayerPanel.add(txtNewJuniorGuardian1Name);
		
		JLabel lblNewLabel_6_6_1 = new JLabel("Guardian 1:");
		lblNewLabel_6_6_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_6_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_6_1.setBounds(257, 166, 75, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_6_1);
		
		txtNewJuniorRelationship1 = new JTextField();
		txtNewJuniorRelationship1.setColumns(10);
		txtNewJuniorRelationship1.setBounds(342, 210, 143, 20);
		newJuniorPlayerPanel.add(txtNewJuniorRelationship1);
		
		JLabel lblNewLabel_6_6_1_1 = new JLabel("Relationship:");
		lblNewLabel_6_6_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_6_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_6_1_1.setBounds(241, 202, 91, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_6_1_1);
		
		JLabel lblNewLabel_6_2_3_1_1 = new JLabel("Address:");
		lblNewLabel_6_2_3_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_2_3_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_2_3_1_1.setBounds(261, 234, 75, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_2_3_1_1);
		
		JTextArea txtNewGuardian1Address = new JTextArea();
		txtNewGuardian1Address.setBorder(UIManager.getBorder("TextField.border"));
		txtNewGuardian1Address.setBounds(342, 241, 143, 35);
		newJuniorPlayerPanel.add(txtNewGuardian1Address);
		
		txtNewGuardian1Phone = new JTextField();
		txtNewGuardian1Phone.setColumns(10);
		txtNewGuardian1Phone.setBounds(342, 287, 143, 20);
		newJuniorPlayerPanel.add(txtNewGuardian1Phone);
		
		JLabel lblNewLabel_6_4_1_1_2_1 = new JLabel("Tel:");
		lblNewLabel_6_4_1_1_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_1_1_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_1_1_2_1.setBounds(223, 280, 109, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_4_1_1_2_1);
		
		txtNewJuniorGuardian2Phone = new JTextField();
		txtNewJuniorGuardian2Phone.setColumns(10);
		txtNewJuniorGuardian2Phone.setBounds(614, 287, 143, 20);
		newJuniorPlayerPanel.add(txtNewJuniorGuardian2Phone);
		
		JLabel lblNewLabel_6_4_1_1_2_1_1 = new JLabel("Tel:");
		lblNewLabel_6_4_1_1_2_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_1_1_2_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_1_1_2_1_1.setBounds(495, 280, 109, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_4_1_1_2_1_1);
		
		JLabel lblNewLabel_6_2_3_1_1_1 = new JLabel("Address:");
		lblNewLabel_6_2_3_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_2_3_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_2_3_1_1_1.setBounds(533, 234, 75, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_2_3_1_1_1);
		
		JTextArea txtNewGuardian2Address = new JTextArea();
		txtNewGuardian2Address.setBorder(UIManager.getBorder("TextField.border"));
		txtNewGuardian2Address.setBounds(614, 241, 143, 35);
		newJuniorPlayerPanel.add(txtNewGuardian2Address);
		
		txtNewJuniorRelationship2 = new JTextField();
		txtNewJuniorRelationship2.setColumns(10);
		txtNewJuniorRelationship2.setBounds(614, 210, 143, 20);
		newJuniorPlayerPanel.add(txtNewJuniorRelationship2);
		
		JLabel lblNewLabel_6_6_1_1_1 = new JLabel("Relationship:");
		lblNewLabel_6_6_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_6_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_6_1_1_1.setBounds(513, 202, 91, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_6_1_1_1);
		
		JLabel lblNewLabel_6_6_1_2 = new JLabel("Guardian 2:");
		lblNewLabel_6_6_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_6_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_6_1_2.setBounds(529, 166, 75, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_6_1_2);
		
		txtNewJuniorGuardian2Name = new JTextField();
		txtNewJuniorGuardian2Name.setColumns(10);
		txtNewJuniorGuardian2Name.setBounds(614, 174, 143, 20);
		newJuniorPlayerPanel.add(txtNewJuniorGuardian2Name);
		
		JComboBox cmbNewJuniorPosition = new JComboBox();
		cmbNewJuniorPosition.setModel(new DefaultComboBoxModel(Position.values()));
		cmbNewJuniorPosition.setBounds(95, 517, 143, 22);
		newJuniorPlayerPanel.add(cmbNewJuniorPosition);
		
		JLabel lblNewLabel_6_4_1_1_2_2 = new JLabel("Position:");
		lblNewLabel_6_4_1_1_2_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_1_1_2_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_1_1_2_2.setBounds(-24, 511, 109, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_4_1_1_2_2);
		
		/**
		 * Button to add a new junior player with values set by the user
		 */
		JButton btnNewJuniorSubmit = new JButton("Submit");
		btnNewJuniorSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String DOB = txtNewJuniorDOB.getText();
					message = myController.createNewJunior(txtNewJuniorFirstName.getText(), txtNewJuniorLastName.getText(), 
							null, null, false, txtNewJuniorPostcode.getText(), txtNewJuniorAddress.getText(), 
							LocalDate.parse(DOB, formatter), txtNewJuniorEmail.getText(),
							txtNewJuniorPhone.getText(), txtNewJuniorSRUNumber.getText(), false, loggedCoach.getSquad(),
							null, null, null, txtNewJuniorDoctor.getText(),
							txtNewJuniorDoctorPhone.getText(), txtNewJuniorHealthIssues.getText(), (Position) cmbNewJuniorPosition.getSelectedItem(),
							SquadCategory.junior, txtNewJuniorGuardian1Name.getText(), txtNewJuniorRelationship1.getText(), 
							txtNewGuardian1Address.getText(), txtNewGuardian1Phone.getText(), 
							txtNewJuniorGuardian2Name.getText(), txtNewJuniorRelationship2.getText(), 
							txtNewGuardian2Address.getText(), txtNewJuniorGuardian2Phone.getText(), txtNewJuniorDoctorAddress.getText());
					juniorList = myController.getJuniorList();
					
					displayMessage(message);
				} catch (DateTimeParseException e1) {
					JFrame f = new JFrame();
					JOptionPane.showMessageDialog(f, "Please insert a correct date (DD/MM/YYYY)");
				} catch (Exception e2) {
					JFrame f = new JFrame();
					JOptionPane.showMessageDialog(f, "Please insert correct data in all boxes!");
				}
			}
		});
		btnNewJuniorSubmit.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		btnNewJuniorSubmit.setBounds(675, 503, 89, 45);
		newJuniorPlayerPanel.add(btnNewJuniorSubmit);
		
		txtNewJuniorPostcode = new JTextField();
		txtNewJuniorPostcode.setColumns(10);
		txtNewJuniorPostcode.setBounds(95, 287, 143, 20);
		newJuniorPlayerPanel.add(txtNewJuniorPostcode);
		
		JLabel lblNewLabel_6_1_2_2 = new JLabel("Postcode:");
		lblNewLabel_6_1_2_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_1_2_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_1_2_2.setBounds(10, 280, 75, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_1_2_2);
		newJuniorPlayerPanel.setVisible(false);
		newJuniorPlayerPanel.setVisible(false);
		
		
		
		JPanel newSeniorPlayerPanel = new JPanel();
		newSeniorPlayerPanel.setLayout(null);
		newSeniorPlayerPanel.setBounds(205, 53, 793, 572);
		contentPane.add(newSeniorPlayerPanel);
		
		JLabel lblNewLabel_5_2 = new JLabel("Add New Player");
		lblNewLabel_5_2.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel_5_2.setBounds(302, 11, 245, 105);
		newSeniorPlayerPanel.add(lblNewLabel_5_2);
		
		JLabel lblNewLabel_6 = new JLabel("First Name:");
		lblNewLabel_6.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6.setBounds(104, 108, 75, 28);
		newSeniorPlayerPanel.add(lblNewLabel_6);
		
		txtNewSeniorFirstName = new JTextField();
		txtNewSeniorFirstName.setColumns(10);
		txtNewSeniorFirstName.setBounds(189, 115, 143, 20);
		newSeniorPlayerPanel.add(txtNewSeniorFirstName);
		
		JLabel lblNewLabel_6_1 = new JLabel("Last Name:");
		lblNewLabel_6_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_1.setBounds(104, 147, 75, 28);
		newSeniorPlayerPanel.add(lblNewLabel_6_1);
		
		txtNewSeniorLastName = new JTextField();
		txtNewSeniorLastName.setColumns(10);
		txtNewSeniorLastName.setBounds(189, 154, 143, 20);
		newSeniorPlayerPanel.add(txtNewSeniorLastName);
		
		JLabel lblNewLabel_6_2 = new JLabel("Address:");
		lblNewLabel_6_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_2.setBounds(104, 186, 75, 28);
		newSeniorPlayerPanel.add(lblNewLabel_6_2);
		
		JTextArea txtNewSeniorAddress = new JTextArea();
		txtNewSeniorAddress.setBorder(UIManager.getBorder("TextField.border"));
		txtNewSeniorAddress.setBounds(189, 191, 143, 102);
		newSeniorPlayerPanel.add(txtNewSeniorAddress);
		
		txtNewSeniorSRUNumber = new JTextField();
		txtNewSeniorSRUNumber.setColumns(10);
		txtNewSeniorSRUNumber.setBounds(507, 115, 143, 20);
		newSeniorPlayerPanel.add(txtNewSeniorSRUNumber);
		
		JLabel lblNewLabel_6_3 = new JLabel("SRU Number:");
		lblNewLabel_6_3.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3.setBounds(388, 108, 109, 28);
		newSeniorPlayerPanel.add(lblNewLabel_6_3);
		
		txtNewSeniorDOB = new JTextField();
		txtNewSeniorDOB.setColumns(10);
		txtNewSeniorDOB.setBounds(507, 154, 143, 20);
		newSeniorPlayerPanel.add(txtNewSeniorDOB);
		
		JLabel lblNewLabel_6_3_1 = new JLabel("Date of Birth:");
		lblNewLabel_6_3_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_1.setBounds(388, 147, 109, 28);
		newSeniorPlayerPanel.add(lblNewLabel_6_3_1);
		
		txtNewSeniorPhone = new JTextField();
		txtNewSeniorPhone.setColumns(10);
		txtNewSeniorPhone.setBounds(507, 193, 143, 20);
		newSeniorPlayerPanel.add(txtNewSeniorPhone);
		
		JLabel lblNewLabel_6_3_2 = new JLabel("Phone Number:");
		lblNewLabel_6_3_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_2.setBounds(388, 186, 109, 28);
		newSeniorPlayerPanel.add(lblNewLabel_6_3_2);
		
		txtNewSeniorEmail = new JTextField();
		txtNewSeniorEmail.setColumns(10);
		txtNewSeniorEmail.setBounds(507, 234, 143, 20);
		newSeniorPlayerPanel.add(txtNewSeniorEmail);
		
		JLabel lblNewLabel_6_3_3 = new JLabel("E-mail:");
		lblNewLabel_6_3_3.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_3.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_3.setBounds(388, 227, 109, 28);
		newSeniorPlayerPanel.add(lblNewLabel_6_3_3);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(0, 319, 793, 2);
		newSeniorPlayerPanel.add(separator_1);
		
		JLabel lblNewLabel_6_4 = new JLabel("Next of Kin:");
		lblNewLabel_6_4.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4.setBounds(70, 332, 109, 28);
		newSeniorPlayerPanel.add(lblNewLabel_6_4);
		
		txtNewSeniorNOKName = new JTextField();
		txtNewSeniorNOKName.setColumns(10);
		txtNewSeniorNOKName.setBounds(189, 339, 143, 20);
		newSeniorPlayerPanel.add(txtNewSeniorNOKName);
		
		JLabel lblNewLabel_6_4_1 = new JLabel("Tel:");
		lblNewLabel_6_4_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_1.setBounds(70, 371, 109, 28);
		newSeniorPlayerPanel.add(lblNewLabel_6_4_1);
		
		txtNewSeniorNOKPhone = new JTextField();
		txtNewSeniorNOKPhone.setColumns(10);
		txtNewSeniorNOKPhone.setBounds(189, 378, 143, 20);
		newSeniorPlayerPanel.add(txtNewSeniorNOKPhone);
		
		txtNewSeniorDoctorName = new JTextField();
		txtNewSeniorDoctorName.setColumns(10);
		txtNewSeniorDoctorName.setBounds(507, 339, 143, 20);
		newSeniorPlayerPanel.add(txtNewSeniorDoctorName);
		
		JLabel lblNewLabel_6_4_2 = new JLabel("Doctor:");
		lblNewLabel_6_4_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_2.setBounds(388, 332, 109, 28);
		newSeniorPlayerPanel.add(lblNewLabel_6_4_2);
		
		JLabel lblNewLabel_6_4_1_1 = new JLabel("Tel:");
		lblNewLabel_6_4_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_1_1.setBounds(388, 371, 109, 28);
		newSeniorPlayerPanel.add(lblNewLabel_6_4_1_1);
		
		txtNewSeniorDoctorPhone = new JTextField();
		txtNewSeniorDoctorPhone.setColumns(10);
		txtNewSeniorDoctorPhone.setBounds(507, 378, 143, 20);
		newSeniorPlayerPanel.add(txtNewSeniorDoctorPhone);
		
		JLabel lblNewLabel_6_2_1 = new JLabel("Known Health issues:");
		lblNewLabel_6_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_2_1.setBounds(27, 410, 152, 28);
		newSeniorPlayerPanel.add(lblNewLabel_6_2_1);
		
		JTextArea txtNewSeniorHealthIssues = new JTextArea();
		txtNewSeniorHealthIssues.setBorder(UIManager.getBorder("TextField.border"));
		txtNewSeniorHealthIssues.setBounds(189, 415, 461, 64);
		newSeniorPlayerPanel.add(txtNewSeniorHealthIssues);
		
		JSeparator separator_1_1 = new JSeparator();
		separator_1_1.setBounds(0, 490, 793, 2);
		newSeniorPlayerPanel.add(separator_1_1);
		
		/**
		 * Button to take the user back to the home screen
		 */
		JButton btnNewSeniorCancel = new JButton("Cancel");
		btnNewSeniorCancel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				newSeniorPlayerPanel.setVisible(false);
				welcomePanel.setVisible(true);
			}
		});
		btnNewSeniorCancel.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		btnNewSeniorCancel.setBounds(568, 503, 89, 45);
		newSeniorPlayerPanel.add(btnNewSeniorCancel);
		
		JComboBox cmbNewSeniorPosition = new JComboBox();
		cmbNewSeniorPosition.setModel(new DefaultComboBoxModel(Position.values()));
		cmbNewSeniorPosition.setBounds(104, 517, 143, 22);
		newSeniorPlayerPanel.add(cmbNewSeniorPosition);
		
		JLabel lblNewLabel_6_4_1_1_2_2_2 = new JLabel("Position:");
		lblNewLabel_6_4_1_1_2_2_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_1_1_2_2_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_1_1_2_2_2.setBounds(-15, 511, 109, 28);
		newSeniorPlayerPanel.add(lblNewLabel_6_4_1_1_2_2_2);
		
		JLabel lblNewLabel_6_3_3_3 = new JLabel("Postcode:");
		lblNewLabel_6_3_3_3.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_3_3.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_3_3.setBounds(388, 265, 109, 28);
		newSeniorPlayerPanel.add(lblNewLabel_6_3_3_3);
		
		txtNewSeniorPostcode = new JTextField();
		txtNewSeniorPostcode.setColumns(10);
		txtNewSeniorPostcode.setBounds(507, 272, 143, 20);
		newSeniorPlayerPanel.add(txtNewSeniorPostcode);
		
		/**
		 * Button to add a new senior player with values set by the user
		 */
		JButton btnNewSeniorSubmit = new JButton("Submit");
		btnNewSeniorSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String DOB = txtNewSeniorDOB.getText();
					message = myController.createNewSenior(txtNewSeniorFirstName.getText(), txtNewSeniorLastName.getText(), 
							null, null, false, txtNewSeniorPostcode.getText(), txtNewSeniorAddress.getText(), 
							LocalDate.parse(DOB, formatter), txtNewSeniorEmail.getText(),
							txtNewSeniorPhone.getText(), txtNewSeniorSRUNumber.getText(), false, loggedCoach.getSquad(),
							null, txtNewSeniorNOKName.getText(), txtNewSeniorNOKPhone.getText(), txtNewSeniorDoctorName.getText(),
							txtNewSeniorDoctorPhone.getText(), txtNewSeniorHealthIssues.getText(), (Position) cmbNewSeniorPosition.getSelectedItem(),
							SquadCategory.senior);
					seniorList = myController.getSeniorList();
					displayMessage(message);
				} catch (DateTimeParseException e1) {
					JFrame f = new JFrame();
					JOptionPane.showMessageDialog(f, "Please insert a correct date (DD/MM/YYYY)");
				} catch (Exception e2) {
					JFrame f = new JFrame();
					JOptionPane.showMessageDialog(f, "Please insert correct data in all boxes!");
				}
			}
		});
		btnNewSeniorSubmit.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		btnNewSeniorSubmit.setBounds(675, 503, 89, 45);
		newSeniorPlayerPanel.add(btnNewSeniorSubmit);
		newSeniorPlayerPanel.setVisible(false);
		newSeniorPlayerPanel.setVisible(false);
		
		
		titleBar.setBackground(Color.LIGHT_GRAY);
		titleBar.setBounds(205, 0, 793, 53);
		contentPane.add(titleBar);
		titleBar.setLayout(null);
		
		/**
		 * Adds functionality to close the program
		 */
		JLabel lblExit = new JLabel("X");
		lblExit.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				System.exit(0);
			}
		});
		lblExit.setHorizontalAlignment(SwingConstants.CENTER);
		lblExit.setForeground(Color.WHITE);
		lblExit.setFont(new Font("Segoe UI", Font.BOLD, 25));
		lblExit.setBounds(745, 0, 48, 53);
		titleBar.add(lblExit);
		
		JLabel lblNewLabel_10 = new JLabel("Coach Application");
		lblNewLabel_10.setForeground(Color.WHITE);
		lblNewLabel_10.setFont(new Font("Segoe UI", Font.BOLD, 25));
		lblNewLabel_10.setBounds(10, 11, 410, 31);
		titleBar.add(lblNewLabel_10);
		
		
		JPanel editJuniorPlayerPanel = new JPanel();
		editJuniorPlayerPanel.setLayout(null);
		editJuniorPlayerPanel.setBounds(205, 53, 793, 572);
		contentPane.add(editJuniorPlayerPanel);
		
		JLabel lblNewLabel_5_2_2_1 = new JLabel("Edit Junior Player");
		lblNewLabel_5_2_2_1.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel_5_2_2_1.setBounds(302, 11, 245, 105);
		editJuniorPlayerPanel.add(lblNewLabel_5_2_2_1);
		
		JLabel lblNewLabel_6_6_2 = new JLabel("First Name:");
		lblNewLabel_6_6_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_6_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_6_2.setBounds(10, 88, 75, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_6_2);
		
		txtEditJuniorFirstName = new JTextField();
		txtEditJuniorFirstName.setColumns(10);
		txtEditJuniorFirstName.setBounds(95, 96, 143, 20);
		editJuniorPlayerPanel.add(txtEditJuniorFirstName);
		
		JLabel lblNewLabel_6_1_2_1 = new JLabel("Last Name:");
		lblNewLabel_6_1_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_1_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_1_2_1.setBounds(10, 127, 75, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_1_2_1);
		
		txtEditJuniorLastName = new JTextField();
		txtEditJuniorLastName.setColumns(10);
		txtEditJuniorLastName.setBounds(95, 134, 143, 20);
		editJuniorPlayerPanel.add(txtEditJuniorLastName);
		
		JLabel lblNewLabel_6_2_3_2 = new JLabel("Address:");
		lblNewLabel_6_2_3_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_2_3_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_2_3_2.setBounds(10, 166, 75, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_2_3_2);
		
		JTextArea txtEditJuniorAddress = new JTextArea();
		txtEditJuniorAddress.setBorder(UIManager.getBorder("TextField.border"));
		txtEditJuniorAddress.setBounds(95, 171, 143, 105);
		editJuniorPlayerPanel.add(txtEditJuniorAddress);
		
		txtEditJuniorSRUNumber = new JTextField();
		txtEditJuniorSRUNumber.setEditable(false);
		txtEditJuniorSRUNumber.setColumns(10);
		txtEditJuniorSRUNumber.setBounds(342, 95, 143, 20);
		editJuniorPlayerPanel.add(txtEditJuniorSRUNumber);
		
		JLabel lblNewLabel_6_3_5_1 = new JLabel("SRU Number:");
		lblNewLabel_6_3_5_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_5_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_5_1.setBounds(223, 88, 109, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_3_5_1);
		
		txtEditJuniorDOB = new JTextField();
		txtEditJuniorDOB.setColumns(10);
		txtEditJuniorDOB.setBounds(342, 134, 143, 20);
		editJuniorPlayerPanel.add(txtEditJuniorDOB);
		
		JLabel lblNewLabel_6_3_1_2_1 = new JLabel("Date of Birth:");
		lblNewLabel_6_3_1_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_1_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_1_2_1.setBounds(223, 127, 109, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_3_1_2_1);
		
		txtEditJuniorPhone = new JTextField();
		txtEditJuniorPhone.setColumns(10);
		txtEditJuniorPhone.setBounds(614, 96, 143, 20);
		editJuniorPlayerPanel.add(txtEditJuniorPhone);
		
		JLabel lblNewLabel_6_3_2_2_1 = new JLabel("Phone Number:");
		lblNewLabel_6_3_2_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_2_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_2_2_1.setBounds(495, 88, 109, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_3_2_2_1);
		
		txtEditJuniorEmail = new JTextField();
		txtEditJuniorEmail.setColumns(10);
		txtEditJuniorEmail.setBounds(614, 134, 143, 20);
		editJuniorPlayerPanel.add(txtEditJuniorEmail);
		
		JLabel lblNewLabel_6_3_3_2_1 = new JLabel("E-mail:");
		lblNewLabel_6_3_3_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_3_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_3_2_1.setBounds(495, 127, 109, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_3_3_2_1);
		
		JSeparator separator_1_3_2 = new JSeparator();
		separator_1_3_2.setBounds(0, 319, 793, 2);
		editJuniorPlayerPanel.add(separator_1_3_2);
		
		txtEditJuniorDoctorName = new JTextField();
		txtEditJuniorDoctorName.setColumns(10);
		txtEditJuniorDoctorName.setBounds(95, 339, 143, 20);
		editJuniorPlayerPanel.add(txtEditJuniorDoctorName);
		
		JLabel lblNewLabel_6_4_2_2_1 = new JLabel("Doctor:");
		lblNewLabel_6_4_2_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_2_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_2_2_1.setBounds(-24, 332, 109, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_4_2_2_1);
		
		JLabel lblNewLabel_6_4_1_1_2_3 = new JLabel("Tel:");
		lblNewLabel_6_4_1_1_2_3.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_1_1_2_3.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_1_1_2_3.setBounds(-24, 371, 109, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_4_1_1_2_3);
		
		txtEditJuniorDoctorPhone = new JTextField();
		txtEditJuniorDoctorPhone.setColumns(10);
		txtEditJuniorDoctorPhone.setBounds(95, 378, 143, 20);
		editJuniorPlayerPanel.add(txtEditJuniorDoctorPhone);
		
		JLabel lblNewLabel_6_2_1_2_1 = new JLabel("Known Health issues:");
		lblNewLabel_6_2_1_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_2_1_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_2_1_2_1.setBounds(27, 410, 152, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_2_1_2_1);
		
		JTextArea txtEditJuniorHealthIssues = new JTextArea();
		txtEditJuniorHealthIssues.setBorder(UIManager.getBorder("TextField.border"));
		txtEditJuniorHealthIssues.setBounds(189, 415, 461, 64);
		editJuniorPlayerPanel.add(txtEditJuniorHealthIssues);
		
		JSeparator separator_1_1_2_1 = new JSeparator();
		separator_1_1_2_1.setBounds(0, 490, 793, 2);
		editJuniorPlayerPanel.add(separator_1_1_2_1);
		
		/**
		 * Button to take the user back to the home screen
		 */
		JButton btnEditJuniorCancel = new JButton("Cancel");
		btnEditJuniorCancel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				editJuniorPlayerPanel.setVisible(false);
				welcomePanel.setVisible(true);
			}
		});
		btnEditJuniorCancel.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		btnEditJuniorCancel.setBounds(568, 503, 89, 45);
		editJuniorPlayerPanel.add(btnEditJuniorCancel);
		
		JTextArea txtEditJuniorDoctorAddress = new JTextArea();
		txtEditJuniorDoctorAddress.setBorder(UIManager.getBorder("TextField.border"));
		txtEditJuniorDoctorAddress.setBounds(342, 339, 308, 60);
		editJuniorPlayerPanel.add(txtEditJuniorDoctorAddress);
		
		JLabel lblNewLabel_6_2_3_1_2 = new JLabel("Address:");
		lblNewLabel_6_2_3_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_2_3_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_2_3_1_2.setBounds(261, 332, 75, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_2_3_1_2);
		
		JSeparator separator_1_3_1_1 = new JSeparator();
		separator_1_3_1_1.setBounds(241, 166, 552, 2);
		editJuniorPlayerPanel.add(separator_1_3_1_1);
		
		JSeparator separator_2_1 = new JSeparator();
		separator_2_1.setOrientation(SwingConstants.VERTICAL);
		separator_2_1.setBounds(241, 166, 1, 155);
		editJuniorPlayerPanel.add(separator_2_1);
		
		txtEditJuniorGuardian1Name = new JTextField();
		txtEditJuniorGuardian1Name.setColumns(10);
		txtEditJuniorGuardian1Name.setBounds(342, 174, 143, 20);
		editJuniorPlayerPanel.add(txtEditJuniorGuardian1Name);
		
		JLabel lblNewLabel_6_6_1_3 = new JLabel("Guardian 1:");
		lblNewLabel_6_6_1_3.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_6_1_3.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_6_1_3.setBounds(257, 166, 75, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_6_1_3);
		
		txtEditJuniorRelationship1 = new JTextField();
		txtEditJuniorRelationship1.setColumns(10);
		txtEditJuniorRelationship1.setBounds(342, 210, 143, 20);
		editJuniorPlayerPanel.add(txtEditJuniorRelationship1);
		
		JLabel lblNewLabel_6_6_1_1_2 = new JLabel("Relationship:");
		lblNewLabel_6_6_1_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_6_1_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_6_1_1_2.setBounds(241, 202, 91, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_6_1_1_2);
		
		JLabel lblNewLabel_6_2_3_1_1_2 = new JLabel("Address:");
		lblNewLabel_6_2_3_1_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_2_3_1_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_2_3_1_1_2.setBounds(261, 234, 75, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_2_3_1_1_2);
		
		JTextArea txtEditJuniorGuardian1Address = new JTextArea();
		txtEditJuniorGuardian1Address.setBorder(UIManager.getBorder("TextField.border"));
		txtEditJuniorGuardian1Address.setBounds(342, 241, 143, 35);
		editJuniorPlayerPanel.add(txtEditJuniorGuardian1Address);
		
		txtEditJuniorGuardian1Phone = new JTextField();
		txtEditJuniorGuardian1Phone.setColumns(10);
		txtEditJuniorGuardian1Phone.setBounds(342, 287, 143, 20);
		editJuniorPlayerPanel.add(txtEditJuniorGuardian1Phone);
		
		JLabel lblNewLabel_6_4_1_1_2_1_2 = new JLabel("Tel:");
		lblNewLabel_6_4_1_1_2_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_1_1_2_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_1_1_2_1_2.setBounds(223, 280, 109, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_4_1_1_2_1_2);
		
		txtEditJuniorGuardian2Phone = new JTextField();
		txtEditJuniorGuardian2Phone.setColumns(10);
		txtEditJuniorGuardian2Phone.setBounds(614, 287, 143, 20);
		editJuniorPlayerPanel.add(txtEditJuniorGuardian2Phone);
		
		JLabel lblNewLabel_6_4_1_1_2_1_1_1 = new JLabel("Tel:");
		lblNewLabel_6_4_1_1_2_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_1_1_2_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_1_1_2_1_1_1.setBounds(495, 280, 109, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_4_1_1_2_1_1_1);
		
		JLabel lblNewLabel_6_2_3_1_1_1_1 = new JLabel("Address:");
		lblNewLabel_6_2_3_1_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_2_3_1_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_2_3_1_1_1_1.setBounds(533, 234, 75, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_2_3_1_1_1_1);
		
		JTextArea txtEditJuniorGuardian2Address = new JTextArea();
		txtEditJuniorGuardian2Address.setBorder(UIManager.getBorder("TextField.border"));
		txtEditJuniorGuardian2Address.setBounds(614, 241, 143, 35);
		editJuniorPlayerPanel.add(txtEditJuniorGuardian2Address);
		
		txtEditJuniorRelationship2 = new JTextField();
		txtEditJuniorRelationship2.setColumns(10);
		txtEditJuniorRelationship2.setBounds(614, 210, 143, 20);
		editJuniorPlayerPanel.add(txtEditJuniorRelationship2);
		
		JLabel lblNewLabel_6_6_1_1_1_1 = new JLabel("Relationship:");
		lblNewLabel_6_6_1_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_6_1_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_6_1_1_1_1.setBounds(513, 202, 91, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_6_1_1_1_1);
		
		JLabel lblNewLabel_6_6_1_2_1 = new JLabel("Guardian 2:");
		lblNewLabel_6_6_1_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_6_1_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_6_1_2_1.setBounds(529, 166, 75, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_6_1_2_1);
		
		txtEditJuniorGuardian2Name = new JTextField();
		txtEditJuniorGuardian2Name.setColumns(10);
		txtEditJuniorGuardian2Name.setBounds(614, 174, 143, 20);
		editJuniorPlayerPanel.add(txtEditJuniorGuardian2Name);
		
		JComboBox cmbEditJuniorPosition = new JComboBox();
		cmbEditJuniorPosition.setModel(new DefaultComboBoxModel(Position.values()));
		cmbEditJuniorPosition.setBounds(95, 517, 143, 22);
		editJuniorPlayerPanel.add(cmbEditJuniorPosition);
		
		JLabel lblNewLabel_6_4_1_1_2_2_3 = new JLabel("Position:");
		lblNewLabel_6_4_1_1_2_2_3.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_1_1_2_2_3.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_1_1_2_2_3.setBounds(-24, 511, 109, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_4_1_1_2_2_3);
		
		txtEditJuniorPostcode = new JTextField();
		txtEditJuniorPostcode.setColumns(10);
		txtEditJuniorPostcode.setBounds(95, 287, 143, 20);
		editJuniorPlayerPanel.add(txtEditJuniorPostcode);
		
		JLabel lblNewLabel_6_1_2_1_2 = new JLabel("Postcode:");
		lblNewLabel_6_1_2_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_1_2_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_1_2_1_2.setBounds(10, 280, 75, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_1_2_1_2);
		
		/**
		 * Button to edit the selected junior player with new values set by the user
		 */
		JButton btnEditJuniorSubmit = new JButton("Submit");
		btnEditJuniorSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String DOB = txtEditJuniorDOB.getText();
					message = myController.editJunior(txtEditJuniorFirstName.getText(), txtEditJuniorLastName.getText(), 
							null, null, false, txtEditJuniorPostcode.getText(), txtEditJuniorAddress.getText(), 
							LocalDate.parse(DOB, formatter), txtEditJuniorEmail.getText(),
							txtEditJuniorPhone.getText(), txtEditJuniorSRUNumber.getText(), false, loggedCoach.getSquad(),
							null, null, null, txtEditJuniorDoctorName.getText(),
							txtEditJuniorDoctorPhone.getText(), txtEditJuniorHealthIssues.getText(), (Position) cmbEditJuniorPosition.getSelectedItem(),
							SquadCategory.junior, txtEditJuniorGuardian1Name.getText(), txtEditJuniorRelationship1.getText(), 
							txtEditJuniorGuardian1Address.getText(), txtEditJuniorGuardian1Phone.getText(), 
							txtEditJuniorGuardian2Name.getText(), txtEditJuniorRelationship2.getText(), 
							txtEditJuniorGuardian2Address.getText(), txtEditJuniorGuardian2Phone.getText(), txtEditJuniorDoctorAddress.getText());
					juniorList = myController.getJuniorList();
					displayMessage(message);
				} catch (DateTimeParseException e1) {
					JFrame f = new JFrame();
					JOptionPane.showMessageDialog(f, "Please insert a correct date (DD/MM/YYYY)");
				} catch (Exception e2) {
					JFrame f = new JFrame();
					JOptionPane.showMessageDialog(f, "Please insert correct data in all boxes!");
				}
			}
		});
		btnEditJuniorSubmit.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		btnEditJuniorSubmit.setBounds(675, 503, 89, 45);
		editJuniorPlayerPanel.add(btnEditJuniorSubmit);
		editJuniorPlayerPanel.setVisible(false);
		
		JPanel editSeniorPlayerPanel = new JPanel();
		editSeniorPlayerPanel.setLayout(null);
		editSeniorPlayerPanel.setBounds(205, 53, 793, 572);
		contentPane.add(editSeniorPlayerPanel);
		
		JLabel lblNewLabel_5_2_1 = new JLabel("Edit Senior Player");
		lblNewLabel_5_2_1.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel_5_2_1.setBounds(302, 11, 245, 105);
		editSeniorPlayerPanel.add(lblNewLabel_5_2_1);
		
		JLabel lblNewLabel_6_5 = new JLabel("First Name:");
		lblNewLabel_6_5.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_5.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_5.setBounds(104, 113, 75, 28);
		editSeniorPlayerPanel.add(lblNewLabel_6_5);
		
		txtEditSeniorFirstName = new JTextField();
		txtEditSeniorFirstName.setColumns(10);
		txtEditSeniorFirstName.setBounds(189, 120, 143, 20);
		editSeniorPlayerPanel.add(txtEditSeniorFirstName);
		
		JLabel lblNewLabel_6_1_1 = new JLabel("Last Name:");
		lblNewLabel_6_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_1_1.setBounds(104, 152, 75, 28);
		editSeniorPlayerPanel.add(lblNewLabel_6_1_1);
		
		txtEditSeniorLastName = new JTextField();
		txtEditSeniorLastName.setColumns(10);
		txtEditSeniorLastName.setBounds(189, 159, 143, 20);
		editSeniorPlayerPanel.add(txtEditSeniorLastName);
		
		JLabel lblNewLabel_6_2_2 = new JLabel("Address:");
		lblNewLabel_6_2_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_2_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_2_2.setBounds(104, 191, 75, 28);
		editSeniorPlayerPanel.add(lblNewLabel_6_2_2);
		
		JTextArea txtEditSeniorAddress = new JTextArea();
		txtEditSeniorAddress.setBorder(UIManager.getBorder("TextField.border"));
		txtEditSeniorAddress.setBounds(189, 196, 143, 63);
		editSeniorPlayerPanel.add(txtEditSeniorAddress);
		
		txtEditSeniorSRUNumber = new JTextField();
		txtEditSeniorSRUNumber.setEditable(false);
		txtEditSeniorSRUNumber.setColumns(10);
		txtEditSeniorSRUNumber.setBounds(507, 120, 143, 20);
		editSeniorPlayerPanel.add(txtEditSeniorSRUNumber);
		
		JLabel lblNewLabel_6_3_4 = new JLabel("SRU Number:");
		lblNewLabel_6_3_4.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_4.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_4.setBounds(388, 113, 109, 28);
		editSeniorPlayerPanel.add(lblNewLabel_6_3_4);
		
		txtEditSeniorDOB = new JTextField();
		txtEditSeniorDOB.setColumns(10);
		txtEditSeniorDOB.setBounds(507, 159, 143, 20);
		editSeniorPlayerPanel.add(txtEditSeniorDOB);
		
		JLabel lblNewLabel_6_3_1_1 = new JLabel("Date of Birth:");
		lblNewLabel_6_3_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_1_1.setBounds(388, 152, 109, 28);
		editSeniorPlayerPanel.add(lblNewLabel_6_3_1_1);
		
		txtEditSeniorPhone = new JTextField();
		txtEditSeniorPhone.setColumns(10);
		txtEditSeniorPhone.setBounds(507, 198, 143, 20);
		editSeniorPlayerPanel.add(txtEditSeniorPhone);
		
		JLabel lblNewLabel_6_3_2_1 = new JLabel("Phone Number:");
		lblNewLabel_6_3_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_2_1.setBounds(388, 191, 109, 28);
		editSeniorPlayerPanel.add(lblNewLabel_6_3_2_1);
		
		txtEditSeniorEmail = new JTextField();
		txtEditSeniorEmail.setColumns(10);
		txtEditSeniorEmail.setBounds(507, 239, 143, 20);
		editSeniorPlayerPanel.add(txtEditSeniorEmail);
		
		JLabel lblNewLabel_6_3_3_1 = new JLabel("E-mail:");
		lblNewLabel_6_3_3_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_3_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_3_1.setBounds(388, 232, 109, 28);
		editSeniorPlayerPanel.add(lblNewLabel_6_3_3_1);
		
		JSeparator separator_1_2 = new JSeparator();
		separator_1_2.setBounds(0, 319, 793, 2);
		editSeniorPlayerPanel.add(separator_1_2);
		
		JLabel lblNewLabel_6_4_3 = new JLabel("Next of Kin:");
		lblNewLabel_6_4_3.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_3.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_3.setBounds(70, 332, 109, 28);
		editSeniorPlayerPanel.add(lblNewLabel_6_4_3);
		
		txtEditSeniorNOKName = new JTextField();
		txtEditSeniorNOKName.setColumns(10);
		txtEditSeniorNOKName.setBounds(189, 339, 143, 20);
		editSeniorPlayerPanel.add(txtEditSeniorNOKName);
		
		JLabel lblNewLabel_6_4_1_2 = new JLabel("Tel:");
		lblNewLabel_6_4_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_1_2.setBounds(70, 371, 109, 28);
		editSeniorPlayerPanel.add(lblNewLabel_6_4_1_2);
		
		txtEditSeniorNOKPhone = new JTextField();
		txtEditSeniorNOKPhone.setColumns(10);
		txtEditSeniorNOKPhone.setBounds(189, 378, 143, 20);
		editSeniorPlayerPanel.add(txtEditSeniorNOKPhone);
		
		txtEditSeniorDoctorName = new JTextField();
		txtEditSeniorDoctorName.setColumns(10);
		txtEditSeniorDoctorName.setBounds(507, 339, 143, 20);
		editSeniorPlayerPanel.add(txtEditSeniorDoctorName);
		
		JLabel lblNewLabel_6_4_2_1 = new JLabel("Doctor:");
		lblNewLabel_6_4_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_2_1.setBounds(388, 332, 109, 28);
		editSeniorPlayerPanel.add(lblNewLabel_6_4_2_1);
		
		JLabel lblNewLabel_6_4_1_1_1 = new JLabel("Tel:");
		lblNewLabel_6_4_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_1_1_1.setBounds(388, 371, 109, 28);
		editSeniorPlayerPanel.add(lblNewLabel_6_4_1_1_1);
		
		txtEditSeniorDoctorPhone = new JTextField();
		txtEditSeniorDoctorPhone.setColumns(10);
		txtEditSeniorDoctorPhone.setBounds(507, 378, 143, 20);
		editSeniorPlayerPanel.add(txtEditSeniorDoctorPhone);
		
		JLabel lblNewLabel_6_2_1_1 = new JLabel("Known Health issues:");
		lblNewLabel_6_2_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_2_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_2_1_1.setBounds(27, 410, 152, 28);
		editSeniorPlayerPanel.add(lblNewLabel_6_2_1_1);
		
		JTextArea txtEditSeniorHealthIssues = new JTextArea();
		txtEditSeniorHealthIssues.setBorder(UIManager.getBorder("TextField.border"));
		txtEditSeniorHealthIssues.setBounds(189, 415, 461, 64);
		editSeniorPlayerPanel.add(txtEditSeniorHealthIssues);
		
		JSeparator separator_1_1_1 = new JSeparator();
		separator_1_1_1.setBounds(0, 490, 793, 2);
		editSeniorPlayerPanel.add(separator_1_1_1);
		
		/**
		 * Button to take the user back to the home screen
		 */
		JButton btnEditSeniorCancel = new JButton("Cancel");
		btnEditSeniorCancel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				editSeniorPlayerPanel.setVisible(false);
				welcomePanel.setVisible(true);
			}
		});
		btnEditSeniorCancel.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		btnEditSeniorCancel.setBounds(568, 503, 89, 45);
		editSeniorPlayerPanel.add(btnEditSeniorCancel);
		
		JComboBox cmbEditSeniorPosition = new JComboBox();
		cmbEditSeniorPosition.setModel(new DefaultComboBoxModel(Position.values()));
		cmbEditSeniorPosition.setBounds(189, 517, 143, 22);
		editSeniorPlayerPanel.add(cmbEditSeniorPosition);
		
		JLabel lblNewLabel_6_2_1_1_1 = new JLabel("Position:");
		lblNewLabel_6_2_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_2_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_2_1_1_1.setBounds(27, 511, 152, 28);
		editSeniorPlayerPanel.add(lblNewLabel_6_2_1_1_1);
		
		JLabel lblNewLabel_6_3_3_1_2 = new JLabel("Postcode:");
		lblNewLabel_6_3_3_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_3_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_3_1_2.setBounds(70, 270, 109, 28);
		editSeniorPlayerPanel.add(lblNewLabel_6_3_3_1_2);
		
		txtEditSeniorPostcode = new JTextField();
		txtEditSeniorPostcode.setColumns(10);
		txtEditSeniorPostcode.setBounds(189, 277, 143, 20);
		editSeniorPlayerPanel.add(txtEditSeniorPostcode);
		
		/**
		 * Button to edit the selected senior player with new values set by the user
		 */
		JButton btnEditSeniorSubmit = new JButton("Submit");
		btnEditSeniorSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String DOB = txtEditSeniorDOB.getText();
					message = myController.editSenior(txtEditSeniorFirstName.getText(), txtEditSeniorLastName.getText(), 
							null, null, false, txtEditSeniorPostcode.getText(), txtEditSeniorAddress.getText(), 
							LocalDate.parse(DOB, formatter), txtEditSeniorEmail.getText(),
							txtEditSeniorPhone.getText(), txtEditSeniorSRUNumber.getText(), false, loggedCoach.getSquad(),
							null, txtEditSeniorNOKName.getText(), txtEditSeniorNOKPhone.getText(), txtEditSeniorDoctorName.getText(),
							txtEditSeniorDoctorPhone.getText(), txtEditSeniorHealthIssues.getText(), (Position) cmbEditSeniorPosition.getSelectedItem(),
							SquadCategory.senior);
					seniorList = myController.getSeniorList();
					displayMessage(message);
				} catch (DateTimeParseException e1) {
					JFrame f = new JFrame();
					JOptionPane.showMessageDialog(f, "Please insert a correct date (DD/MM/YYYY)");
				} catch (Exception e2) {
					JFrame f = new JFrame();
					JOptionPane.showMessageDialog(f, "Please insert correct data in all boxes!");
				}
			}
		});
		btnEditSeniorSubmit.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		btnEditSeniorSubmit.setBounds(675, 503, 89, 45);
		editSeniorPlayerPanel.add(btnEditSeniorSubmit);
		editSeniorPlayerPanel.setVisible(false);
		
		JPanel selectPlayerToEditPanel = new JPanel();
		selectPlayerToEditPanel.setLayout(null);
		selectPlayerToEditPanel.setBounds(205, 53, 793, 572);
		contentPane.add(selectPlayerToEditPanel);
		
		JLabel lblNewLabel_3_2 = new JLabel("Select a Player to Edit");
		lblNewLabel_3_2.setFont(new Font("Segoe UI", Font.BOLD, 25));
		lblNewLabel_3_2.setBounds(255, 11, 319, 51);
		selectPlayerToEditPanel.add(lblNewLabel_3_2);

		
		
		JList listOfPlayersToEdit = new JList(players);
		listOfPlayersToEdit.setBorder(UIManager.getBorder("TextField.border"));
		listOfPlayersToEdit.setBounds(41, 181, 213, 354);
		selectPlayerToEditPanel.add(listOfPlayersToEdit);
		
		JLabel lblNewLabel_3_1_2 = new JLabel("List of Players");
		lblNewLabel_3_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 20));
		lblNewLabel_3_1_2.setBounds(41, 139, 213, 51);
		selectPlayerToEditPanel.add(lblNewLabel_3_1_2);
		

		/**
		 * Button to take the selected user from the list
		 * Button will take the user to the form for the correct player type
		 * Text fields will be set to the values of the selected player
		 */
		JButton btnEditPlayer = new JButton("Edit Player");
		btnEditPlayer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JuniorPlayer editJunior;
				Player editSenior;
				try {
					if (loggedCoach.getSquad().getSquadCategory() == SquadCategory.junior) {
						editJunior = (JuniorPlayer) listOfPlayersToEdit.getSelectedValue();
						LocalDate selectedDOB = editJunior.getDateOfBirth();
						String formattedDate = selectedDOB.format(formatter);
						txtEditJuniorFirstName.setText(editJunior.getFirstname());
						txtEditJuniorLastName.setText(editJunior.getSurname());
						txtEditJuniorPostcode.setText(editJunior.getPostCode());
						txtEditJuniorSRUNumber.setText(editJunior.getSRUNumber());
						txtEditJuniorDOB.setText(formattedDate);
						txtEditJuniorPhone.setText(editJunior.getPhone());
						txtEditJuniorEmail.setText(editJunior.getEmail());
						txtEditJuniorAddress.setText(editJunior.getAddress());
						txtEditJuniorDoctorName.setText(editJunior.getDoctor());
						txtEditJuniorDoctorPhone.setText(editJunior.getDoctorPhone());
						txtEditJuniorHealthIssues.setText(editJunior.getHealthIssues());
						cmbEditJuniorPosition.setSelectedItem(editJunior.getPosition());
						txtEditJuniorGuardian1Name.setText(editJunior.getGuardian1());
						txtEditJuniorRelationship1.setText(editJunior.getRelationship1());
						txtEditJuniorGuardian1Address.setText(editJunior.getAddress1());
						txtEditJuniorGuardian1Phone.setText(editJunior.getGuardianPhone1());
						txtEditJuniorGuardian2Name.setText(editJunior.getGuardian2());
						txtEditJuniorRelationship2.setText(editJunior.getRelationship2());
						txtEditJuniorGuardian2Address.setText(editJunior.getAddress2());
						txtEditJuniorGuardian2Phone.setText(editJunior.getGuardianPhone2());
						txtEditJuniorDoctorAddress.setText(editJunior.getDoctorAddress());
						selectPlayerToEditPanel.setVisible(false);
						editJuniorPlayerPanel.setVisible(true);
					} else if (loggedCoach.getSquad().getSquadCategory() == SquadCategory.senior) {
						editSenior = (Player) listOfPlayersToEdit.getSelectedValue();
						LocalDate selectedDOB = editSenior.getDateOfBirth();
						String formattedDate = selectedDOB.format(formatter);
						txtEditSeniorFirstName.setText(editSenior.getFirstname());
						txtEditSeniorLastName.setText(editSenior.getSurname());
						txtEditSeniorPostcode.setText(editSenior.getPostCode());
						txtEditSeniorSRUNumber.setText(editSenior.getSRUNumber());
						txtEditSeniorDOB.setText(formattedDate);
						txtEditSeniorPhone.setText(editSenior.getPhone());
						txtEditSeniorEmail.setText(editSenior.getEmail());
						txtEditSeniorAddress.setText(editSenior.getAddress());
						txtEditSeniorNOKName.setText(editSenior.getNextOfKin());
						txtEditSeniorNOKPhone.setText(editSenior.getNextOfKinPhone());
						txtEditSeniorDoctorName.setText(editSenior.getDoctor());
						txtEditSeniorDoctorPhone.setText(editSenior.getDoctorPhone());
						txtEditSeniorHealthIssues.setText(editSenior.getHealthIssues());
						cmbEditSeniorPosition.setSelectedItem(editSenior.getPosition());
						selectPlayerToEditPanel.setVisible(false);
						editSeniorPlayerPanel.setVisible(true);
					}
					} catch (NullPointerException e1) {
						displayMessage("Please select a player from the list!");
				}
					
			}
		});
		btnEditPlayer.setFont(new Font("Segoe UI", Font.BOLD, 20));
		btnEditPlayer.setBounds(264, 440, 257, 94);
		selectPlayerToEditPanel.add(btnEditPlayer);
		
		JPanel editPlayerSkillsPanel = new JPanel();
		editPlayerSkillsPanel.setBounds(205, 53, 793, 572);
		contentPane.add(editPlayerSkillsPanel);
		editPlayerSkillsPanel.setLayout(null);
		
		JLabel lblNewLabel_5_2_1_1_1 = new JLabel("Edit Player Skills");
		lblNewLabel_5_2_1_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_5_2_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel_5_2_1_1_1.setBounds(248, 0, 297, 105);
		editPlayerSkillsPanel.add(lblNewLabel_5_2_1_1_1);
		
		JLabel lblNewLabel_6_5_1_1 = new JLabel("First Name:");
		lblNewLabel_6_5_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_5_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_5_1_1.setBounds(38, 87, 75, 28);
		editPlayerSkillsPanel.add(lblNewLabel_6_5_1_1);
		
		txtEditSkillFirstName = new JTextField();
		txtEditSkillFirstName.setEditable(false);
		txtEditSkillFirstName.setColumns(10);
		txtEditSkillFirstName.setBounds(123, 94, 143, 20);
		editPlayerSkillsPanel.add(txtEditSkillFirstName);
		
		JLabel lblNewLabel_6_1_1_1_1 = new JLabel("Last Name:");
		lblNewLabel_6_1_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_1_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_1_1_1_1.setBounds(38, 126, 75, 28);
		editPlayerSkillsPanel.add(lblNewLabel_6_1_1_1_1);
		
		txtEditSkillLastName = new JTextField();
		txtEditSkillLastName.setEditable(false);
		txtEditSkillLastName.setColumns(10);
		txtEditSkillLastName.setBounds(123, 133, 143, 20);
		editPlayerSkillsPanel.add(txtEditSkillLastName);
		
		txtEditSkillSRUNumber = new JTextField();
		txtEditSkillSRUNumber.setEditable(false);
		txtEditSkillSRUNumber.setColumns(10);
		txtEditSkillSRUNumber.setBounds(377, 94, 143, 20);
		editPlayerSkillsPanel.add(txtEditSkillSRUNumber);
		
		JLabel lblNewLabel_6_3_4_1_1 = new JLabel("SRU Number:");
		lblNewLabel_6_3_4_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_4_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_4_1_1.setBounds(258, 87, 109, 28);
		editPlayerSkillsPanel.add(lblNewLabel_6_3_4_1_1);
		
		JLabel lblNewLabel_6_3_4_1_1_1 = new JLabel("Position");
		lblNewLabel_6_3_4_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_4_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_4_1_1_1.setBounds(258, 126, 109, 28);
		editPlayerSkillsPanel.add(lblNewLabel_6_3_4_1_1_1);
		
		txtEditSkillPosition = new JTextField();
		txtEditSkillPosition.setEditable(false);
		txtEditSkillPosition.setColumns(10);
		txtEditSkillPosition.setBounds(377, 133, 143, 20);
		editPlayerSkillsPanel.add(txtEditSkillPosition);
		
		JSeparator separator_3 = new JSeparator();
		separator_3.setBounds(0, 165, 793, 2);
		editPlayerSkillsPanel.add(separator_3);
		
		JLabel lblNewLabel_6_1_1_1_1_1 = new JLabel("Passing");
		lblNewLabel_6_1_1_1_1_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_6_1_1_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_1_1_1_1_1.setBounds(38, 217, 75, 28);
		editPlayerSkillsPanel.add(lblNewLabel_6_1_1_1_1_1);
		
		JLabel lblNewLabel_6_1_1_1_1_1_1 = new JLabel("Category");
		lblNewLabel_6_1_1_1_1_1_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_6_1_1_1_1_1_1.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblNewLabel_6_1_1_1_1_1_1.setBounds(38, 178, 75, 28);
		editPlayerSkillsPanel.add(lblNewLabel_6_1_1_1_1_1_1);
		
		JLabel lblNewLabel_6_1_1_1_1_1_1_1 = new JLabel("Skill");
		lblNewLabel_6_1_1_1_1_1_1_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_6_1_1_1_1_1_1_1.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblNewLabel_6_1_1_1_1_1_1_1.setBounds(141, 178, 75, 28);
		editPlayerSkillsPanel.add(lblNewLabel_6_1_1_1_1_1_1_1);
		
		JLabel lblNewLabel_6_1_1_1_1_1_1_1_1 = new JLabel("Skill Level");
		lblNewLabel_6_1_1_1_1_1_1_1_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_6_1_1_1_1_1_1_1_1.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblNewLabel_6_1_1_1_1_1_1_1_1.setBounds(254, 178, 75, 28);
		editPlayerSkillsPanel.add(lblNewLabel_6_1_1_1_1_1_1_1_1);
		
		JLabel lblNewLabel_6_1_1_1_1_1_1_1_1_1 = new JLabel("Notes");
		lblNewLabel_6_1_1_1_1_1_1_1_1_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_6_1_1_1_1_1_1_1_1_1.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblNewLabel_6_1_1_1_1_1_1_1_1_1.setBounds(361, 178, 89, 28);
		editPlayerSkillsPanel.add(lblNewLabel_6_1_1_1_1_1_1_1_1_1);
		
		JLabel lblNewLabel_6_1_1_1_1_1_2 = new JLabel("Standard");
		lblNewLabel_6_1_1_1_1_1_2.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_6_1_1_1_1_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_1_1_1_1_1_2.setBounds(141, 217, 75, 28);
		editPlayerSkillsPanel.add(lblNewLabel_6_1_1_1_1_1_2);
		
		JLabel lblNewLabel_6_1_1_1_1_1_2_1 = new JLabel("Spin");
		lblNewLabel_6_1_1_1_1_1_2_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_6_1_1_1_1_1_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_1_1_1_1_1_2_1.setBounds(141, 241, 75, 28);
		editPlayerSkillsPanel.add(lblNewLabel_6_1_1_1_1_1_2_1);
		
		JLabel lblNewLabel_6_1_1_1_1_1_2_2 = new JLabel("Pop");
		lblNewLabel_6_1_1_1_1_1_2_2.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_6_1_1_1_1_1_2_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_1_1_1_1_1_2_2.setBounds(141, 266, 75, 28);
		editPlayerSkillsPanel.add(lblNewLabel_6_1_1_1_1_1_2_2);
		
		JLabel lblNewLabel_6_1_1_1_1_1_3 = new JLabel("Tackling");
		lblNewLabel_6_1_1_1_1_1_3.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_6_1_1_1_1_1_3.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_1_1_1_1_1_3.setBounds(38, 301, 75, 28);
		editPlayerSkillsPanel.add(lblNewLabel_6_1_1_1_1_1_3);
		
		JLabel lblNewLabel_6_1_1_1_1_1_2_3 = new JLabel("Front");
		lblNewLabel_6_1_1_1_1_1_2_3.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_6_1_1_1_1_1_2_3.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_1_1_1_1_1_2_3.setBounds(141, 301, 75, 28);
		editPlayerSkillsPanel.add(lblNewLabel_6_1_1_1_1_1_2_3);
		
		JLabel lblNewLabel_6_1_1_1_1_1_2_1_1 = new JLabel("Rear");
		lblNewLabel_6_1_1_1_1_1_2_1_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_6_1_1_1_1_1_2_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_1_1_1_1_1_2_1_1.setBounds(141, 329, 75, 28);
		editPlayerSkillsPanel.add(lblNewLabel_6_1_1_1_1_1_2_1_1);
		
		JLabel lblNewLabel_6_1_1_1_1_1_2_2_1 = new JLabel("Side");
		lblNewLabel_6_1_1_1_1_1_2_2_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_6_1_1_1_1_1_2_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_1_1_1_1_1_2_2_1.setBounds(141, 354, 75, 28);
		editPlayerSkillsPanel.add(lblNewLabel_6_1_1_1_1_1_2_2_1);
		
		JLabel lblNewLabel_6_1_1_1_1_1_2_2_1_1 = new JLabel("Scrabble");
		lblNewLabel_6_1_1_1_1_1_2_2_1_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_6_1_1_1_1_1_2_2_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_1_1_1_1_1_2_2_1_1.setBounds(141, 377, 75, 28);
		editPlayerSkillsPanel.add(lblNewLabel_6_1_1_1_1_1_2_2_1_1);
		
		JLabel lblNewLabel_6_1_1_1_1_1_2_2_1_1_1 = new JLabel("Goal");
		lblNewLabel_6_1_1_1_1_1_2_2_1_1_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_6_1_1_1_1_1_2_2_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_1_1_1_1_1_2_2_1_1_1.setBounds(141, 488, 75, 28);
		editPlayerSkillsPanel.add(lblNewLabel_6_1_1_1_1_1_2_2_1_1_1);
		
		JLabel lblNewLabel_6_1_1_1_1_1_2_2_1_2 = new JLabel("Grubber");
		lblNewLabel_6_1_1_1_1_1_2_2_1_2.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_6_1_1_1_1_1_2_2_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_1_1_1_1_1_2_2_1_2.setBounds(141, 465, 75, 28);
		editPlayerSkillsPanel.add(lblNewLabel_6_1_1_1_1_1_2_2_1_2);
		
		JLabel lblNewLabel_6_1_1_1_1_1_2_1_1_1 = new JLabel("Punt");
		lblNewLabel_6_1_1_1_1_1_2_1_1_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_6_1_1_1_1_1_2_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_1_1_1_1_1_2_1_1_1.setBounds(141, 440, 75, 28);
		editPlayerSkillsPanel.add(lblNewLabel_6_1_1_1_1_1_2_1_1_1);
		
		JLabel lblNewLabel_6_1_1_1_1_1_2_3_1 = new JLabel("Drop");
		lblNewLabel_6_1_1_1_1_1_2_3_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_6_1_1_1_1_1_2_3_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_1_1_1_1_1_2_3_1.setBounds(141, 416, 75, 28);
		editPlayerSkillsPanel.add(lblNewLabel_6_1_1_1_1_1_2_3_1);
		
		JLabel lblNewLabel_6_1_1_1_1_1_3_1 = new JLabel("Kicking");
		lblNewLabel_6_1_1_1_1_1_3_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_6_1_1_1_1_1_3_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_1_1_1_1_1_3_1.setBounds(38, 416, 75, 28);
		editPlayerSkillsPanel.add(lblNewLabel_6_1_1_1_1_1_3_1);
		
		JSeparator separator_3_1 = new JSeparator();
		separator_3_1.setBounds(0, 206, 793, 2);
		editPlayerSkillsPanel.add(separator_3_1);
		
		JSeparator separator_4 = new JSeparator();
		separator_4.setOrientation(SwingConstants.VERTICAL);
		separator_4.setBounds(111, 178, 2, 342);
		editPlayerSkillsPanel.add(separator_4);
		
		JSeparator separator_4_1 = new JSeparator();
		separator_4_1.setOrientation(SwingConstants.VERTICAL);
		separator_4_1.setBounds(226, 178, 2, 342);
		editPlayerSkillsPanel.add(separator_4_1);
		
		JSeparator separator_4_2 = new JSeparator();
		separator_4_2.setOrientation(SwingConstants.VERTICAL);
		separator_4_2.setBounds(349, 178, 2, 342);
		editPlayerSkillsPanel.add(separator_4_2);
		
		JSeparator separator_3_1_1 = new JSeparator();
		separator_3_1_1.setBounds(113, 243, 238, 2);
		editPlayerSkillsPanel.add(separator_3_1_1);
		
		JSeparator separator_3_1_1_1 = new JSeparator();
		separator_3_1_1_1.setBounds(113, 267, 238, 2);
		editPlayerSkillsPanel.add(separator_3_1_1_1);
		
		JSeparator separator_3_1_1_2 = new JSeparator();
		separator_3_1_1_2.setBounds(111, 327, 240, 2);
		editPlayerSkillsPanel.add(separator_3_1_1_2);
		
		JSeparator separator_3_1_1_3 = new JSeparator();
		separator_3_1_1_3.setBounds(111, 355, 240, 2);
		editPlayerSkillsPanel.add(separator_3_1_1_3);
		
		JSeparator separator_3_1_1_4 = new JSeparator();
		separator_3_1_1_4.setBounds(111, 380, 240, 2);
		editPlayerSkillsPanel.add(separator_3_1_1_4);
		
		JSeparator separator_3_1_1_5 = new JSeparator();
		separator_3_1_1_5.setBounds(111, 440, 240, 2);
		editPlayerSkillsPanel.add(separator_3_1_1_5);
		
		JSeparator separator_3_1_1_6 = new JSeparator();
		separator_3_1_1_6.setBounds(111, 465, 240, 2);
		editPlayerSkillsPanel.add(separator_3_1_1_6);
		
		JSeparator separator_3_1_1_7 = new JSeparator();
		separator_3_1_1_7.setBounds(111, 491, 240, 2);
		editPlayerSkillsPanel.add(separator_3_1_1_7);
		
		JSeparator separator_3_1_2 = new JSeparator();
		separator_3_1_2.setBounds(0, 292, 793, 2);
		editPlayerSkillsPanel.add(separator_3_1_2);
		
		JSeparator separator_3_1_3 = new JSeparator();
		separator_3_1_3.setBounds(0, 403, 793, 2);
		editPlayerSkillsPanel.add(separator_3_1_3);
		
		JSeparator separator_3_1_4 = new JSeparator();
		separator_3_1_4.setBounds(0, 520, 793, 2);
		editPlayerSkillsPanel.add(separator_3_1_4);
		
		JSpinner spinEditFrontSkill = new JSpinner();
		spinEditFrontSkill.setModel(new SpinnerNumberModel(1, 1, 5, 1));
		spinEditFrontSkill.setBounds(236, 301, 93, 20);
		editPlayerSkillsPanel.add(spinEditFrontSkill);
		
		JSpinner spinEditStandardSkill = new JSpinner();
		spinEditStandardSkill.setModel(new SpinnerNumberModel(1, 1, 5, 1));
		spinEditStandardSkill.setBounds(236, 217, 93, 20);
		editPlayerSkillsPanel.add(spinEditStandardSkill);
		
		JSpinner spinEditSpinSkill = new JSpinner();
		spinEditSpinSkill.setModel(new SpinnerNumberModel(1, 1, 5, 1));
		spinEditSpinSkill.setBounds(236, 246, 93, 20);
		editPlayerSkillsPanel.add(spinEditSpinSkill);
		
		JSpinner spinEditPopSkill = new JSpinner();
		spinEditPopSkill.setModel(new SpinnerNumberModel(1, 1, 5, 1));
		spinEditPopSkill.setBounds(236, 271, 93, 20);
		editPlayerSkillsPanel.add(spinEditPopSkill);
		
		JSpinner spinEditRearSkill = new JSpinner();
		spinEditRearSkill.setModel(new SpinnerNumberModel(1, 1, 5, 1));
		spinEditRearSkill.setBounds(236, 333, 93, 20);
		editPlayerSkillsPanel.add(spinEditRearSkill);
		
		JSpinner spinEditSideSkill = new JSpinner();
		spinEditSideSkill.setModel(new SpinnerNumberModel(1, 1, 5, 1));
		spinEditSideSkill.setBounds(236, 359, 93, 20);
		editPlayerSkillsPanel.add(spinEditSideSkill);
		
		JSpinner spinEditScrabbleSkill = new JSpinner();
		spinEditScrabbleSkill.setModel(new SpinnerNumberModel(1, 1, 5, 1));
		spinEditScrabbleSkill.setBounds(236, 382, 93, 20);
		editPlayerSkillsPanel.add(spinEditScrabbleSkill);
		
		JSpinner spinEditDropSkill = new JSpinner();
		spinEditDropSkill.setModel(new SpinnerNumberModel(1, 1, 5, 1));
		spinEditDropSkill.setBounds(236, 416, 93, 20);
		editPlayerSkillsPanel.add(spinEditDropSkill);
		
		JSpinner spinEditPuntSkill = new JSpinner();
		spinEditPuntSkill.setModel(new SpinnerNumberModel(1, 1, 5, 1));
		spinEditPuntSkill.setBounds(236, 444, 93, 20);
		editPlayerSkillsPanel.add(spinEditPuntSkill);
		
		JSpinner spinEditGrubberSkill = new JSpinner();
		spinEditGrubberSkill.setModel(new SpinnerNumberModel(1, 1, 5, 1));
		spinEditGrubberSkill.setBounds(236, 469, 93, 20);
		editPlayerSkillsPanel.add(spinEditGrubberSkill);
		
		JSpinner spinEditGoalSkill = new JSpinner();
		spinEditGoalSkill.setModel(new SpinnerNumberModel(1, 1, 5, 1));
		spinEditGoalSkill.setBounds(236, 495, 93, 20);
		editPlayerSkillsPanel.add(spinEditGoalSkill);
		
		JTextArea txtEditPassingNotes = new JTextArea();
		txtEditPassingNotes.setBorder(UIManager.getBorder("TextField.border"));
		txtEditPassingNotes.setBounds(361, 217, 422, 69);
		editPlayerSkillsPanel.add(txtEditPassingNotes);
		
		JTextArea txtEditTacklingNotes = new JTextArea();
		txtEditTacklingNotes.setBorder(UIManager.getBorder("TextField.border"));
		txtEditTacklingNotes.setBounds(361, 301, 422, 91);
		editPlayerSkillsPanel.add(txtEditTacklingNotes);
		
		JTextArea txtEditKickingNotes = new JTextArea();
		txtEditKickingNotes.setBorder(UIManager.getBorder("TextField.border"));
		txtEditKickingNotes.setBounds(361, 416, 422, 91);
		editPlayerSkillsPanel.add(txtEditKickingNotes);
		
		/**
		 * Button to save the selected players skills
		 */
		JButton btnSaveNewSkills = new JButton("Save");
		btnSaveNewSkills.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Player skillPlayer;
				for (Player player: seniorList) {
					if (player.getSRUNumber().equals(txtEditSkillSRUNumber.getText())) {
						skillPlayer = player;
						message = myController.saveSeniorPlayerSkills(skillPlayer, 
								(int) spinEditStandardSkill.getValue(), (int) spinEditSpinSkill.getValue(),
								(int) spinEditPopSkill.getValue(), txtEditPassingNotes.getText(), 
								(int) spinEditFrontSkill.getValue(), (int) spinEditRearSkill.getValue(), 
								(int) spinEditSideSkill.getValue(), (int) spinEditScrabbleSkill.getValue(), 
								txtEditTacklingNotes.getText(), (int) spinEditDropSkill.getValue(), 
								(int) spinEditPuntSkill.getValue(), (int) spinEditGrubberSkill.getValue(), 
								(int) spinEditGoalSkill.getValue(), txtEditKickingNotes.getText());
						displayMessage(message);
					}
				}
				JuniorPlayer juniorPlayer;
				for (JuniorPlayer junior: juniorList) {
					if (junior.getSRUNumber().equals(txtEditSkillSRUNumber.getText())) {
						juniorPlayer = junior;
						message = myController.saveJuniorPlayerSkills(juniorPlayer, 
								(int) spinEditStandardSkill.getValue(), (int) spinEditSpinSkill.getValue(),
								(int) spinEditPopSkill.getValue(), txtEditPassingNotes.getText(), 
								(int) spinEditFrontSkill.getValue(), (int) spinEditRearSkill.getValue(), 
								(int) spinEditSideSkill.getValue(), (int) spinEditScrabbleSkill.getValue(), 
								txtEditTacklingNotes.getText(), (int) spinEditDropSkill.getValue(), 
								(int) spinEditPuntSkill.getValue(), (int) spinEditGrubberSkill.getValue(), 
								(int) spinEditGoalSkill.getValue(), txtEditKickingNotes.getText());
						displayMessage(message);
					}
				}
			}
		});
		btnSaveNewSkills.setFont(new Font("Segoe UI", Font.BOLD, 15));
		btnSaveNewSkills.setBounds(660, 525, 123, 41);
		editPlayerSkillsPanel.add(btnSaveNewSkills);
		
		JButton btnCancelNewSkills = new JButton("Cancel");
		btnCancelNewSkills.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				editPlayerSkillsPanel.setVisible(false);
				welcomePanel.setVisible(true);
			}
		});
		btnCancelNewSkills.setFont(new Font("Segoe UI", Font.BOLD, 15));
		btnCancelNewSkills.setBounds(527, 525, 123, 41);
		editPlayerSkillsPanel.add(btnCancelNewSkills);
		
		JPanel selectPlayerToEditSkillsPanel = new JPanel();
		selectPlayerToEditSkillsPanel.setLayout(null);
		selectPlayerToEditSkillsPanel.setBounds(205, 53, 793, 572);
		contentPane.add(selectPlayerToEditSkillsPanel);
		
		JLabel lblNewLabel_3_2_1 = new JLabel("Select a Player to Edit");
		lblNewLabel_3_2_1.setFont(new Font("Segoe UI", Font.BOLD, 25));
		lblNewLabel_3_2_1.setBounds(255, 11, 319, 51);
		selectPlayerToEditSkillsPanel.add(lblNewLabel_3_2_1);
		
		JList listOfPlayerSkillsToEdit = new JList(players);
		listOfPlayerSkillsToEdit.setBorder(UIManager.getBorder("TextField.border"));
		listOfPlayerSkillsToEdit.setBounds(41, 181, 213, 354);
		selectPlayerToEditSkillsPanel.add(listOfPlayerSkillsToEdit);
		
		JLabel lblNewLabel_3_1_2_1 = new JLabel("List of Players");
		lblNewLabel_3_1_2_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3_1_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 20));
		lblNewLabel_3_1_2_1.setBounds(41, 139, 213, 51);
		selectPlayerToEditSkillsPanel.add(lblNewLabel_3_1_2_1);
		
		/**
		 * Button to take the selected player from the list
		 * Sets all fields on the skill page equal to the values from the selected player
		 */
		JButton btnEditPlayerSkillSheet = new JButton("Edit Player Skills");
		btnEditPlayerSkillSheet.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Player editPlayer = null;
				try {
					editPlayer = (Player) listOfPlayerSkillsToEdit.getSelectedValue();
					txtEditSkillFirstName.setText(editPlayer.getFirstname());
					txtEditSkillLastName.setText(editPlayer.getSurname());
					txtEditSkillSRUNumber.setText(editPlayer.getSRUNumber());
					txtEditSkillPosition.setText(editPlayer.getPosition().toString());
				} catch (NullPointerException e2) {
					displayMessage("Please select a player from the list!");
				}
				
				
				try {
					skillList = editPlayer.getSkills();
					boolean checkIsNull = skillList.isEmpty();
					if (!checkIsNull) {
						for (SkillCategory skillCat: skillList) {
							if (skillCat.getCategoryName().equals("Passing")) {
								spinEditStandardSkill.setValue(skillCat.getSkillRating("Standard"));
								spinEditSpinSkill.setValue(skillCat.getSkillRating("Spin"));
								spinEditPopSkill.setValue(skillCat.getSkillRating("Pop"));
								txtEditPassingNotes.setText(skillCat.getNotes());
							} else if (skillCat.getCategoryName().equals("Tackling")) {
								spinEditFrontSkill.setValue(skillCat.getSkillRating("Front"));
								spinEditRearSkill.setValue(skillCat.getSkillRating("Rear"));
								spinEditSideSkill.setValue(skillCat.getSkillRating("Side"));
								spinEditScrabbleSkill.setValue(skillCat.getSkillRating("Scrabble"));
								txtEditTacklingNotes.setText(skillCat.getNotes());
							} else if (skillCat.getCategoryName().equals("Kicking")) {
								spinEditDropSkill.setValue(skillCat.getSkillRating("Drop"));
								spinEditPuntSkill.setValue(skillCat.getSkillRating("Punt"));
								spinEditGrubberSkill.setValue(skillCat.getSkillRating("Grubber"));
								spinEditGoalSkill.setValue(skillCat.getSkillRating("Goal"));
								txtEditKickingNotes.setText(skillCat.getNotes());
							}
							selectPlayerToEditSkillsPanel.setVisible(false);
							editPlayerSkillsPanel.setVisible(true);
						}
					} else {
						spinEditStandardSkill.setValue(1);
						spinEditSpinSkill.setValue(1);
						spinEditPopSkill.setValue(1);
						txtEditPassingNotes.setText("");

						spinEditFrontSkill.setValue(1);
						spinEditRearSkill.setValue(1);
						spinEditSideSkill.setValue(1);
						spinEditScrabbleSkill.setValue(1);
						txtEditTacklingNotes.setText("");
					
						spinEditDropSkill.setValue(1);
						spinEditPuntSkill.setValue(1);
						spinEditGrubberSkill.setValue(1);
						spinEditGoalSkill.setValue(1);
						txtEditKickingNotes.setText("");
						selectPlayerToEditSkillsPanel.setVisible(false);
						editPlayerSkillsPanel.setVisible(true);
					}
				} catch (NullPointerException e1) {
				}
				
			}
			
		});
		btnEditPlayerSkillSheet.setFont(new Font("Segoe UI", Font.BOLD, 20));
		btnEditPlayerSkillSheet.setBounds(264, 440, 257, 94);
		selectPlayerToEditSkillsPanel.add(btnEditPlayerSkillSheet);
		
		
		
		
		
		
		JPanel sidePanel = new JPanel();
		sidePanel.setBackground(Color.DARK_GRAY);
		sidePanel.setBounds(0, 0, 205, 625);
		contentPane.add(sidePanel);
		sidePanel.setLayout(null);
		
		/**
		 * Button to take the user to the add player panel
		 */
		JPanel btnAddPlayer = new JPanel();
		btnAddPlayer.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				welcomePanel.setVisible(false);
				newJuniorPlayerPanel.setVisible(false);
				newSeniorPlayerPanel.setVisible(false);
				editJuniorPlayerPanel.setVisible(false);
				editSeniorPlayerPanel.setVisible(false);
				selectPlayerToEditPanel.setVisible(false);
				editPlayerSkillsPanel.setVisible(false);
				selectPlayerToEditSkillsPanel.setVisible(false);
				
				if (loggedCoach.getSquad().getSquadCategory() == SquadCategory.junior) {
					newJuniorPlayerPanel.setVisible(true);
				} else if (loggedCoach.getSquad().getSquadCategory() == SquadCategory.senior) {
					newSeniorPlayerPanel.setVisible(true);
				}
			}
		});
		
		btnAddPlayer.setBorder(null);
		btnAddPlayer.setBackground(Color.LIGHT_GRAY);
		btnAddPlayer.setBounds(0, 111, 205, 60);
		sidePanel.add(btnAddPlayer);
		btnAddPlayer.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Add New Player");
		lblNewLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		lblNewLabel.setBounds(40, 11, 130, 38);
		btnAddPlayer.add(lblNewLabel);
		
		/**
		 * Button to take the user to the edit player details panel
		 */
		JPanel btnEditPlayerDetails = new JPanel();
		btnEditPlayerDetails.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				welcomePanel.setVisible(false);
				newJuniorPlayerPanel.setVisible(false);
				newSeniorPlayerPanel.setVisible(false);
				editJuniorPlayerPanel.setVisible(false);
				editSeniorPlayerPanel.setVisible(false);
				selectPlayerToEditPanel.setVisible(true);
				editPlayerSkillsPanel.setVisible(false);
				selectPlayerToEditSkillsPanel.setVisible(false);
				
				try {
					if (loggedCoach.getSquad().getSquadCategory() == SquadCategory.senior) {
						players.clear();
						coachesPlayerList = getSeniorCoachesList(coachesPlayerList, loggedCoach);
						for (Player coachPlayer: coachesPlayerList) {
							players.addElement(coachPlayer);
						}
					} else if (loggedCoach.getSquad().getSquadCategory() == SquadCategory.junior) {
						players.clear();
						coachesJuniorPlayerList = getJuniorCoachesList(coachesJuniorPlayerList, loggedCoach);
						for (JuniorPlayer coachPlayer: coachesJuniorPlayerList) {
							players.addElement(coachPlayer);
						}
					}
				} catch (NullPointerException e1) {
					e1.printStackTrace();
				}
				
			}
		});
		btnEditPlayerDetails.setBorder(null);
		btnEditPlayerDetails.setLayout(null);
		btnEditPlayerDetails.setBackground(Color.GRAY);
		btnEditPlayerDetails.setBounds(0, 171, 205, 60);
		sidePanel.add(btnEditPlayerDetails);
		
		JLabel lblNewLabel_1 = new JLabel("Edit Player Details");
		lblNewLabel_1.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(41, 11, 154, 38);
		btnEditPlayerDetails.add(lblNewLabel_1);
		
		/**
		 * Button to take the user to the edit player skills panel
		 */
		JPanel btnEditPlayerSkills = new JPanel();
		btnEditPlayerSkills.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				welcomePanel.setVisible(false);
				newJuniorPlayerPanel.setVisible(false);
				newSeniorPlayerPanel.setVisible(false);
				editJuniorPlayerPanel.setVisible(false);
				editSeniorPlayerPanel.setVisible(false);
				selectPlayerToEditPanel.setVisible(false);
				editPlayerSkillsPanel.setVisible(false);
				selectPlayerToEditSkillsPanel.setVisible(true);

				try {
					if (loggedCoach.getSquad().getSquadCategory() == SquadCategory.senior) {
						players.clear();
						coachesPlayerList = getSeniorCoachesList(coachesPlayerList, loggedCoach);
						for (Player coachPlayer: coachesPlayerList) {
							players.addElement(coachPlayer);
						}
					} else if (loggedCoach.getSquad().getSquadCategory() == SquadCategory.junior) {
						players.clear();
						coachesJuniorPlayerList = getJuniorCoachesList(coachesJuniorPlayerList, loggedCoach);
						for (JuniorPlayer coachPlayer: coachesJuniorPlayerList) {
							players.addElement(coachPlayer);
						}
					}
				} catch (NullPointerException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnEditPlayerSkills.setLayout(null);
		btnEditPlayerSkills.setBackground(Color.LIGHT_GRAY);
		btnEditPlayerSkills.setBounds(0, 231, 205, 60);
		sidePanel.add(btnEditPlayerSkills);
		
		JLabel lblNewLabel_1_1 = new JLabel("Edit Player Skills");
		lblNewLabel_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		lblNewLabel_1_1.setBounds(41, 11, 130, 38);
		btnEditPlayerSkills.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_2 = new JLabel("Simply Rugby");
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setFont(new Font("Segoe UI", Font.BOLD | Font.ITALIC, 25));
		lblNewLabel_2.setBounds(20, 42, 185, 37);
		sidePanel.add(lblNewLabel_2);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(20, 90, 161, 2);
		sidePanel.add(separator);
		
		/**
		 * Button to log the user out
		 */
		JPanel btnLogout = new JPanel();
		btnLogout.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				myController.logout();
			}
		});
		btnLogout.setLayout(null);
		btnLogout.setBackground(Color.LIGHT_GRAY);
		btnLogout.setBounds(0, 565, 205, 60);
		sidePanel.add(btnLogout);
		
		JLabel lblLogout = new JLabel("Logout");
		lblLogout.setHorizontalAlignment(SwingConstants.CENTER);
		lblLogout.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		lblLogout.setBounds(40, 11, 130, 38);
		btnLogout.add(lblLogout);
		
		welcomePanel.setVisible(true);
		selectPlayerToEditPanel.setVisible(false);
		editPlayerSkillsPanel.setVisible(false);
		selectPlayerToEditSkillsPanel.setVisible(false);
	}
	
	/**
	 * Display message.
	 *
	 * @param message the message
	 */
	private void displayMessage(String message) {
		JOptionPane.showMessageDialog(this, message);
	}
	
	
	/**
	 * Gets the senior coaches list.
	 *
	 * @param coachesPlayerList the coaches player list
	 * @param loggedCoach the logged coach
	 * @return the senior coaches list
	 */
	private ArrayList<Player> getSeniorCoachesList (ArrayList<Player> coachesPlayerList, Member loggedCoach) {
		coachesPlayerList.clear();
		for (Player player: seniorList) {
			if (player.getSquad().toString().equals(loggedCoach.getSquad().toString())) {
				coachesPlayerList.add(player);
			}
		}
		return coachesPlayerList;
	}
	
	/**
	 * Adds the new player to senior coaches list.
	 *
	 * @param newSenior the new senior
	 */
	private void addToSeniorCoachesList (Player newSenior) {
		this.coachesPlayerList.add(newSenior);
	}
	
	/**
	 * Gets the junior coaches list.
	 *
	 * @param coachesJuniorList the coaches junior list
	 * @param loggedCoach the logged coach
	 * @return the junior coaches list
	 */
	private ArrayList<JuniorPlayer> getJuniorCoachesList (ArrayList<JuniorPlayer> coachesJuniorList, Member loggedCoach) {
		coachesJuniorList.clear();
		for (JuniorPlayer player: juniorList) {
			if (player.getSquad().toString().equals(loggedCoach.getSquad().toString())) {
				coachesJuniorList.add(player);
			}
		}
		return coachesJuniorList;
	}
	
	/**
	 * Edits the senior coaches list.
	 *
	 * @param coachesPlayerList the coaches player list
	 * @param loggedCoach the logged coach
	 * @return the coaches senior list
	 */
	private ArrayList<Player> editSeniorCoachesList (ArrayList<Player> coachesPlayerList, Member loggedCoach) {
		int i = 0;
		for (Player player: seniorList) {
			if (player.getSquad().toString().equals(loggedCoach.getSquad().toString())) {
				coachesPlayerList.set(i, player);
			}
			i++;
		}
		return coachesPlayerList;
	}
	
	/**
	 * Edits the junior coaches list.
	 *
	 * @param coachesJuniorList the coaches junior list
	 * @param loggedCoach the logged coach
	 * @return the coaches senior list
	 */
	private ArrayList<JuniorPlayer> editJuniorCoachesList (ArrayList<JuniorPlayer> coachesJuniorList, Member loggedCoach) {
		int i = 0;
		for (JuniorPlayer player: juniorList) {
			if (player.getSquad().toString().equals(loggedCoach.getSquad().toString())) {
				coachesJuniorList.set(i, player);
			}
			i++;
		}
		return coachesJuniorList;
	}
}

package userInterfaces;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import enums.Position;
import enums.SquadCategory;
import models.JuniorPlayer;
import models.Member;
import models.Player;
import models.Squad;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.BoxLayout;
import javax.swing.ComboBoxModel;
import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.Image;
import java.awt.Point;

import javax.swing.JSeparator;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.event.MouseMotionAdapter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.UIManager;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JCheckBox;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.DefaultComboBoxModel;
/**
 * 
 * @author Liam Irvine
 * Class AdminScreen inherits JFrame
 */
public class AdminScreen extends JFrame {
	
	/**
	 * Initialises variables for each field created.
	 */
	private JPanel contentPane;
	private static Point point = new Point();
	private Controller myController;
	private String message;
	private JTextField txtNewCoachFirstName;
	private JTextField txtNewCoachLastName;
	private JTextField txtNewCoachPostcode;
	private JTextField txtNewCoachSRU;
	private JTextField txtNewCoachDOB;
	private JTextField txtNewCoachPhone;
	private JTextField txtNewCoachEmail;
	private JTextField txtEditCoachFirstName;
	private JTextField txtEditCoachLastName;
	private JTextField txtEditCoachPostcode;
	private JTextField txtEditCoachSRUNumber;
	private JTextField txtEditCoachDOB;
	private JTextField txtEditCoachPhone;
	private JTextField txtEditCoachEmail;
	private JTextField txtViewCoachFirstName;
	private JTextField txtViewCoachLastName;
	private JTextField txtViewCoachPostcode;
	private JTextField txtViewCoachSRUNumber;
	private JTextField txtViewCoachDOB;
	private JTextField txtViewCoachPhone;
	private JTextField txtViewCoachEmail;
	private JTextField txtViewCoachSquad;
	private JTextField txtNewSquadName;
	private JTextField txtEditSquadName;
	private JTextField txtNewJuniorFirstName;
	private JTextField txtNewJuniorLastName;
	private JTextField txtNewJuniorSRUNumber;
	private JTextField txtNewJuniorDOB;
	private JTextField txtNewJuniorPhone;
	private JTextField txtNewJuniorEmail;
	private JTextField txtNewJuniorDoctor;
	private JTextField txtNewJuniorDoctorPhone;
	private JTextField txtNewJuniorGuardian1Name;
	private JTextField txtNewJuniorRelationship1;
	private JTextField txtNewGuardian1Phone;
	private JTextField txtNewJuniorGuardian2Phone;
	private JTextField txtNewJuniorRelationship2;
	private JTextField txtNewJuniorGuardian2Name;
	private JTextField txtNewSeniorFirstName;
	private JTextField txtNewSeniorLastName;
	private JTextField txtNewSeniorSRUNumber;
	private JTextField txtNewSeniorDOB;
	private JTextField txtNewSeniorPhone;
	private JTextField txtNewSeniorEmail;
	private JTextField txtNewSeniorNOKName;
	private JTextField txtNewSeniorNOKPhone;
	private JTextField txtNewSeniorDoctorName;
	private JTextField txtNewSeniorDoctorPhone;
	private JTextField txtEditJuniorFirstName;
	private JTextField txtEditJuniorLastName;
	private JTextField txtEditJuniorSRUNumber;
	private JTextField txtEditJuniorDOB;
	private JTextField txtEditJuniorPhone;
	private JTextField txtEditJuniorEmail;
	private JTextField txtEditJuniorDoctorName;
	private JTextField txtEditJuniorDoctorPhone;
	private JTextField txtEditJuniorGuardian1Name;
	private JTextField txtEditJuniorRelationship1;
	private JTextField txtEditJuniorGuardian1Phone;
	private JTextField txtEditJuniorGuardian2Phone;
	private JTextField txtEditJuniorRelationship2;
	private JTextField txtEditJuniorGuardian2Name;
	private JTextField txtEditSeniorFirstName;
	private JTextField txtEditSeniorLastName;
	private JTextField txtEditSeniorSRUNumber;
	private JTextField txtEditSeniorDOB;
	private JTextField txtEditSeniorPhone;
	private JTextField txtEditSeniorEmail;
	private JTextField txtEditSeniorNOKName;
	private JTextField txtEditSeniorNOKPhone;
	private JTextField txtEditSeniorDoctorName;
	private JTextField txtEditSeniorDoctorPhone;
	private JTextField txtViewJuniorFirstName;
	private JTextField txtViewJuniorLastName;
	private JTextField txtViewJuniorSRUNumber;
	private JTextField txtViewJuniorDOB;
	private JTextField txtViewJuniorPhone;
	private JTextField txtViewJuniorEmail;
	private JTextField txtViewJuniorDoctorName;
	private JTextField txtViewJuniorDoctorPhone;
	private JTextField txtViewJuniorGuardian1Name;
	private JTextField txtViewJuniorRelationship1;
	private JTextField txtViewJuniorGuardian1Phone;
	private JTextField txtViewJuniorGuardian2Phone;
	private JTextField txtViewJuniorRelationship2;
	private JTextField txtViewJuniorGuardian2Name;
	private JTextField txtViewJuniorPosition;
	private JTextField txtViewJuniorSquad;
	private JTextField txtViewSeniorFirstName;
	private JTextField txtViewSeniorLastName;
	private JTextField txtViewSeniorSRUNumber;
	private JTextField txtViewSeniorDOB;
	private JTextField txtViewSeniorPhone;
	private JTextField txtViewSeniorEmail;
	private JTextField txtViewSeniorNOKName;
	private JTextField txtViewSeniorNOKPhone;
	private JTextField txtViewSeniorDoctorName;
	private JTextField txtViewSeniorDoctorPhone;
	private JTextField txtViewSeniorPosition;
	private JTextField txtViewSeniorSquad;
	private JTextField txtNewCoachUsername;
	private JTextField txtNewCoachPassword;
	private JTextField txtEditCoachUsername;
	private JTextField txtEditCoachPassword;
	private JTextField txtViewCoachPassword;
	private JTextField txtViewCoachUsername;
	private JTextField txtNewSeniorPostcode;
	private JTextField txtNewJuniorPostcode;
	private JTextField txtEditJuniorPostcode;
	private JTextField txtEditSeniorPostcode;
	private JTextField txtViewJuniorPostcode;
	private JTextField txtViewSeniorPostcode;

	/**
	 * Create the frame.
	 */
	public AdminScreen(Controller newController) {
		myController = newController;
		ArrayList<Squad> squadList = myController.getSquadList();
		ArrayList<Player> playerList = myController.getSeniorList();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/MM/yyyy");
		setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 998, 625);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		ImageIcon background = (new ImageIcon(AdminScreen.class.getResource("/images/background.jpg")));
		Image img = background.getImage();
		Image imgScale = img.getScaledInstance(793, 625, Image.SCALE_SMOOTH);
		ImageIcon scaledIcon = new ImageIcon(imgScale);
		
		JPanel welcomePanel = new JPanel();
		welcomePanel.setBounds(205, 53, 793, 572);
		contentPane.add(welcomePanel);
		welcomePanel.setLayout(null);
		
		JLabel lblBackground = new JLabel("");
		lblBackground.setIcon(scaledIcon);
		lblBackground.setBounds(0, 0, 793, 625);
		welcomePanel.add(lblBackground);
		
		
		/**
		 * Adds functionality to title bar
		 */
		JPanel titleBar = new JPanel();
		titleBar.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				point.x = e.getX();
                point.y = e.getY();
			}
		});
		titleBar.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseDragged(MouseEvent e) {
				Point p = getLocation();
                setLocation(p.x + e.getX() - point.x, p.y + e.getY() - point.y);
			}
		});
		titleBar.setBackground(Color.LIGHT_GRAY);
		titleBar.setBounds(205, 0, 793, 53);
		contentPane.add(titleBar);
		titleBar.setLayout(null);
		
		/**
		 * Adds functionality to close the program
		 */
		JLabel lblExit = new JLabel("X");
		lblExit.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				System.exit(0);
			}
		});
		lblExit.setHorizontalAlignment(SwingConstants.CENTER);
		lblExit.setForeground(Color.WHITE);
		lblExit.setFont(new Font("Segoe UI", Font.BOLD, 25));
		lblExit.setBounds(745, 0, 48, 53);
		titleBar.add(lblExit);
		
		JLabel lblNewLabel_10 = new JLabel("Administrator Application");
		lblNewLabel_10.setForeground(Color.WHITE);
		lblNewLabel_10.setFont(new Font("Segoe UI", Font.BOLD, 25));
		lblNewLabel_10.setBounds(10, 11, 410, 31);
		titleBar.add(lblNewLabel_10);
		
		JPanel editExistingCoachPanel = new JPanel();
		editExistingCoachPanel.setLayout(null);
		editExistingCoachPanel.setBounds(205, 53, 793, 572);
		contentPane.add(editExistingCoachPanel);
		
		JLabel lblNewLabel_3_1 = new JLabel("Edit Existing Coach");
		lblNewLabel_3_1.setFont(new Font("Segoe UI", Font.BOLD, 25));
		lblNewLabel_3_1.setBounds(265, 26, 295, 52);
		editExistingCoachPanel.add(lblNewLabel_3_1);
		
		JLabel lblNewLabel_4_4 = new JLabel("First Name:");
		lblNewLabel_4_4.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_4_4.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_4_4.setBounds(70, 160, 75, 25);
		editExistingCoachPanel.add(lblNewLabel_4_4);
		
		txtEditCoachFirstName = new JTextField();
		txtEditCoachFirstName.setColumns(10);
		txtEditCoachFirstName.setBounds(155, 163, 129, 20);
		editExistingCoachPanel.add(txtEditCoachFirstName);
		
		JLabel lblNewLabel_4_1_2 = new JLabel("Last Name:");
		lblNewLabel_4_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_4_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_4_1_2.setBounds(70, 196, 75, 25);
		editExistingCoachPanel.add(lblNewLabel_4_1_2);
		
		txtEditCoachLastName = new JTextField();
		txtEditCoachLastName.setColumns(10);
		txtEditCoachLastName.setBounds(155, 199, 129, 20);
		editExistingCoachPanel.add(txtEditCoachLastName);
		
		JLabel lblNewLabel_4_2_1 = new JLabel("Address:");
		lblNewLabel_4_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_4_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_4_2_1.setBounds(70, 232, 75, 25);
		editExistingCoachPanel.add(lblNewLabel_4_2_1);
		
		JLabel lblNewLabel_4_1_1_1 = new JLabel("Postcode:");
		lblNewLabel_4_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_4_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_4_1_1_1.setBounds(70, 340, 75, 25);
		editExistingCoachPanel.add(lblNewLabel_4_1_1_1);
		
		txtEditCoachPostcode = new JTextField();
		txtEditCoachPostcode.setColumns(10);
		txtEditCoachPostcode.setBounds(155, 343, 129, 20);
		editExistingCoachPanel.add(txtEditCoachPostcode);
		
		JLabel lblNewLabel_4_3_4 = new JLabel("SRU Number:");
		lblNewLabel_4_3_4.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_4_3_4.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_4_3_4.setBounds(424, 160, 104, 25);
		editExistingCoachPanel.add(lblNewLabel_4_3_4);
		
		txtEditCoachSRUNumber = new JTextField();
		txtEditCoachSRUNumber.setEditable(false);
		txtEditCoachSRUNumber.setColumns(10);
		txtEditCoachSRUNumber.setBounds(538, 163, 129, 20);
		editExistingCoachPanel.add(txtEditCoachSRUNumber);
		
		JLabel lblNewLabel_4_3_1_1 = new JLabel("Date of Birth:");
		lblNewLabel_4_3_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_4_3_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_4_3_1_1.setBounds(424, 196, 104, 25);
		editExistingCoachPanel.add(lblNewLabel_4_3_1_1);
		
		txtEditCoachDOB = new JTextField();
		txtEditCoachDOB.setColumns(10);
		txtEditCoachDOB.setBounds(538, 199, 129, 20);
		editExistingCoachPanel.add(txtEditCoachDOB);
		
		JLabel lblNewLabel_4_3_2_1 = new JLabel("Phone Number:");
		lblNewLabel_4_3_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_4_3_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_4_3_2_1.setBounds(424, 232, 104, 25);
		editExistingCoachPanel.add(lblNewLabel_4_3_2_1);
		
		txtEditCoachPhone = new JTextField();
		txtEditCoachPhone.setColumns(10);
		txtEditCoachPhone.setBounds(538, 235, 129, 20);
		editExistingCoachPanel.add(txtEditCoachPhone);
		
		JLabel lblNewLabel_4_3_3_1 = new JLabel("E-Mail:");
		lblNewLabel_4_3_3_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_4_3_3_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_4_3_3_1.setBounds(424, 268, 104, 25);
		editExistingCoachPanel.add(lblNewLabel_4_3_3_1);
		
		txtEditCoachEmail = new JTextField();
		txtEditCoachEmail.setColumns(10);
		txtEditCoachEmail.setBounds(538, 271, 129, 20);
		editExistingCoachPanel.add(txtEditCoachEmail);
		
		/**
		 * Button returns user to home screen
		 */
		JButton btnCancelEditCoach = new JButton("Cancel");
		btnCancelEditCoach.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				editExistingCoachPanel.setVisible(false);
				welcomePanel.setVisible(true);
			}
		});
		btnCancelEditCoach.setFont(new Font("Segoe UI", Font.BOLD, 25));
		btnCancelEditCoach.setBounds(202, 470, 157, 59);
		editExistingCoachPanel.add(btnCancelEditCoach);
		
		JTextArea txtEditCoachAddress = new JTextArea();
		txtEditCoachAddress.setWrapStyleWord(true);
		txtEditCoachAddress.setLineWrap(true);
		txtEditCoachAddress.setBorder(UIManager.getBorder("TextField.border"));
		txtEditCoachAddress.setBounds(155, 233, 129, 99);
		editExistingCoachPanel.add(txtEditCoachAddress);
		
		
		
		JComboBox cmbEditCoachSquad = new JComboBox(myController.getSquadList().toArray());
		cmbEditCoachSquad.setBounds(538, 342, 129, 22);
		editExistingCoachPanel.add(cmbEditCoachSquad);
		
		JLabel lblNewLabel_4_3_3_1_1 = new JLabel("Squad:");
		lblNewLabel_4_3_3_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_4_3_3_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_4_3_3_1_1.setBounds(424, 340, 104, 25);
		editExistingCoachPanel.add(lblNewLabel_4_3_3_1_1);
		
		
		JLabel lblNewLabel_4_4_1 = new JLabel("Select a Coach:");
		lblNewLabel_4_4_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_4_4_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_4_4_1.setBounds(28, 101, 117, 25);
		editExistingCoachPanel.add(lblNewLabel_4_4_1);
		
		/**
		 * Allows user to select a coach
		 * Sets each text field to that coaches values
		 */
		JComboBox cmbEditCoach = new JComboBox(myController.getCoachList().toArray());
		cmbEditCoach.setBounds(155, 101, 129, 22);
		editExistingCoachPanel.add(cmbEditCoach);
		cmbEditCoach.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Member selectedCoach = (Member) cmbEditCoach.getSelectedItem();
				LocalDate selectedDOB = selectedCoach.getDateOfBirth();
				String formattedDate = selectedDOB.format(formatter);
				txtEditCoachFirstName.setText(selectedCoach.getFirstname());
				txtEditCoachLastName.setText(selectedCoach.getSurname());
				txtEditCoachPostcode.setText(selectedCoach.getPostCode());
				txtEditCoachSRUNumber.setText(selectedCoach.getSRUNumber());
				txtEditCoachDOB.setText(formattedDate);
				txtEditCoachPhone.setText(selectedCoach.getPhone());
				txtEditCoachEmail.setText(selectedCoach.getEmail());
				txtEditCoachAddress.setText(selectedCoach.getAddress());
				cmbEditCoachSquad.setSelectedItem(selectedCoach.getSquad());
				txtEditCoachUsername.setText(selectedCoach.getUsername());
				txtEditCoachPassword.setText(selectedCoach.getPassword());
			}
		});
		
		JLabel lblNewLabel_4_5_1 = new JLabel("Username:");
		lblNewLabel_4_5_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_4_5_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_4_5_1.setBounds(453, 89, 75, 25);
		editExistingCoachPanel.add(lblNewLabel_4_5_1);
		
		txtEditCoachUsername = new JTextField();
		txtEditCoachUsername.setColumns(10);
		txtEditCoachUsername.setBounds(538, 92, 129, 20);
		editExistingCoachPanel.add(txtEditCoachUsername);
		
		JLabel lblNewLabel_4_6_1 = new JLabel("Password");
		lblNewLabel_4_6_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_4_6_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_4_6_1.setBounds(453, 125, 75, 25);
		editExistingCoachPanel.add(lblNewLabel_4_6_1);
		
		txtEditCoachPassword = new JTextField();
		txtEditCoachPassword.setColumns(10);
		txtEditCoachPassword.setBounds(538, 128, 129, 20);
		editExistingCoachPanel.add(txtEditCoachPassword);
		
		
		
		/**
		 * Button to Edit selected coach with new values
		 */
		JButton btnSubmitEditCoach = new JButton("Submit");
		btnSubmitEditCoach.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					String DOB = txtEditCoachDOB.getText();
					message = myController.editCoach(txtEditCoachFirstName.getText(), txtEditCoachLastName.getText(), 
							txtEditCoachUsername.getText(), txtEditCoachPassword.getText(), 
							false, txtEditCoachPostcode.getText(), txtEditCoachAddress.getText(), 
							LocalDate.parse(DOB, formatter), txtEditCoachEmail.getText(),
							txtEditCoachPhone.getText(), txtEditCoachSRUNumber.getText(), true, (Squad) cmbEditCoachSquad.getSelectedItem());
					displayMessage(message);
				} catch (DateTimeParseException e1) {
					JFrame f = new JFrame();
					JOptionPane.showMessageDialog(f, "Please insert a correct date (DD/MM/YYYY)");
				} catch (Exception e2) {
					JFrame f = new JFrame();
					JOptionPane.showMessageDialog(f, "Please insert correct data in all boxes!");
				}
				cmbEditCoach.setModel(new DefaultComboBoxModel(myController.getCoachList().toArray()));
			}
		});
		btnSubmitEditCoach.setFont(new Font("Segoe UI", Font.BOLD, 25));
		btnSubmitEditCoach.setBounds(439, 470, 157, 59);
		editExistingCoachPanel.add(btnSubmitEditCoach);
		editExistingCoachPanel.setVisible(false);
		editExistingCoachPanel.setVisible(false);
		
		JPanel newCoachPanel = new JPanel();
		newCoachPanel.setBounds(205, 53, 793, 572);
		contentPane.add(newCoachPanel);
		newCoachPanel.setLayout(null);
		
		JLabel lblNewLabel_3 = new JLabel("Coach Registration Form");
		lblNewLabel_3.setFont(new Font("Segoe UI", Font.BOLD, 25));
		lblNewLabel_3.setBounds(246, 25, 295, 52);
		newCoachPanel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("First Name:");
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_4.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_4.setBounds(70, 160, 75, 25);
		newCoachPanel.add(lblNewLabel_4);
		
		txtNewCoachFirstName = new JTextField();
		txtNewCoachFirstName.setBounds(155, 163, 129, 20);
		newCoachPanel.add(txtNewCoachFirstName);
		txtNewCoachFirstName.setColumns(10);
		
		JLabel lblNewLabel_4_1 = new JLabel("Last Name:");
		lblNewLabel_4_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_4_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_4_1.setBounds(70, 196, 75, 25);
		newCoachPanel.add(lblNewLabel_4_1);
		
		txtNewCoachLastName = new JTextField();
		txtNewCoachLastName.setColumns(10);
		txtNewCoachLastName.setBounds(155, 199, 129, 20);
		newCoachPanel.add(txtNewCoachLastName);
		
		JLabel lblNewLabel_4_2 = new JLabel("Address:");
		lblNewLabel_4_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_4_2.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_4_2.setBounds(70, 232, 75, 25);
		newCoachPanel.add(lblNewLabel_4_2);
		
		JLabel lblNewLabel_4_1_1 = new JLabel("Postcode:");
		lblNewLabel_4_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_4_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_4_1_1.setBounds(70, 340, 75, 25);
		newCoachPanel.add(lblNewLabel_4_1_1);
		
		txtNewCoachPostcode = new JTextField();
		txtNewCoachPostcode.setColumns(10);
		txtNewCoachPostcode.setBounds(155, 343, 129, 20);
		newCoachPanel.add(txtNewCoachPostcode);
		
		JLabel lblNewLabel_4_3 = new JLabel("SRU Number:");
		lblNewLabel_4_3.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_4_3.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_4_3.setBounds(424, 160, 104, 25);
		newCoachPanel.add(lblNewLabel_4_3);
		
		txtNewCoachSRU = new JTextField();
		txtNewCoachSRU.setColumns(10);
		txtNewCoachSRU.setBounds(538, 163, 129, 20);
		newCoachPanel.add(txtNewCoachSRU);
		
		JLabel lblNewLabel_4_3_1 = new JLabel("Date of Birth:");
		lblNewLabel_4_3_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_4_3_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_4_3_1.setBounds(424, 196, 104, 25);
		newCoachPanel.add(lblNewLabel_4_3_1);
		
		txtNewCoachDOB = new JTextField();
		txtNewCoachDOB.setColumns(10);
		txtNewCoachDOB.setBounds(538, 199, 129, 20);
		newCoachPanel.add(txtNewCoachDOB);
		
		JLabel lblNewLabel_4_3_2 = new JLabel("Phone Number:");
		lblNewLabel_4_3_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_4_3_2.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_4_3_2.setBounds(424, 232, 104, 25);
		newCoachPanel.add(lblNewLabel_4_3_2);
		
		txtNewCoachPhone = new JTextField();
		txtNewCoachPhone.setColumns(10);
		txtNewCoachPhone.setBounds(538, 235, 129, 20);
		newCoachPanel.add(txtNewCoachPhone);
		
		JLabel lblNewLabel_4_3_3 = new JLabel("E-Mail:");
		lblNewLabel_4_3_3.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_4_3_3.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_4_3_3.setBounds(424, 268, 104, 25);
		newCoachPanel.add(lblNewLabel_4_3_3);
		
		txtNewCoachEmail = new JTextField();
		txtNewCoachEmail.setColumns(10);
		txtNewCoachEmail.setBounds(538, 271, 129, 20);
		newCoachPanel.add(txtNewCoachEmail);
		
		/**
		 * Button to take user back to home screen
		 */
		JButton btnCancelNewCoach = new JButton("Cancel");
		btnCancelNewCoach.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				newCoachPanel.setVisible(false);
				welcomePanel.setVisible(true);
			}
		});
		btnCancelNewCoach.setFont(new Font("Segoe UI", Font.BOLD, 25));
		btnCancelNewCoach.setBounds(202, 470, 157, 59);
		newCoachPanel.add(btnCancelNewCoach);
		
		JTextArea txtNewCoachAddress = new JTextArea();
		txtNewCoachAddress.setBorder(UIManager.getBorder("TextField.border"));
		txtNewCoachAddress.setBounds(155, 233, 129, 99);
		txtNewCoachAddress.setLineWrap(true);
		txtNewCoachAddress.setWrapStyleWord(true);
		newCoachPanel.add(txtNewCoachAddress);
		
		JComboBox cmbNewCoachSquad = new JComboBox(myController.getSquadList().toArray());
		cmbNewCoachSquad.setBounds(538, 342, 129, 22);
		newCoachPanel.add(cmbNewCoachSquad);
		
		JLabel lblNewLabel_4_3_3_2 = new JLabel("Squad:");
		lblNewLabel_4_3_3_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_4_3_3_2.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_4_3_3_2.setBounds(424, 340, 104, 25);
		newCoachPanel.add(lblNewLabel_4_3_3_2);
		
		JLabel lblNewLabel_4_5 = new JLabel("Username:");
		lblNewLabel_4_5.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_4_5.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_4_5.setBounds(70, 88, 75, 25);
		newCoachPanel.add(lblNewLabel_4_5);
		
		txtNewCoachUsername = new JTextField();
		txtNewCoachUsername.setColumns(10);
		txtNewCoachUsername.setBounds(155, 91, 129, 20);
		newCoachPanel.add(txtNewCoachUsername);
		
		JLabel lblNewLabel_4_6 = new JLabel("Password");
		lblNewLabel_4_6.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_4_6.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_4_6.setBounds(70, 124, 75, 25);
		newCoachPanel.add(lblNewLabel_4_6);
		
		txtNewCoachPassword = new JTextField();
		txtNewCoachPassword.setColumns(10);
		txtNewCoachPassword.setBounds(155, 127, 129, 20);
		newCoachPanel.add(txtNewCoachPassword);
		
		/**
		 * Button to add a new coach with values in text fields
		 */
		JButton btnSubmitNewCoach = new JButton("Submit");
		btnSubmitNewCoach.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					String DOB = txtNewCoachDOB.getText();
					message = myController.createNewCoach(txtNewCoachFirstName.getText(), txtNewCoachLastName.getText(), 
							txtNewCoachUsername.getText(), txtNewCoachPassword.getText(), 
							false, txtNewCoachPostcode.getText(), txtNewCoachAddress.getText(), 
							LocalDate.parse(DOB, formatter), txtNewCoachEmail.getText(),
							txtNewCoachPhone.getText(), txtNewCoachSRU.getText(), true, (Squad) cmbNewCoachSquad.getSelectedItem());
					displayMessage(message);
				} catch (DateTimeParseException e1) {
					JFrame f = new JFrame();
					JOptionPane.showMessageDialog(f, "Please insert a correct date (DD/MM/YYYY)");
				} catch (Exception e2) {
					JFrame f = new JFrame();
					JOptionPane.showMessageDialog(f, "Please insert correct data in all boxes!");
				}
				
				cmbEditCoach.setModel(new DefaultComboBoxModel(myController.getCoachList().toArray()));
			}
		});
		btnSubmitNewCoach.setFont(new Font("Segoe UI", Font.BOLD, 25));
		btnSubmitNewCoach.setBounds(439, 470, 157, 59);
		newCoachPanel.add(btnSubmitNewCoach);
		newCoachPanel.setVisible(false);
		newCoachPanel.setVisible(false);
		
		JPanel newJuniorPlayerPanel = new JPanel();
		newJuniorPlayerPanel.setLayout(null);
		newJuniorPlayerPanel.setBounds(205, 53, 793, 572);
		contentPane.add(newJuniorPlayerPanel);
		
		JLabel lblNewLabel_5_2_2 = new JLabel("Add New Player");
		lblNewLabel_5_2_2.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel_5_2_2.setBounds(302, 11, 245, 105);
		newJuniorPlayerPanel.add(lblNewLabel_5_2_2);
		
		JLabel lblNewLabel_6_6 = new JLabel("First Name:");
		lblNewLabel_6_6.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_6.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_6.setBounds(10, 88, 75, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_6);
		
		txtNewJuniorFirstName = new JTextField();
		txtNewJuniorFirstName.setColumns(10);
		txtNewJuniorFirstName.setBounds(95, 96, 143, 20);
		newJuniorPlayerPanel.add(txtNewJuniorFirstName);
		
		JLabel lblNewLabel_6_1_2 = new JLabel("Last Name:");
		lblNewLabel_6_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_1_2.setBounds(10, 127, 75, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_1_2);
		
		txtNewJuniorLastName = new JTextField();
		txtNewJuniorLastName.setColumns(10);
		txtNewJuniorLastName.setBounds(95, 134, 143, 20);
		newJuniorPlayerPanel.add(txtNewJuniorLastName);
		
		JLabel lblNewLabel_6_2_3 = new JLabel("Address:");
		lblNewLabel_6_2_3.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_2_3.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_2_3.setBounds(10, 166, 75, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_2_3);
		
		JTextArea txtNewJuniorAddress = new JTextArea();
		txtNewJuniorAddress.setBorder(UIManager.getBorder("TextField.border"));
		txtNewJuniorAddress.setBounds(95, 171, 143, 64);
		newJuniorPlayerPanel.add(txtNewJuniorAddress);
		
		txtNewJuniorSRUNumber = new JTextField();
		txtNewJuniorSRUNumber.setColumns(10);
		txtNewJuniorSRUNumber.setBounds(342, 95, 143, 20);
		newJuniorPlayerPanel.add(txtNewJuniorSRUNumber);
		
		JLabel lblNewLabel_6_3_5 = new JLabel("SRU Number:");
		lblNewLabel_6_3_5.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_5.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_5.setBounds(223, 88, 109, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_3_5);
		
		txtNewJuniorDOB = new JTextField();
		txtNewJuniorDOB.setColumns(10);
		txtNewJuniorDOB.setBounds(342, 134, 143, 20);
		newJuniorPlayerPanel.add(txtNewJuniorDOB);
		
		JLabel lblNewLabel_6_3_1_2 = new JLabel("Date of Birth:");
		lblNewLabel_6_3_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_1_2.setBounds(223, 127, 109, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_3_1_2);
		
		txtNewJuniorPhone = new JTextField();
		txtNewJuniorPhone.setColumns(10);
		txtNewJuniorPhone.setBounds(614, 93, 143, 20);
		newJuniorPlayerPanel.add(txtNewJuniorPhone);
		
		JLabel lblNewLabel_6_3_2_2 = new JLabel("Phone Number:");
		lblNewLabel_6_3_2_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_2_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_2_2.setBounds(495, 86, 109, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_3_2_2);
		
		txtNewJuniorEmail = new JTextField();
		txtNewJuniorEmail.setColumns(10);
		txtNewJuniorEmail.setBounds(614, 134, 143, 20);
		newJuniorPlayerPanel.add(txtNewJuniorEmail);
		
		JLabel lblNewLabel_6_3_3_2 = new JLabel("E-mail:");
		lblNewLabel_6_3_3_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_3_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_3_2.setBounds(495, 127, 109, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_3_3_2);
		
		JSeparator separator_1_3 = new JSeparator();
		separator_1_3.setBounds(0, 319, 793, 2);
		newJuniorPlayerPanel.add(separator_1_3);
		
		txtNewJuniorDoctor = new JTextField();
		txtNewJuniorDoctor.setColumns(10);
		txtNewJuniorDoctor.setBounds(95, 339, 143, 20);
		newJuniorPlayerPanel.add(txtNewJuniorDoctor);
		
		JLabel lblNewLabel_6_4_2_2 = new JLabel("Doctor:");
		lblNewLabel_6_4_2_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_2_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_2_2.setBounds(-24, 332, 109, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_4_2_2);
		
		JLabel lblNewLabel_6_4_1_1_2 = new JLabel("Tel:");
		lblNewLabel_6_4_1_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_1_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_1_1_2.setBounds(-24, 371, 109, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_4_1_1_2);
		
		txtNewJuniorDoctorPhone = new JTextField();
		txtNewJuniorDoctorPhone.setColumns(10);
		txtNewJuniorDoctorPhone.setBounds(95, 378, 143, 20);
		newJuniorPlayerPanel.add(txtNewJuniorDoctorPhone);
		
		JLabel lblNewLabel_6_2_1_2 = new JLabel("Known Health issues:");
		lblNewLabel_6_2_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_2_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_2_1_2.setBounds(27, 410, 152, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_2_1_2);
		
		JTextArea txtNewJuniorHealthIssues = new JTextArea();
		txtNewJuniorHealthIssues.setBorder(UIManager.getBorder("TextField.border"));
		txtNewJuniorHealthIssues.setBounds(189, 415, 461, 64);
		newJuniorPlayerPanel.add(txtNewJuniorHealthIssues);
		
		JSeparator separator_1_1_2 = new JSeparator();
		separator_1_1_2.setBounds(0, 490, 793, 2);
		newJuniorPlayerPanel.add(separator_1_1_2);
		
		/**
		 * Button to take user back to home screen
		 */
		JButton btnNewJuniorCancel = new JButton("Cancel");
		btnNewJuniorCancel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				newJuniorPlayerPanel.setVisible(false);
				welcomePanel.setVisible(true);
			}
		});
		btnNewJuniorCancel.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		btnNewJuniorCancel.setBounds(568, 503, 89, 45);
		newJuniorPlayerPanel.add(btnNewJuniorCancel);
		
		JTextArea txtNewJuniorDoctorAddress = new JTextArea();
		txtNewJuniorDoctorAddress.setBorder(UIManager.getBorder("TextField.border"));
		txtNewJuniorDoctorAddress.setBounds(342, 339, 308, 60);
		newJuniorPlayerPanel.add(txtNewJuniorDoctorAddress);
		
		JLabel lblNewLabel_6_2_3_1 = new JLabel("Address:");
		lblNewLabel_6_2_3_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_2_3_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_2_3_1.setBounds(261, 332, 75, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_2_3_1);
		
		JSeparator separator_1_3_1 = new JSeparator();
		separator_1_3_1.setBounds(241, 166, 552, 2);
		newJuniorPlayerPanel.add(separator_1_3_1);
		
		JSeparator separator_2 = new JSeparator();
		separator_2.setOrientation(SwingConstants.VERTICAL);
		separator_2.setBounds(241, 166, 1, 155);
		newJuniorPlayerPanel.add(separator_2);
		
		txtNewJuniorGuardian1Name = new JTextField();
		txtNewJuniorGuardian1Name.setColumns(10);
		txtNewJuniorGuardian1Name.setBounds(342, 174, 143, 20);
		newJuniorPlayerPanel.add(txtNewJuniorGuardian1Name);
		
		JLabel lblNewLabel_6_6_1 = new JLabel("Guardian 1:");
		lblNewLabel_6_6_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_6_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_6_1.setBounds(257, 166, 75, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_6_1);
		
		txtNewJuniorRelationship1 = new JTextField();
		txtNewJuniorRelationship1.setColumns(10);
		txtNewJuniorRelationship1.setBounds(342, 210, 143, 20);
		newJuniorPlayerPanel.add(txtNewJuniorRelationship1);
		
		JLabel lblNewLabel_6_6_1_1 = new JLabel("Relationship:");
		lblNewLabel_6_6_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_6_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_6_1_1.setBounds(241, 202, 91, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_6_1_1);
		
		JLabel lblNewLabel_6_2_3_1_1 = new JLabel("Address:");
		lblNewLabel_6_2_3_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_2_3_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_2_3_1_1.setBounds(261, 234, 75, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_2_3_1_1);
		
		JTextArea txtNewGuardian1Address = new JTextArea();
		txtNewGuardian1Address.setBorder(UIManager.getBorder("TextField.border"));
		txtNewGuardian1Address.setBounds(342, 241, 143, 35);
		newJuniorPlayerPanel.add(txtNewGuardian1Address);
		
		txtNewGuardian1Phone = new JTextField();
		txtNewGuardian1Phone.setColumns(10);
		txtNewGuardian1Phone.setBounds(342, 287, 143, 20);
		newJuniorPlayerPanel.add(txtNewGuardian1Phone);
		
		JLabel lblNewLabel_6_4_1_1_2_1 = new JLabel("Tel:");
		lblNewLabel_6_4_1_1_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_1_1_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_1_1_2_1.setBounds(223, 280, 109, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_4_1_1_2_1);
		
		txtNewJuniorGuardian2Phone = new JTextField();
		txtNewJuniorGuardian2Phone.setColumns(10);
		txtNewJuniorGuardian2Phone.setBounds(614, 287, 143, 20);
		newJuniorPlayerPanel.add(txtNewJuniorGuardian2Phone);
		
		JLabel lblNewLabel_6_4_1_1_2_1_1 = new JLabel("Tel:");
		lblNewLabel_6_4_1_1_2_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_1_1_2_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_1_1_2_1_1.setBounds(495, 280, 109, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_4_1_1_2_1_1);
		
		JLabel lblNewLabel_6_2_3_1_1_1 = new JLabel("Address:");
		lblNewLabel_6_2_3_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_2_3_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_2_3_1_1_1.setBounds(533, 234, 75, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_2_3_1_1_1);
		
		JTextArea txtNewGuardian2Address = new JTextArea();
		txtNewGuardian2Address.setBorder(UIManager.getBorder("TextField.border"));
		txtNewGuardian2Address.setBounds(614, 241, 143, 35);
		newJuniorPlayerPanel.add(txtNewGuardian2Address);
		
		txtNewJuniorRelationship2 = new JTextField();
		txtNewJuniorRelationship2.setColumns(10);
		txtNewJuniorRelationship2.setBounds(614, 210, 143, 20);
		newJuniorPlayerPanel.add(txtNewJuniorRelationship2);
		
		JLabel lblNewLabel_6_6_1_1_1 = new JLabel("Relationship:");
		lblNewLabel_6_6_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_6_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_6_1_1_1.setBounds(513, 202, 91, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_6_1_1_1);
		
		JLabel lblNewLabel_6_6_1_2 = new JLabel("Guardian 2:");
		lblNewLabel_6_6_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_6_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_6_1_2.setBounds(529, 166, 75, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_6_1_2);
		
		txtNewJuniorGuardian2Name = new JTextField();
		txtNewJuniorGuardian2Name.setColumns(10);
		txtNewJuniorGuardian2Name.setBounds(614, 174, 143, 20);
		newJuniorPlayerPanel.add(txtNewJuniorGuardian2Name);
		
		JComboBox cmbNewJuniorPosition = new JComboBox();
		cmbNewJuniorPosition.setModel(new DefaultComboBoxModel(Position.values()));
		cmbNewJuniorPosition.setBounds(95, 517, 143, 22);
		newJuniorPlayerPanel.add(cmbNewJuniorPosition);
		
		JLabel lblNewLabel_6_4_1_1_2_2 = new JLabel("Position:");
		lblNewLabel_6_4_1_1_2_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_1_1_2_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_1_1_2_2.setBounds(-24, 511, 109, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_4_1_1_2_2);
		
		JComboBox cmbNewJuniorSquad = new JComboBox(myController.getJuniorSquadList().toArray());
		cmbNewJuniorSquad.setBounds(342, 517, 143, 22);
		newJuniorPlayerPanel.add(cmbNewJuniorSquad);
		
		JLabel lblNewLabel_6_4_1_1_2_2_1 = new JLabel("Squad:");
		lblNewLabel_6_4_1_1_2_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_1_1_2_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_1_1_2_2_1.setBounds(223, 511, 109, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_4_1_1_2_2_1);
		
		JLabel lblNewLabel_6_1_2_2 = new JLabel("Postcode");
		lblNewLabel_6_1_2_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_1_2_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_1_2_2.setBounds(10, 246, 75, 28);
		newJuniorPlayerPanel.add(lblNewLabel_6_1_2_2);
		
		txtNewJuniorPostcode = new JTextField();
		txtNewJuniorPostcode.setColumns(10);
		txtNewJuniorPostcode.setBounds(95, 253, 143, 20);
		newJuniorPlayerPanel.add(txtNewJuniorPostcode);
		
		/**
		 * Button to add a new junior player with values in text fields
		 */
		JButton btnNewJuniorSubmit = new JButton("Submit");
		btnNewJuniorSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String DOB = txtNewJuniorDOB.getText();
					message = myController.createNewJunior(txtNewJuniorFirstName.getText(), txtNewJuniorLastName.getText(), 
							null, null, false, txtNewJuniorPostcode.getText(), txtNewJuniorAddress.getText(), 
							LocalDate.parse(DOB, formatter), txtNewJuniorEmail.getText(),
							txtNewJuniorPhone.getText(), txtNewJuniorSRUNumber.getText(), false, (Squad) cmbNewJuniorSquad.getSelectedItem(),
							null, null, null, txtNewJuniorDoctor.getText(),
							txtNewJuniorDoctorPhone.getText(), txtNewJuniorHealthIssues.getText(), (Position) cmbNewJuniorPosition.getSelectedItem(),
							SquadCategory.junior, txtNewJuniorGuardian1Name.getText(), txtNewJuniorRelationship1.getText(), 
							txtNewGuardian1Address.getText(), txtNewGuardian1Phone.getText(), 
							txtNewJuniorGuardian2Name.getText(), txtNewJuniorRelationship2.getText(), 
							txtNewGuardian2Address.getText(), txtNewJuniorGuardian2Phone.getText(), txtNewJuniorDoctorAddress.getText());
					displayMessage(message);
				} catch (DateTimeParseException e1) {
					JFrame f = new JFrame();
					JOptionPane.showMessageDialog(f, "Please insert a correct date (DD/MM/YYYY)");
				} catch (Exception e2) {
					JFrame f = new JFrame();
					JOptionPane.showMessageDialog(f, "Please insert correct data in all boxes!");
				}
			}
		});
		btnNewJuniorSubmit.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		btnNewJuniorSubmit.setBounds(675, 503, 89, 45);
		newJuniorPlayerPanel.add(btnNewJuniorSubmit);
		newJuniorPlayerPanel.setVisible(false);
		newJuniorPlayerPanel.setVisible(false);
		
		JPanel newSeniorPlayerPanel = new JPanel();
		newSeniorPlayerPanel.setLayout(null);
		newSeniorPlayerPanel.setBounds(205, 53, 793, 572);
		contentPane.add(newSeniorPlayerPanel);
		
		JLabel lblNewLabel_5_2 = new JLabel("Add New Player");
		lblNewLabel_5_2.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel_5_2.setBounds(302, 11, 245, 105);
		newSeniorPlayerPanel.add(lblNewLabel_5_2);
		
		JLabel lblNewLabel_6 = new JLabel("First Name:");
		lblNewLabel_6.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6.setBounds(104, 108, 75, 28);
		newSeniorPlayerPanel.add(lblNewLabel_6);
		
		txtNewSeniorFirstName = new JTextField();
		txtNewSeniorFirstName.setColumns(10);
		txtNewSeniorFirstName.setBounds(189, 115, 143, 20);
		newSeniorPlayerPanel.add(txtNewSeniorFirstName);
		
		JLabel lblNewLabel_6_1 = new JLabel("Last Name:");
		lblNewLabel_6_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_1.setBounds(104, 147, 75, 28);
		newSeniorPlayerPanel.add(lblNewLabel_6_1);
		
		txtNewSeniorLastName = new JTextField();
		txtNewSeniorLastName.setColumns(10);
		txtNewSeniorLastName.setBounds(189, 154, 143, 20);
		newSeniorPlayerPanel.add(txtNewSeniorLastName);
		
		JLabel lblNewLabel_6_2 = new JLabel("Address:");
		lblNewLabel_6_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_2.setBounds(104, 186, 75, 28);
		newSeniorPlayerPanel.add(lblNewLabel_6_2);
		
		JTextArea txtNewSeniorAddress = new JTextArea();
		txtNewSeniorAddress.setBorder(UIManager.getBorder("TextField.border"));
		txtNewSeniorAddress.setBounds(189, 191, 143, 101);
		newSeniorPlayerPanel.add(txtNewSeniorAddress);
		
		txtNewSeniorSRUNumber = new JTextField();
		txtNewSeniorSRUNumber.setColumns(10);
		txtNewSeniorSRUNumber.setBounds(507, 115, 143, 20);
		newSeniorPlayerPanel.add(txtNewSeniorSRUNumber);
		
		JLabel lblNewLabel_6_3 = new JLabel("SRU Number:");
		lblNewLabel_6_3.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3.setBounds(388, 108, 109, 28);
		newSeniorPlayerPanel.add(lblNewLabel_6_3);
		
		txtNewSeniorDOB = new JTextField();
		txtNewSeniorDOB.setColumns(10);
		txtNewSeniorDOB.setBounds(507, 154, 143, 20);
		newSeniorPlayerPanel.add(txtNewSeniorDOB);
		
		JLabel lblNewLabel_6_3_1 = new JLabel("Date of Birth:");
		lblNewLabel_6_3_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_1.setBounds(388, 147, 109, 28);
		newSeniorPlayerPanel.add(lblNewLabel_6_3_1);
		
		txtNewSeniorPhone = new JTextField();
		txtNewSeniorPhone.setColumns(10);
		txtNewSeniorPhone.setBounds(507, 193, 143, 20);
		newSeniorPlayerPanel.add(txtNewSeniorPhone);
		
		JLabel lblNewLabel_6_3_2 = new JLabel("Phone Number:");
		lblNewLabel_6_3_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_2.setBounds(388, 186, 109, 28);
		newSeniorPlayerPanel.add(lblNewLabel_6_3_2);
		
		txtNewSeniorEmail = new JTextField();
		txtNewSeniorEmail.setColumns(10);
		txtNewSeniorEmail.setBounds(507, 234, 143, 20);
		newSeniorPlayerPanel.add(txtNewSeniorEmail);
		
		JLabel lblNewLabel_6_3_3 = new JLabel("E-mail:");
		lblNewLabel_6_3_3.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_3.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_3.setBounds(388, 227, 109, 28);
		newSeniorPlayerPanel.add(lblNewLabel_6_3_3);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(0, 319, 793, 2);
		newSeniorPlayerPanel.add(separator_1);
		
		JLabel lblNewLabel_6_4 = new JLabel("Next of Kin:");
		lblNewLabel_6_4.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4.setBounds(70, 332, 109, 28);
		newSeniorPlayerPanel.add(lblNewLabel_6_4);
		
		txtNewSeniorNOKName = new JTextField();
		txtNewSeniorNOKName.setColumns(10);
		txtNewSeniorNOKName.setBounds(189, 339, 143, 20);
		newSeniorPlayerPanel.add(txtNewSeniorNOKName);
		
		JLabel lblNewLabel_6_4_1 = new JLabel("Tel:");
		lblNewLabel_6_4_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_1.setBounds(70, 371, 109, 28);
		newSeniorPlayerPanel.add(lblNewLabel_6_4_1);
		
		txtNewSeniorNOKPhone = new JTextField();
		txtNewSeniorNOKPhone.setColumns(10);
		txtNewSeniorNOKPhone.setBounds(189, 378, 143, 20);
		newSeniorPlayerPanel.add(txtNewSeniorNOKPhone);
		
		txtNewSeniorDoctorName = new JTextField();
		txtNewSeniorDoctorName.setColumns(10);
		txtNewSeniorDoctorName.setBounds(507, 339, 143, 20);
		newSeniorPlayerPanel.add(txtNewSeniorDoctorName);
		
		JLabel lblNewLabel_6_4_2 = new JLabel("Doctor:");
		lblNewLabel_6_4_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_2.setBounds(388, 332, 109, 28);
		newSeniorPlayerPanel.add(lblNewLabel_6_4_2);
		
		JLabel lblNewLabel_6_4_1_1 = new JLabel("Tel:");
		lblNewLabel_6_4_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_1_1.setBounds(388, 371, 109, 28);
		newSeniorPlayerPanel.add(lblNewLabel_6_4_1_1);
		
		txtNewSeniorDoctorPhone = new JTextField();
		txtNewSeniorDoctorPhone.setColumns(10);
		txtNewSeniorDoctorPhone.setBounds(507, 378, 143, 20);
		newSeniorPlayerPanel.add(txtNewSeniorDoctorPhone);
		
		JLabel lblNewLabel_6_2_1 = new JLabel("Known Health issues:");
		lblNewLabel_6_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_2_1.setBounds(27, 410, 152, 28);
		newSeniorPlayerPanel.add(lblNewLabel_6_2_1);
		
		JTextArea txtNewSeniorHealthIssues = new JTextArea();
		txtNewSeniorHealthIssues.setBorder(UIManager.getBorder("TextField.border"));
		txtNewSeniorHealthIssues.setBounds(189, 415, 461, 64);
		newSeniorPlayerPanel.add(txtNewSeniorHealthIssues);
		
		JSeparator separator_1_1 = new JSeparator();
		separator_1_1.setBounds(0, 490, 793, 2);
		newSeniorPlayerPanel.add(separator_1_1);
		
		/**
		 * Button to take user back to home screen
		 */
		JButton btnNewSeniorCancel = new JButton("Cancel");
		btnNewSeniorCancel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				newSeniorPlayerPanel.setVisible(false);
				welcomePanel.setVisible(true);
			}
		});
		btnNewSeniorCancel.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		btnNewSeniorCancel.setBounds(568, 503, 89, 45);
		newSeniorPlayerPanel.add(btnNewSeniorCancel);
		
		JComboBox cmbNewSeniorPosition = new JComboBox();
		cmbNewSeniorPosition.setModel(new DefaultComboBoxModel(Position.values()));
		cmbNewSeniorPosition.setBounds(104, 517, 143, 22);
		newSeniorPlayerPanel.add(cmbNewSeniorPosition);
		
		JLabel lblNewLabel_6_4_1_1_2_2_2 = new JLabel("Position:");
		lblNewLabel_6_4_1_1_2_2_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_1_1_2_2_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_1_1_2_2_2.setBounds(-15, 511, 109, 28);
		newSeniorPlayerPanel.add(lblNewLabel_6_4_1_1_2_2_2);
		
		JComboBox cmbNewSeniorSquad = new JComboBox(myController.getSeniorSquadList().toArray());
		cmbNewSeniorSquad.setBounds(350, 517, 143, 22);
		newSeniorPlayerPanel.add(cmbNewSeniorSquad);
		
		JLabel lblNewLabel_6_4_1_1_2_2_2_1 = new JLabel("Squad");
		lblNewLabel_6_4_1_1_2_2_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_1_1_2_2_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_1_1_2_2_2_1.setBounds(231, 511, 109, 28);
		newSeniorPlayerPanel.add(lblNewLabel_6_4_1_1_2_2_2_1);
		
		txtNewSeniorPostcode = new JTextField();
		txtNewSeniorPostcode.setColumns(10);
		txtNewSeniorPostcode.setBounds(507, 272, 143, 20);
		newSeniorPlayerPanel.add(txtNewSeniorPostcode);
		
		JLabel lblNewLabel_6_3_3_3 = new JLabel("Postcode:");
		lblNewLabel_6_3_3_3.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_3_3.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_3_3.setBounds(388, 265, 109, 28);
		newSeniorPlayerPanel.add(lblNewLabel_6_3_3_3);
		
		/**
		 * Button to add a new senior player with values from text fields
		 */
		JButton btnNewSeniorSubmit = new JButton("Submit");
		btnNewSeniorSubmit.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					String DOB = txtNewSeniorDOB.getText();
					message = myController.createNewSenior(txtNewSeniorFirstName.getText(), txtNewSeniorLastName.getText(), 
							null, null, false, txtNewSeniorPostcode.getText(), txtNewSeniorAddress.getText(), 
							LocalDate.parse(DOB, formatter), txtNewSeniorEmail.getText(),
							txtNewSeniorPhone.getText(), txtNewSeniorSRUNumber.getText(), false, (Squad) cmbNewSeniorSquad.getSelectedItem(),
							null, txtNewSeniorNOKName.getText(), txtNewSeniorNOKPhone.getText(), txtNewSeniorDoctorName.getText(),
							txtNewSeniorDoctorPhone.getText(), txtNewSeniorHealthIssues.getText(), (Position) cmbNewSeniorPosition.getSelectedItem(),
							SquadCategory.senior);
					displayMessage(message);
				} catch (DateTimeParseException e1) {
					JFrame f = new JFrame();
					JOptionPane.showMessageDialog(f, "Please insert a correct date (DD/MM/YYYY)");
				} catch (Exception e2) {
					JFrame f = new JFrame();
					JOptionPane.showMessageDialog(f, "Please insert correct data in all boxes!");
				}
			}
		});
		btnNewSeniorSubmit.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		btnNewSeniorSubmit.setBounds(675, 503, 89, 45);
		newSeniorPlayerPanel.add(btnNewSeniorSubmit);
		newSeniorPlayerPanel.setVisible(false);
		newSeniorPlayerPanel.setVisible(false);
		
		JPanel newPlayerTypePanel = new JPanel();
		newPlayerTypePanel.setLayout(null);
		newPlayerTypePanel.setBounds(205, 53, 793, 572);
		contentPane.add(newPlayerTypePanel);
		
		JLabel lblNewLabel_5 = new JLabel("Add New Player");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel_5.setBounds(302, 11, 245, 105);
		newPlayerTypePanel.add(lblNewLabel_5);
		
		JLabel lblNewLabel_5_1 = new JLabel("Junior");
		lblNewLabel_5_1.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel_5_1.setBounds(169, 212, 115, 105);
		newPlayerTypePanel.add(lblNewLabel_5_1);
		
		JLabel lblNewLabel_5_1_1 = new JLabel("Senior");
		lblNewLabel_5_1_1.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel_5_1_1.setBounds(545, 212, 115, 105);
		newPlayerTypePanel.add(lblNewLabel_5_1_1);
		
		/**
		 * Button to take the user to the junior form screen
		 */
		JButton btnAddJunior = new JButton("Junior Form");
		btnAddJunior.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				newJuniorPlayerPanel.setVisible(true);
				newPlayerTypePanel.setVisible(false);
				cmbNewJuniorSquad.setModel(new DefaultComboBoxModel(myController.getJuniorSquadList().toArray()));
			}
		});
		btnAddJunior.setFont(new Font("Segoe UI", Font.PLAIN, 20));
		btnAddJunior.setBounds(130, 294, 160, 79);
		newPlayerTypePanel.add(btnAddJunior);
		
		/**
		 * button to take the user to the senior form screen
		 */
		JButton btnAddSenior = new JButton("Senior Form");
		btnAddSenior.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				newSeniorPlayerPanel.setVisible(true);
				newPlayerTypePanel.setVisible(false);
			}
		});
		btnAddSenior.setFont(new Font("Segoe UI", Font.PLAIN, 20));
		btnAddSenior.setBounds(507, 294, 160, 79);
		newPlayerTypePanel.add(btnAddSenior);
		newPlayerTypePanel.setVisible(false);
		
		JPanel editJuniorPlayerPanel = new JPanel();
		editJuniorPlayerPanel.setLayout(null);
		editJuniorPlayerPanel.setBounds(205, 53, 793, 572);
		contentPane.add(editJuniorPlayerPanel);
		
		JLabel lblNewLabel_5_2_2_1 = new JLabel("Edit Junior Player");
		lblNewLabel_5_2_2_1.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel_5_2_2_1.setBounds(302, 11, 245, 105);
		editJuniorPlayerPanel.add(lblNewLabel_5_2_2_1);
		
		JLabel lblNewLabel_6_6_2 = new JLabel("First Name:");
		lblNewLabel_6_6_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_6_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_6_2.setBounds(10, 88, 75, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_6_2);
		
		txtEditJuniorFirstName = new JTextField();
		txtEditJuniorFirstName.setColumns(10);
		txtEditJuniorFirstName.setBounds(95, 96, 143, 20);
		editJuniorPlayerPanel.add(txtEditJuniorFirstName);
		
		JLabel lblNewLabel_6_1_2_1 = new JLabel("Last Name:");
		lblNewLabel_6_1_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_1_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_1_2_1.setBounds(10, 127, 75, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_1_2_1);
		
		txtEditJuniorLastName = new JTextField();
		txtEditJuniorLastName.setColumns(10);
		txtEditJuniorLastName.setBounds(95, 134, 143, 20);
		editJuniorPlayerPanel.add(txtEditJuniorLastName);
		
		JLabel lblNewLabel_6_2_3_2 = new JLabel("Address:");
		lblNewLabel_6_2_3_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_2_3_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_2_3_2.setBounds(10, 166, 75, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_2_3_2);
		
		JTextArea txtEditJuniorAddress = new JTextArea();
		txtEditJuniorAddress.setBorder(UIManager.getBorder("TextField.border"));
		txtEditJuniorAddress.setBounds(95, 171, 143, 64);
		editJuniorPlayerPanel.add(txtEditJuniorAddress);
		
		txtEditJuniorSRUNumber = new JTextField();
		txtEditJuniorSRUNumber.setEditable(false);
		txtEditJuniorSRUNumber.setColumns(10);
		txtEditJuniorSRUNumber.setBounds(342, 95, 143, 20);
		editJuniorPlayerPanel.add(txtEditJuniorSRUNumber);
		
		JLabel lblNewLabel_6_3_5_1 = new JLabel("SRU Number:");
		lblNewLabel_6_3_5_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_5_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_5_1.setBounds(223, 88, 109, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_3_5_1);
		
		txtEditJuniorDOB = new JTextField();
		txtEditJuniorDOB.setColumns(10);
		txtEditJuniorDOB.setBounds(342, 134, 143, 20);
		editJuniorPlayerPanel.add(txtEditJuniorDOB);
		
		JLabel lblNewLabel_6_3_1_2_1 = new JLabel("Date of Birth:");
		lblNewLabel_6_3_1_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_1_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_1_2_1.setBounds(223, 127, 109, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_3_1_2_1);
		
		txtEditJuniorPhone = new JTextField();
		txtEditJuniorPhone.setColumns(10);
		txtEditJuniorPhone.setBounds(614, 96, 143, 20);
		editJuniorPlayerPanel.add(txtEditJuniorPhone);
		
		JLabel lblNewLabel_6_3_2_2_1 = new JLabel("Phone Number:");
		lblNewLabel_6_3_2_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_2_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_2_2_1.setBounds(495, 88, 109, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_3_2_2_1);
		
		txtEditJuniorEmail = new JTextField();
		txtEditJuniorEmail.setColumns(10);
		txtEditJuniorEmail.setBounds(614, 134, 143, 20);
		editJuniorPlayerPanel.add(txtEditJuniorEmail);
		
		JLabel lblNewLabel_6_3_3_2_1 = new JLabel("E-mail:");
		lblNewLabel_6_3_3_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_3_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_3_2_1.setBounds(495, 127, 109, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_3_3_2_1);
		
		JSeparator separator_1_3_2 = new JSeparator();
		separator_1_3_2.setBounds(0, 319, 793, 2);
		editJuniorPlayerPanel.add(separator_1_3_2);
		
		txtEditJuniorDoctorName = new JTextField();
		txtEditJuniorDoctorName.setColumns(10);
		txtEditJuniorDoctorName.setBounds(95, 339, 143, 20);
		editJuniorPlayerPanel.add(txtEditJuniorDoctorName);
		
		JLabel lblNewLabel_6_4_2_2_1 = new JLabel("Doctor:");
		lblNewLabel_6_4_2_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_2_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_2_2_1.setBounds(-24, 332, 109, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_4_2_2_1);
		
		JLabel lblNewLabel_6_4_1_1_2_3 = new JLabel("Tel:");
		lblNewLabel_6_4_1_1_2_3.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_1_1_2_3.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_1_1_2_3.setBounds(-24, 371, 109, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_4_1_1_2_3);
		
		txtEditJuniorDoctorPhone = new JTextField();
		txtEditJuniorDoctorPhone.setColumns(10);
		txtEditJuniorDoctorPhone.setBounds(95, 378, 143, 20);
		editJuniorPlayerPanel.add(txtEditJuniorDoctorPhone);
		
		JLabel lblNewLabel_6_2_1_2_1 = new JLabel("Known Health issues:");
		lblNewLabel_6_2_1_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_2_1_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_2_1_2_1.setBounds(27, 410, 152, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_2_1_2_1);
		
		JTextArea txtEditJuniorHealthIssues = new JTextArea();
		txtEditJuniorHealthIssues.setBorder(UIManager.getBorder("TextField.border"));
		txtEditJuniorHealthIssues.setBounds(189, 415, 461, 64);
		editJuniorPlayerPanel.add(txtEditJuniorHealthIssues);
		
		JSeparator separator_1_1_2_1 = new JSeparator();
		separator_1_1_2_1.setBounds(0, 490, 793, 2);
		editJuniorPlayerPanel.add(separator_1_1_2_1);
		
		/**
		 * Button to take the user back to the home screen
		 */
		JButton btnEditJuniorCancel = new JButton("Cancel");
		btnEditJuniorCancel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				editJuniorPlayerPanel.setVisible(false);
				welcomePanel.setVisible(true);
			}
		});
		btnEditJuniorCancel.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		btnEditJuniorCancel.setBounds(568, 503, 89, 45);
		editJuniorPlayerPanel.add(btnEditJuniorCancel);
		
		JTextArea txtEditJuniorDoctorAddress = new JTextArea();
		txtEditJuniorDoctorAddress.setBorder(UIManager.getBorder("TextField.border"));
		txtEditJuniorDoctorAddress.setBounds(342, 339, 308, 60);
		editJuniorPlayerPanel.add(txtEditJuniorDoctorAddress);
		
		JLabel lblNewLabel_6_2_3_1_2 = new JLabel("Address:");
		lblNewLabel_6_2_3_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_2_3_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_2_3_1_2.setBounds(261, 332, 75, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_2_3_1_2);
		
		JSeparator separator_1_3_1_1 = new JSeparator();
		separator_1_3_1_1.setBounds(241, 166, 552, 2);
		editJuniorPlayerPanel.add(separator_1_3_1_1);
		
		JSeparator separator_2_1 = new JSeparator();
		separator_2_1.setOrientation(SwingConstants.VERTICAL);
		separator_2_1.setBounds(241, 166, 1, 155);
		editJuniorPlayerPanel.add(separator_2_1);
		
		txtEditJuniorGuardian1Name = new JTextField();
		txtEditJuniorGuardian1Name.setColumns(10);
		txtEditJuniorGuardian1Name.setBounds(342, 174, 143, 20);
		editJuniorPlayerPanel.add(txtEditJuniorGuardian1Name);
		
		JLabel lblNewLabel_6_6_1_3 = new JLabel("Guardian 1:");
		lblNewLabel_6_6_1_3.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_6_1_3.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_6_1_3.setBounds(257, 166, 75, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_6_1_3);
		
		txtEditJuniorRelationship1 = new JTextField();
		txtEditJuniorRelationship1.setColumns(10);
		txtEditJuniorRelationship1.setBounds(342, 210, 143, 20);
		editJuniorPlayerPanel.add(txtEditJuniorRelationship1);
		
		JLabel lblNewLabel_6_6_1_1_2 = new JLabel("Relationship:");
		lblNewLabel_6_6_1_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_6_1_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_6_1_1_2.setBounds(241, 202, 91, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_6_1_1_2);
		
		JLabel lblNewLabel_6_2_3_1_1_2 = new JLabel("Address:");
		lblNewLabel_6_2_3_1_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_2_3_1_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_2_3_1_1_2.setBounds(261, 234, 75, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_2_3_1_1_2);
		
		JTextArea txtEditJuniorGuardian1Address = new JTextArea();
		txtEditJuniorGuardian1Address.setBorder(UIManager.getBorder("TextField.border"));
		txtEditJuniorGuardian1Address.setBounds(342, 241, 143, 35);
		editJuniorPlayerPanel.add(txtEditJuniorGuardian1Address);
		
		txtEditJuniorGuardian1Phone = new JTextField();
		txtEditJuniorGuardian1Phone.setColumns(10);
		txtEditJuniorGuardian1Phone.setBounds(342, 287, 143, 20);
		editJuniorPlayerPanel.add(txtEditJuniorGuardian1Phone);
		
		JLabel lblNewLabel_6_4_1_1_2_1_2 = new JLabel("Tel:");
		lblNewLabel_6_4_1_1_2_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_1_1_2_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_1_1_2_1_2.setBounds(223, 280, 109, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_4_1_1_2_1_2);
		
		txtEditJuniorGuardian2Phone = new JTextField();
		txtEditJuniorGuardian2Phone.setColumns(10);
		txtEditJuniorGuardian2Phone.setBounds(614, 287, 143, 20);
		editJuniorPlayerPanel.add(txtEditJuniorGuardian2Phone);
		
		JLabel lblNewLabel_6_4_1_1_2_1_1_1 = new JLabel("Tel:");
		lblNewLabel_6_4_1_1_2_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_1_1_2_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_1_1_2_1_1_1.setBounds(495, 280, 109, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_4_1_1_2_1_1_1);
		
		JLabel lblNewLabel_6_2_3_1_1_1_1 = new JLabel("Address:");
		lblNewLabel_6_2_3_1_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_2_3_1_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_2_3_1_1_1_1.setBounds(533, 234, 75, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_2_3_1_1_1_1);
		
		JTextArea txtEditJuniorGuardian2Address = new JTextArea();
		txtEditJuniorGuardian2Address.setBorder(UIManager.getBorder("TextField.border"));
		txtEditJuniorGuardian2Address.setBounds(614, 241, 143, 35);
		editJuniorPlayerPanel.add(txtEditJuniorGuardian2Address);
		
		txtEditJuniorRelationship2 = new JTextField();
		txtEditJuniorRelationship2.setColumns(10);
		txtEditJuniorRelationship2.setBounds(614, 210, 143, 20);
		editJuniorPlayerPanel.add(txtEditJuniorRelationship2);
		
		JLabel lblNewLabel_6_6_1_1_1_1 = new JLabel("Relationship:");
		lblNewLabel_6_6_1_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_6_1_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_6_1_1_1_1.setBounds(513, 202, 91, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_6_1_1_1_1);
		
		JLabel lblNewLabel_6_6_1_2_1 = new JLabel("Guardian 2:");
		lblNewLabel_6_6_1_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_6_1_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_6_1_2_1.setBounds(529, 166, 75, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_6_1_2_1);
		
		txtEditJuniorGuardian2Name = new JTextField();
		txtEditJuniorGuardian2Name.setColumns(10);
		txtEditJuniorGuardian2Name.setBounds(614, 174, 143, 20);
		editJuniorPlayerPanel.add(txtEditJuniorGuardian2Name);
		
		JComboBox cmbEditJuniorPosition = new JComboBox();
		cmbEditJuniorPosition.setModel(new DefaultComboBoxModel(Position.values()));
		cmbEditJuniorPosition.setBounds(95, 517, 143, 22);
		editJuniorPlayerPanel.add(cmbEditJuniorPosition);
		
		JLabel lblNewLabel_6_4_1_1_2_2_3 = new JLabel("Position:");
		lblNewLabel_6_4_1_1_2_2_3.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_1_1_2_2_3.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_1_1_2_2_3.setBounds(-24, 511, 109, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_4_1_1_2_2_3);
		
		JComboBox cmbEditJuniorSquad = new JComboBox(myController.getJuniorSquadList().toArray());
		cmbEditJuniorSquad.setBounds(342, 517, 143, 22);
		editJuniorPlayerPanel.add(cmbEditJuniorSquad);
		
		JLabel lblNewLabel_6_4_1_1_2_2_1_1 = new JLabel("Squad:");
		lblNewLabel_6_4_1_1_2_2_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_1_1_2_2_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_1_1_2_2_1_1.setBounds(223, 511, 109, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_4_1_1_2_2_1_1);
		
		JLabel lblNewLabel_6_1_2_1_2 = new JLabel("Postcode:");
		lblNewLabel_6_1_2_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_1_2_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_1_2_1_2.setBounds(10, 246, 75, 28);
		editJuniorPlayerPanel.add(lblNewLabel_6_1_2_1_2);
		
		txtEditJuniorPostcode = new JTextField();
		txtEditJuniorPostcode.setColumns(10);
		txtEditJuniorPostcode.setBounds(95, 253, 143, 20);
		editJuniorPlayerPanel.add(txtEditJuniorPostcode);
		
		/**
		 * Combo Box to select a junior player to edit
		 * Sets each text field to the value from that player
		 */
		JComboBox cmbEditJunior = new JComboBox(myController.getJuniorList().toArray());
		cmbEditJunior.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JuniorPlayer selectedPlayer = (JuniorPlayer) cmbEditJunior.getSelectedItem();
				LocalDate selectedDOB = selectedPlayer.getDateOfBirth();
				String formattedDate = selectedDOB.format(formatter);
				txtEditJuniorFirstName.setText(selectedPlayer.getFirstname());
				txtEditJuniorLastName.setText(selectedPlayer.getSurname());
				txtEditJuniorPostcode.setText(selectedPlayer.getPostCode());
				txtEditJuniorSRUNumber.setText(selectedPlayer.getSRUNumber());
				txtEditJuniorDOB.setText(formattedDate);
				txtEditJuniorPhone.setText(selectedPlayer.getPhone());
				txtEditJuniorEmail.setText(selectedPlayer.getEmail());
				txtEditJuniorAddress.setText(selectedPlayer.getAddress());
				cmbEditJuniorSquad.setSelectedItem(selectedPlayer.getSquad());
				txtEditJuniorDoctorName.setText(selectedPlayer.getDoctor());
				txtEditJuniorDoctorPhone.setText(selectedPlayer.getDoctorPhone());
				txtEditJuniorDoctorAddress.setText(selectedPlayer.getDoctorAddress());
				txtEditJuniorHealthIssues.setText(selectedPlayer.getHealthIssues());
				cmbEditJuniorPosition.setSelectedItem(selectedPlayer.getPosition());
				txtEditJuniorGuardian1Name.setText(selectedPlayer.getGuardian1());
				txtEditJuniorRelationship1.setText(selectedPlayer.getRelationship1());
				txtEditJuniorGuardian1Address.setText(selectedPlayer.getAddress1());
				txtEditJuniorGuardian1Phone.setText(selectedPlayer.getGuardianPhone1());
				txtEditJuniorGuardian2Name.setText(selectedPlayer.getGuardian2());
				txtEditJuniorRelationship2.setText(selectedPlayer.getRelationship2());
				txtEditJuniorGuardian2Address.setText(selectedPlayer.getAddress2());
				txtEditJuniorGuardian2Phone.setText(selectedPlayer.getGuardianPhone2());
			}
		});
		cmbEditJunior.setBounds(85, 48, 153, 22);
		editJuniorPlayerPanel.add(cmbEditJunior);
		
		JLabel lblNewLabel_7_2 = new JLabel("Please select a player");
		lblNewLabel_7_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_7_2.setBounds(85, 23, 153, 28);
		editJuniorPlayerPanel.add(lblNewLabel_7_2);
		
		/**
		 * Button to edit the selected junior player with new inserted values
		 */
		JButton btnEditJuniorSubmit = new JButton("Submit");
		btnEditJuniorSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String DOB = txtEditJuniorDOB.getText();
					message = myController.editJunior(txtEditJuniorFirstName.getText(), txtEditJuniorLastName.getText(), 
							null, null, false, txtEditJuniorPostcode.getText(), txtEditJuniorAddress.getText(), 
							LocalDate.parse(DOB, formatter), txtEditJuniorEmail.getText(),
							txtEditJuniorPhone.getText(), txtEditJuniorSRUNumber.getText(), false, (Squad) cmbEditJuniorSquad.getSelectedItem(),
							null, null, null, txtEditJuniorDoctorName.getText(),
							txtEditJuniorDoctorPhone.getText(), txtEditJuniorHealthIssues.getText(), (Position) cmbEditJuniorPosition.getSelectedItem(),
							SquadCategory.junior, txtEditJuniorGuardian1Name.getText(), txtEditJuniorRelationship1.getText(), 
							txtEditJuniorGuardian1Address.getText(), txtEditJuniorGuardian1Phone.getText(), 
							txtEditJuniorGuardian2Name.getText(), txtEditJuniorRelationship2.getText(), 
							txtEditJuniorGuardian2Address.getText(), txtEditJuniorGuardian2Phone.getText(), txtEditJuniorDoctorAddress.getText());
					displayMessage(message);
				} catch (DateTimeParseException e1) {
					JFrame f = new JFrame();
					JOptionPane.showMessageDialog(f, "Please insert a correct date (DD/MM/YYYY)");
				} catch (Exception e2) {
					JFrame f = new JFrame();
					JOptionPane.showMessageDialog(f, "Please insert correct data in all boxes!");
				}
			}
		});
		btnEditJuniorSubmit.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		btnEditJuniorSubmit.setBounds(675, 503, 89, 45);
		editJuniorPlayerPanel.add(btnEditJuniorSubmit);
		editJuniorPlayerPanel.setVisible(false);
		
		JPanel editSeniorPlayerPanel = new JPanel();
		editSeniorPlayerPanel.setLayout(null);
		editSeniorPlayerPanel.setBounds(205, 53, 793, 572);
		contentPane.add(editSeniorPlayerPanel);
		
		JLabel lblNewLabel_5_2_1 = new JLabel("Edit Senior Player");
		lblNewLabel_5_2_1.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel_5_2_1.setBounds(302, 11, 245, 105);
		editSeniorPlayerPanel.add(lblNewLabel_5_2_1);
		
		JLabel lblNewLabel_6_5 = new JLabel("First Name:");
		lblNewLabel_6_5.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_5.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_5.setBounds(104, 113, 75, 28);
		editSeniorPlayerPanel.add(lblNewLabel_6_5);
		
		txtEditSeniorFirstName = new JTextField();
		txtEditSeniorFirstName.setColumns(10);
		txtEditSeniorFirstName.setBounds(189, 120, 143, 20);
		editSeniorPlayerPanel.add(txtEditSeniorFirstName);
		
		JLabel lblNewLabel_6_1_1 = new JLabel("Last Name:");
		lblNewLabel_6_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_1_1.setBounds(104, 152, 75, 28);
		editSeniorPlayerPanel.add(lblNewLabel_6_1_1);
		
		txtEditSeniorLastName = new JTextField();
		txtEditSeniorLastName.setColumns(10);
		txtEditSeniorLastName.setBounds(189, 159, 143, 20);
		editSeniorPlayerPanel.add(txtEditSeniorLastName);
		
		JLabel lblNewLabel_6_2_2 = new JLabel("Address:");
		lblNewLabel_6_2_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_2_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_2_2.setBounds(104, 191, 75, 28);
		editSeniorPlayerPanel.add(lblNewLabel_6_2_2);
		
		JTextArea txtEditSeniorAddress = new JTextArea();
		txtEditSeniorAddress.setBorder(UIManager.getBorder("TextField.border"));
		txtEditSeniorAddress.setBounds(189, 196, 143, 63);
		editSeniorPlayerPanel.add(txtEditSeniorAddress);
		
		txtEditSeniorSRUNumber = new JTextField();
		txtEditSeniorSRUNumber.setEditable(false);
		txtEditSeniorSRUNumber.setColumns(10);
		txtEditSeniorSRUNumber.setBounds(507, 120, 143, 20);
		editSeniorPlayerPanel.add(txtEditSeniorSRUNumber);
		
		JLabel lblNewLabel_6_3_4 = new JLabel("SRU Number:");
		lblNewLabel_6_3_4.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_4.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_4.setBounds(388, 113, 109, 28);
		editSeniorPlayerPanel.add(lblNewLabel_6_3_4);
		
		txtEditSeniorDOB = new JTextField();
		txtEditSeniorDOB.setColumns(10);
		txtEditSeniorDOB.setBounds(507, 159, 143, 20);
		editSeniorPlayerPanel.add(txtEditSeniorDOB);
		
		JLabel lblNewLabel_6_3_1_1 = new JLabel("Date of Birth:");
		lblNewLabel_6_3_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_1_1.setBounds(388, 152, 109, 28);
		editSeniorPlayerPanel.add(lblNewLabel_6_3_1_1);
		
		txtEditSeniorPhone = new JTextField();
		txtEditSeniorPhone.setColumns(10);
		txtEditSeniorPhone.setBounds(507, 198, 143, 20);
		editSeniorPlayerPanel.add(txtEditSeniorPhone);
		
		JLabel lblNewLabel_6_3_2_1 = new JLabel("Phone Number:");
		lblNewLabel_6_3_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_2_1.setBounds(388, 191, 109, 28);
		editSeniorPlayerPanel.add(lblNewLabel_6_3_2_1);
		
		txtEditSeniorEmail = new JTextField();
		txtEditSeniorEmail.setColumns(10);
		txtEditSeniorEmail.setBounds(507, 239, 143, 20);
		editSeniorPlayerPanel.add(txtEditSeniorEmail);
		
		JLabel lblNewLabel_6_3_3_1 = new JLabel("E-mail:");
		lblNewLabel_6_3_3_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_3_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_3_1.setBounds(388, 232, 109, 28);
		editSeniorPlayerPanel.add(lblNewLabel_6_3_3_1);
		
		JSeparator separator_1_2 = new JSeparator();
		separator_1_2.setBounds(0, 319, 793, 2);
		editSeniorPlayerPanel.add(separator_1_2);
		
		JLabel lblNewLabel_6_4_3 = new JLabel("Next of Kin:");
		lblNewLabel_6_4_3.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_3.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_3.setBounds(70, 332, 109, 28);
		editSeniorPlayerPanel.add(lblNewLabel_6_4_3);
		
		txtEditSeniorNOKName = new JTextField();
		txtEditSeniorNOKName.setColumns(10);
		txtEditSeniorNOKName.setBounds(189, 339, 143, 20);
		editSeniorPlayerPanel.add(txtEditSeniorNOKName);
		
		JLabel lblNewLabel_6_4_1_2 = new JLabel("Tel:");
		lblNewLabel_6_4_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_1_2.setBounds(70, 371, 109, 28);
		editSeniorPlayerPanel.add(lblNewLabel_6_4_1_2);
		
		txtEditSeniorNOKPhone = new JTextField();
		txtEditSeniorNOKPhone.setColumns(10);
		txtEditSeniorNOKPhone.setBounds(189, 378, 143, 20);
		editSeniorPlayerPanel.add(txtEditSeniorNOKPhone);
		
		txtEditSeniorDoctorName = new JTextField();
		txtEditSeniorDoctorName.setColumns(10);
		txtEditSeniorDoctorName.setBounds(507, 339, 143, 20);
		editSeniorPlayerPanel.add(txtEditSeniorDoctorName);
		
		JLabel lblNewLabel_6_4_2_1 = new JLabel("Doctor:");
		lblNewLabel_6_4_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_2_1.setBounds(388, 332, 109, 28);
		editSeniorPlayerPanel.add(lblNewLabel_6_4_2_1);
		
		JLabel lblNewLabel_6_4_1_1_1 = new JLabel("Tel:");
		lblNewLabel_6_4_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_1_1_1.setBounds(388, 371, 109, 28);
		editSeniorPlayerPanel.add(lblNewLabel_6_4_1_1_1);
		
		txtEditSeniorDoctorPhone = new JTextField();
		txtEditSeniorDoctorPhone.setColumns(10);
		txtEditSeniorDoctorPhone.setBounds(507, 378, 143, 20);
		editSeniorPlayerPanel.add(txtEditSeniorDoctorPhone);
		
		JLabel lblNewLabel_6_2_1_1 = new JLabel("Known Health issues:");
		lblNewLabel_6_2_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_2_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_2_1_1.setBounds(27, 410, 152, 28);
		editSeniorPlayerPanel.add(lblNewLabel_6_2_1_1);
		
		JTextArea txtEditSeniorHealthIssues = new JTextArea();
		txtEditSeniorHealthIssues.setBorder(UIManager.getBorder("TextField.border"));
		txtEditSeniorHealthIssues.setBounds(189, 415, 461, 64);
		editSeniorPlayerPanel.add(txtEditSeniorHealthIssues);
		
		JSeparator separator_1_1_1 = new JSeparator();
		separator_1_1_1.setBounds(0, 490, 793, 2);
		editSeniorPlayerPanel.add(separator_1_1_1);
		
		/**
		 * Button to take user back to the home screen
		 */
		JButton btnEditSeniorCancel = new JButton("Cancel");
		btnEditSeniorCancel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				editSeniorPlayerPanel.setVisible(false);
				welcomePanel.setVisible(true);
			}
		});
		btnEditSeniorCancel.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		btnEditSeniorCancel.setBounds(568, 503, 89, 45);
		editSeniorPlayerPanel.add(btnEditSeniorCancel);
		
		JLabel lblNewLabel_7 = new JLabel("Please select a player");
		lblNewLabel_7.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_7.setBounds(70, 33, 153, 28);
		editSeniorPlayerPanel.add(lblNewLabel_7);
		
		JComboBox cmbEditSeniorPosition = new JComboBox();
		cmbEditSeniorPosition.setModel(new DefaultComboBoxModel(Position.values()));
		cmbEditSeniorPosition.setBounds(189, 517, 143, 22);
		editSeniorPlayerPanel.add(cmbEditSeniorPosition);
		
		JLabel lblNewLabel_6_2_1_1_1 = new JLabel("Position:");
		lblNewLabel_6_2_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_2_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_2_1_1_1.setBounds(27, 511, 152, 28);
		editSeniorPlayerPanel.add(lblNewLabel_6_2_1_1_1);
		
		JComboBox cmbEditSeniorSquad = new JComboBox(myController.getSeniorSquadList().toArray());
		cmbEditSeniorSquad.setBounds(404, 517, 143, 22);
		editSeniorPlayerPanel.add(cmbEditSeniorSquad);
		
		JLabel lblNewLabel_6_2_1_1_1_1 = new JLabel("Squad:");
		lblNewLabel_6_2_1_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_2_1_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_2_1_1_1_1.setBounds(243, 511, 152, 28);
		editSeniorPlayerPanel.add(lblNewLabel_6_2_1_1_1_1);
		
		JLabel lblNewLabel_6_1_1_2 = new JLabel("Postcode:");
		lblNewLabel_6_1_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_1_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_1_1_2.setBounds(104, 270, 75, 28);
		editSeniorPlayerPanel.add(lblNewLabel_6_1_1_2);
		
		txtEditSeniorPostcode = new JTextField();
		txtEditSeniorPostcode.setColumns(10);
		txtEditSeniorPostcode.setBounds(189, 277, 143, 20);
		editSeniorPlayerPanel.add(txtEditSeniorPostcode);
		
		/**
		 * Allows the user to select a senior player to edit
		 * Sets each text field to the values of that player.
		 */
		JComboBox cmbEditSenior = new JComboBox(myController.getSeniorList().toArray());
		cmbEditSenior.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Player selectedPlayer = (Player) cmbEditSenior.getSelectedItem();
				LocalDate selectedDOB = selectedPlayer.getDateOfBirth();
				String formattedDate = selectedDOB.format(formatter);
				txtEditSeniorFirstName.setText(selectedPlayer.getFirstname());
				txtEditSeniorLastName.setText(selectedPlayer.getSurname());
				txtEditSeniorPostcode.setText(selectedPlayer.getPostCode());
				txtEditSeniorSRUNumber.setText(selectedPlayer.getSRUNumber());
				txtEditSeniorDOB.setText(formattedDate);
				txtEditSeniorPhone.setText(selectedPlayer.getPhone());
				txtEditSeniorEmail.setText(selectedPlayer.getEmail());
				txtEditSeniorAddress.setText(selectedPlayer.getAddress());
				cmbEditSeniorSquad.setSelectedItem(selectedPlayer.getSquad());
				txtEditSeniorNOKName.setText(selectedPlayer.getNextOfKin());
				txtEditSeniorNOKPhone.setText(selectedPlayer.getNextOfKinPhone());
				txtEditSeniorDoctorName.setText(selectedPlayer.getDoctor());
				txtEditSeniorDoctorPhone.setText(selectedPlayer.getDoctorPhone());
				txtEditSeniorHealthIssues.setText(selectedPlayer.getHealthIssues());
				cmbEditSeniorPosition.setSelectedItem(selectedPlayer.getPosition());
			}
		});
		cmbEditSenior.setBounds(70, 58, 153, 22);
		editSeniorPlayerPanel.add(cmbEditSenior);
		
		/**
		 * Button to edit the chosen senior player with new values inserted by the user
		 */
		JButton btnEditSeniorSubmit = new JButton("Submit");
		btnEditSeniorSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String DOB = txtEditSeniorDOB.getText();
					message = myController.editSenior(txtEditSeniorFirstName.getText(), txtEditSeniorLastName.getText(), 
							null, null, false, txtEditSeniorPostcode.getText(), txtEditSeniorAddress.getText(), 
							LocalDate.parse(DOB, formatter), txtEditSeniorEmail.getText(),
							txtEditSeniorPhone.getText(), txtEditSeniorSRUNumber.getText(), false, (Squad) cmbEditSeniorSquad.getSelectedItem(),
							null, txtEditSeniorNOKName.getText(), txtEditSeniorNOKPhone.getText(), txtEditSeniorDoctorName.getText(),
							txtEditSeniorDoctorPhone.getText(), txtEditSeniorHealthIssues.getText(), (Position) cmbEditSeniorPosition.getSelectedItem(),
							SquadCategory.senior);
					displayMessage(message);
				} catch (DateTimeParseException e1) {
					JFrame f = new JFrame();
					JOptionPane.showMessageDialog(f, "Please insert a correct date (DD/MM/YYYY)");
				} catch (Exception e2) {
					JFrame f = new JFrame();
					JOptionPane.showMessageDialog(f, "Please insert correct data in all boxes!");
				}
			}
		});
		btnEditSeniorSubmit.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		btnEditSeniorSubmit.setBounds(675, 503, 89, 45);
		editSeniorPlayerPanel.add(btnEditSeniorSubmit);
		editSeniorPlayerPanel.setVisible(false);
		
		JPanel selectPlayerTypeToEditPanel = new JPanel();
		selectPlayerTypeToEditPanel.setLayout(null);
		selectPlayerTypeToEditPanel.setBounds(205, 53, 793, 572);
		contentPane.add(selectPlayerTypeToEditPanel);
		
		JLabel lblNewLabel_5_3 = new JLabel("Edit Existing Player");
		lblNewLabel_5_3.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel_5_3.setBounds(302, 11, 245, 105);
		selectPlayerTypeToEditPanel.add(lblNewLabel_5_3);
		
		JLabel lblNewLabel_5_1_2 = new JLabel("Junior");
		lblNewLabel_5_1_2.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel_5_1_2.setBounds(169, 212, 115, 105);
		selectPlayerTypeToEditPanel.add(lblNewLabel_5_1_2);
		
		JLabel lblNewLabel_5_1_1_1 = new JLabel("Senior");
		lblNewLabel_5_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel_5_1_1_1.setBounds(545, 212, 115, 105);
		selectPlayerTypeToEditPanel.add(lblNewLabel_5_1_1_1);
		
		/**
		 * Button to take the user to the edit junior player form
		 */
		JButton btnEditJunior = new JButton("Junior Form");
		btnEditJunior.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				selectPlayerTypeToEditPanel.setVisible(false);
				editJuniorPlayerPanel.setVisible(true);
			}
		});
		btnEditJunior.setFont(new Font("Segoe UI", Font.PLAIN, 20));
		btnEditJunior.setBounds(130, 294, 160, 79);
		selectPlayerTypeToEditPanel.add(btnEditJunior);
		
		/**
		 * Button to take the user to the edit senior player form
		 */
		JButton btnEditSenior = new JButton("Senior Form");
		btnEditSenior.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				selectPlayerTypeToEditPanel.setVisible(false);
				editSeniorPlayerPanel.setVisible(true);
			}
		});
		btnEditSenior.setFont(new Font("Segoe UI", Font.PLAIN, 20));
		btnEditSenior.setBounds(507, 294, 160, 79);
		selectPlayerTypeToEditPanel.add(btnEditSenior);
		
		JPanel viewJuniorPlayerPanel = new JPanel();
		viewJuniorPlayerPanel.setLayout(null);
		viewJuniorPlayerPanel.setBounds(205, 53, 793, 572);
		contentPane.add(viewJuniorPlayerPanel);
		
		JLabel lblNewLabel_5_2_2_1_1 = new JLabel("View Junior Player");
		lblNewLabel_5_2_2_1_1.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel_5_2_2_1_1.setBounds(302, 11, 245, 105);
		viewJuniorPlayerPanel.add(lblNewLabel_5_2_2_1_1);
		
		JLabel lblNewLabel_6_6_2_1 = new JLabel("First Name:");
		lblNewLabel_6_6_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_6_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_6_2_1.setBounds(10, 88, 75, 28);
		viewJuniorPlayerPanel.add(lblNewLabel_6_6_2_1);
		
		txtViewJuniorFirstName = new JTextField();
		txtViewJuniorFirstName.setEditable(false);
		txtViewJuniorFirstName.setColumns(10);
		txtViewJuniorFirstName.setBounds(95, 96, 143, 20);
		viewJuniorPlayerPanel.add(txtViewJuniorFirstName);
		
		JLabel lblNewLabel_6_1_2_1_1 = new JLabel("Last Name:");
		lblNewLabel_6_1_2_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_1_2_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_1_2_1_1.setBounds(10, 127, 75, 28);
		viewJuniorPlayerPanel.add(lblNewLabel_6_1_2_1_1);
		
		txtViewJuniorLastName = new JTextField();
		txtViewJuniorLastName.setEditable(false);
		txtViewJuniorLastName.setColumns(10);
		txtViewJuniorLastName.setBounds(95, 134, 143, 20);
		viewJuniorPlayerPanel.add(txtViewJuniorLastName);
		
		JLabel lblNewLabel_6_2_3_2_1 = new JLabel("Address:");
		lblNewLabel_6_2_3_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_2_3_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_2_3_2_1.setBounds(10, 166, 75, 28);
		viewJuniorPlayerPanel.add(lblNewLabel_6_2_3_2_1);
		
		JTextArea txtViewJuniorAddress = new JTextArea();
		txtViewJuniorAddress.setEditable(false);
		txtViewJuniorAddress.setBorder(UIManager.getBorder("TextField.border"));
		txtViewJuniorAddress.setBounds(95, 171, 143, 64);
		viewJuniorPlayerPanel.add(txtViewJuniorAddress);
		
		txtViewJuniorSRUNumber = new JTextField();
		txtViewJuniorSRUNumber.setEditable(false);
		txtViewJuniorSRUNumber.setColumns(10);
		txtViewJuniorSRUNumber.setBounds(342, 95, 143, 20);
		viewJuniorPlayerPanel.add(txtViewJuniorSRUNumber);
		
		JLabel lblNewLabel_6_3_5_1_1 = new JLabel("SRU Number:");
		lblNewLabel_6_3_5_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_5_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_5_1_1.setBounds(223, 88, 109, 28);
		viewJuniorPlayerPanel.add(lblNewLabel_6_3_5_1_1);
		
		txtViewJuniorDOB = new JTextField();
		txtViewJuniorDOB.setEditable(false);
		txtViewJuniorDOB.setColumns(10);
		txtViewJuniorDOB.setBounds(342, 134, 143, 20);
		viewJuniorPlayerPanel.add(txtViewJuniorDOB);
		
		JLabel lblNewLabel_6_3_1_2_1_1 = new JLabel("Date of Birth:");
		lblNewLabel_6_3_1_2_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_1_2_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_1_2_1_1.setBounds(223, 127, 109, 28);
		viewJuniorPlayerPanel.add(lblNewLabel_6_3_1_2_1_1);
		
		txtViewJuniorPhone = new JTextField();
		txtViewJuniorPhone.setEditable(false);
		txtViewJuniorPhone.setColumns(10);
		txtViewJuniorPhone.setBounds(614, 96, 143, 20);
		viewJuniorPlayerPanel.add(txtViewJuniorPhone);
		
		JLabel lblNewLabel_6_3_2_2_1_1 = new JLabel("Phone Number:");
		lblNewLabel_6_3_2_2_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_2_2_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_2_2_1_1.setBounds(495, 88, 109, 28);
		viewJuniorPlayerPanel.add(lblNewLabel_6_3_2_2_1_1);
		
		txtViewJuniorEmail = new JTextField();
		txtViewJuniorEmail.setEditable(false);
		txtViewJuniorEmail.setColumns(10);
		txtViewJuniorEmail.setBounds(614, 134, 143, 20);
		viewJuniorPlayerPanel.add(txtViewJuniorEmail);
		
		JLabel lblNewLabel_6_3_3_2_1_1 = new JLabel("E-mail:");
		lblNewLabel_6_3_3_2_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_3_2_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_3_2_1_1.setBounds(495, 127, 109, 28);
		viewJuniorPlayerPanel.add(lblNewLabel_6_3_3_2_1_1);
		
		JSeparator separator_1_3_2_1 = new JSeparator();
		separator_1_3_2_1.setBounds(0, 319, 793, 2);
		viewJuniorPlayerPanel.add(separator_1_3_2_1);
		
		txtViewJuniorDoctorName = new JTextField();
		txtViewJuniorDoctorName.setEditable(false);
		txtViewJuniorDoctorName.setColumns(10);
		txtViewJuniorDoctorName.setBounds(95, 339, 143, 20);
		viewJuniorPlayerPanel.add(txtViewJuniorDoctorName);
		
		JLabel lblNewLabel_6_4_2_2_1_1 = new JLabel("Doctor:");
		lblNewLabel_6_4_2_2_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_2_2_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_2_2_1_1.setBounds(-24, 332, 109, 28);
		viewJuniorPlayerPanel.add(lblNewLabel_6_4_2_2_1_1);
		
		JLabel lblNewLabel_6_4_1_1_2_3_1 = new JLabel("Tel:");
		lblNewLabel_6_4_1_1_2_3_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_1_1_2_3_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_1_1_2_3_1.setBounds(-24, 371, 109, 28);
		viewJuniorPlayerPanel.add(lblNewLabel_6_4_1_1_2_3_1);
		
		txtViewJuniorDoctorPhone = new JTextField();
		txtViewJuniorDoctorPhone.setEditable(false);
		txtViewJuniorDoctorPhone.setColumns(10);
		txtViewJuniorDoctorPhone.setBounds(95, 378, 143, 20);
		viewJuniorPlayerPanel.add(txtViewJuniorDoctorPhone);
		
		JLabel lblNewLabel_6_2_1_2_1_1 = new JLabel("Known Health issues:");
		lblNewLabel_6_2_1_2_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_2_1_2_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_2_1_2_1_1.setBounds(27, 410, 152, 28);
		viewJuniorPlayerPanel.add(lblNewLabel_6_2_1_2_1_1);
		
		JTextArea txtViewJuniorHealthIssues = new JTextArea();
		txtViewJuniorHealthIssues.setEditable(false);
		txtViewJuniorHealthIssues.setBorder(UIManager.getBorder("TextField.border"));
		txtViewJuniorHealthIssues.setBounds(189, 415, 461, 64);
		viewJuniorPlayerPanel.add(txtViewJuniorHealthIssues);
		
		JSeparator separator_1_1_2_1_1 = new JSeparator();
		separator_1_1_2_1_1.setBounds(0, 490, 793, 2);
		viewJuniorPlayerPanel.add(separator_1_1_2_1_1);
		
		/**
		 * Button to take the user back to the home screen
		 */
		JButton btnViewJuniorMenu = new JButton("Menu");
		btnViewJuniorMenu.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				viewJuniorPlayerPanel.setVisible(false);
				welcomePanel.setVisible(true);
			}
		});
		btnViewJuniorMenu.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		btnViewJuniorMenu.setBounds(647, 503, 117, 45);
		viewJuniorPlayerPanel.add(btnViewJuniorMenu);
		
		JTextArea txtViewJuniorDoctorAddress = new JTextArea();
		txtViewJuniorDoctorAddress.setEditable(false);
		txtViewJuniorDoctorAddress.setBorder(UIManager.getBorder("TextField.border"));
		txtViewJuniorDoctorAddress.setBounds(342, 339, 308, 60);
		viewJuniorPlayerPanel.add(txtViewJuniorDoctorAddress);
		
		JLabel lblNewLabel_6_2_3_1_2_1 = new JLabel("Address:");
		lblNewLabel_6_2_3_1_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_2_3_1_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_2_3_1_2_1.setBounds(261, 332, 75, 28);
		viewJuniorPlayerPanel.add(lblNewLabel_6_2_3_1_2_1);
		
		JSeparator separator_1_3_1_1_1 = new JSeparator();
		separator_1_3_1_1_1.setBounds(241, 166, 552, 2);
		viewJuniorPlayerPanel.add(separator_1_3_1_1_1);
		
		JSeparator separator_2_1_1 = new JSeparator();
		separator_2_1_1.setOrientation(SwingConstants.VERTICAL);
		separator_2_1_1.setBounds(241, 166, 1, 155);
		viewJuniorPlayerPanel.add(separator_2_1_1);
		
		txtViewJuniorGuardian1Name = new JTextField();
		txtViewJuniorGuardian1Name.setEditable(false);
		txtViewJuniorGuardian1Name.setColumns(10);
		txtViewJuniorGuardian1Name.setBounds(342, 174, 143, 20);
		viewJuniorPlayerPanel.add(txtViewJuniorGuardian1Name);
		
		JLabel lblNewLabel_6_6_1_3_1 = new JLabel("Guardian 1:");
		lblNewLabel_6_6_1_3_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_6_1_3_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_6_1_3_1.setBounds(257, 166, 75, 28);
		viewJuniorPlayerPanel.add(lblNewLabel_6_6_1_3_1);
		
		txtViewJuniorRelationship1 = new JTextField();
		txtViewJuniorRelationship1.setEditable(false);
		txtViewJuniorRelationship1.setColumns(10);
		txtViewJuniorRelationship1.setBounds(342, 210, 143, 20);
		viewJuniorPlayerPanel.add(txtViewJuniorRelationship1);
		
		JLabel lblNewLabel_6_6_1_1_2_1 = new JLabel("Relationship:");
		lblNewLabel_6_6_1_1_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_6_1_1_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_6_1_1_2_1.setBounds(241, 202, 91, 28);
		viewJuniorPlayerPanel.add(lblNewLabel_6_6_1_1_2_1);
		
		JLabel lblNewLabel_6_2_3_1_1_2_1 = new JLabel("Address:");
		lblNewLabel_6_2_3_1_1_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_2_3_1_1_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_2_3_1_1_2_1.setBounds(261, 234, 75, 28);
		viewJuniorPlayerPanel.add(lblNewLabel_6_2_3_1_1_2_1);
		
		JTextArea txtViewGuardian1Address = new JTextArea();
		txtViewGuardian1Address.setEditable(false);
		txtViewGuardian1Address.setBorder(UIManager.getBorder("TextField.border"));
		txtViewGuardian1Address.setBounds(342, 241, 143, 35);
		viewJuniorPlayerPanel.add(txtViewGuardian1Address);
		
		txtViewJuniorGuardian1Phone = new JTextField();
		txtViewJuniorGuardian1Phone.setEditable(false);
		txtViewJuniorGuardian1Phone.setColumns(10);
		txtViewJuniorGuardian1Phone.setBounds(342, 287, 143, 20);
		viewJuniorPlayerPanel.add(txtViewJuniorGuardian1Phone);
		
		JLabel lblNewLabel_6_4_1_1_2_1_2_1 = new JLabel("Tel:");
		lblNewLabel_6_4_1_1_2_1_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_1_1_2_1_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_1_1_2_1_2_1.setBounds(223, 280, 109, 28);
		viewJuniorPlayerPanel.add(lblNewLabel_6_4_1_1_2_1_2_1);
		
		txtViewJuniorGuardian2Phone = new JTextField();
		txtViewJuniorGuardian2Phone.setEditable(false);
		txtViewJuniorGuardian2Phone.setColumns(10);
		txtViewJuniorGuardian2Phone.setBounds(614, 287, 143, 20);
		viewJuniorPlayerPanel.add(txtViewJuniorGuardian2Phone);
		
		JLabel lblNewLabel_6_4_1_1_2_1_1_1_1 = new JLabel("Tel:");
		lblNewLabel_6_4_1_1_2_1_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_1_1_2_1_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_1_1_2_1_1_1_1.setBounds(495, 280, 109, 28);
		viewJuniorPlayerPanel.add(lblNewLabel_6_4_1_1_2_1_1_1_1);
		
		JLabel lblNewLabel_6_2_3_1_1_1_1_1 = new JLabel("Address:");
		lblNewLabel_6_2_3_1_1_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_2_3_1_1_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_2_3_1_1_1_1_1.setBounds(533, 234, 75, 28);
		viewJuniorPlayerPanel.add(lblNewLabel_6_2_3_1_1_1_1_1);
		
		JTextArea txtViewGuardian2Address = new JTextArea();
		txtViewGuardian2Address.setEditable(false);
		txtViewGuardian2Address.setBorder(UIManager.getBorder("TextField.border"));
		txtViewGuardian2Address.setBounds(614, 241, 143, 35);
		viewJuniorPlayerPanel.add(txtViewGuardian2Address);
		
		txtViewJuniorRelationship2 = new JTextField();
		txtViewJuniorRelationship2.setEditable(false);
		txtViewJuniorRelationship2.setColumns(10);
		txtViewJuniorRelationship2.setBounds(614, 210, 143, 20);
		viewJuniorPlayerPanel.add(txtViewJuniorRelationship2);
		
		JLabel lblNewLabel_6_6_1_1_1_1_1 = new JLabel("Relationship:");
		lblNewLabel_6_6_1_1_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_6_1_1_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_6_1_1_1_1_1.setBounds(513, 202, 91, 28);
		viewJuniorPlayerPanel.add(lblNewLabel_6_6_1_1_1_1_1);
		
		JLabel lblNewLabel_6_6_1_2_1_1 = new JLabel("Guardian 2:");
		lblNewLabel_6_6_1_2_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_6_1_2_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_6_1_2_1_1.setBounds(529, 166, 75, 28);
		viewJuniorPlayerPanel.add(lblNewLabel_6_6_1_2_1_1);
		
		txtViewJuniorGuardian2Name = new JTextField();
		txtViewJuniorGuardian2Name.setEditable(false);
		txtViewJuniorGuardian2Name.setColumns(10);
		txtViewJuniorGuardian2Name.setBounds(614, 174, 143, 20);
		viewJuniorPlayerPanel.add(txtViewJuniorGuardian2Name);
		
		JLabel lblNewLabel_6_4_1_1_2_2_3_1 = new JLabel("Position:");
		lblNewLabel_6_4_1_1_2_2_3_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_1_1_2_2_3_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_1_1_2_2_3_1.setBounds(-24, 511, 109, 28);
		viewJuniorPlayerPanel.add(lblNewLabel_6_4_1_1_2_2_3_1);
		
		JLabel lblNewLabel_6_4_1_1_2_2_1_1_1 = new JLabel("Squad:");
		lblNewLabel_6_4_1_1_2_2_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_1_1_2_2_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_1_1_2_2_1_1_1.setBounds(223, 511, 109, 28);
		viewJuniorPlayerPanel.add(lblNewLabel_6_4_1_1_2_2_1_1_1);
		
		txtViewJuniorPosition = new JTextField();
		txtViewJuniorPosition.setEditable(false);
		txtViewJuniorPosition.setColumns(10);
		txtViewJuniorPosition.setBounds(95, 518, 143, 20);
		viewJuniorPlayerPanel.add(txtViewJuniorPosition);
		
		txtViewJuniorSquad = new JTextField();
		txtViewJuniorSquad.setEditable(false);
		txtViewJuniorSquad.setColumns(10);
		txtViewJuniorSquad.setBounds(342, 518, 143, 20);
		viewJuniorPlayerPanel.add(txtViewJuniorSquad);
		
		JLabel lblNewLabel_6_6_2_1_1 = new JLabel("Select Player");
		lblNewLabel_6_6_2_1_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_6_6_2_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_6_2_1_1.setBounds(95, 27, 117, 28);
		viewJuniorPlayerPanel.add(lblNewLabel_6_6_2_1_1);
		
		txtViewJuniorPostcode = new JTextField();
		txtViewJuniorPostcode.setEditable(false);
		txtViewJuniorPostcode.setColumns(10);
		txtViewJuniorPostcode.setBounds(95, 253, 143, 20);
		viewJuniorPlayerPanel.add(txtViewJuniorPostcode);
		
		JLabel lblNewLabel_6_1_2_1_1_1 = new JLabel("Postcode:");
		lblNewLabel_6_1_2_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_1_2_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_1_2_1_1_1.setBounds(10, 246, 75, 28);
		viewJuniorPlayerPanel.add(lblNewLabel_6_1_2_1_1_1);
		
		/**
		 * Allows the user to select a junior player to view
		 * Sets each text field to the value from the player
		 */
		JComboBox cmbViewJuniorPlayer = new JComboBox(myController.getJuniorList().toArray());
		cmbViewJuniorPlayer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JuniorPlayer selectedPlayer = (JuniorPlayer) cmbViewJuniorPlayer.getSelectedItem();
				LocalDate selectedDOB = selectedPlayer.getDateOfBirth();
				String formattedDate = selectedDOB.format(formatter);
				txtViewJuniorFirstName.setText(selectedPlayer.getFirstname());
				txtViewJuniorLastName.setText(selectedPlayer.getSurname());
				txtViewJuniorPostcode.setText(selectedPlayer.getPostCode());
				txtViewJuniorSRUNumber.setText(selectedPlayer.getSRUNumber());
				txtViewJuniorDOB.setText(formattedDate);
				txtViewJuniorPhone.setText(selectedPlayer.getPhone());
				txtViewJuniorEmail.setText(selectedPlayer.getEmail());
				txtViewJuniorAddress.setText(selectedPlayer.getAddress());
				try {
					txtViewJuniorSquad.setText(selectedPlayer.getSquad().toString());
				} catch (NullPointerException e1) {
					txtViewJuniorSquad.setText("No Squad");
				}
				txtViewJuniorDoctorName.setText(selectedPlayer.getDoctor());
				txtViewJuniorDoctorPhone.setText(selectedPlayer.getDoctorPhone());
				txtViewJuniorHealthIssues.setText(selectedPlayer.getHealthIssues());
				txtViewJuniorPosition.setText(selectedPlayer.getPosition().toString());
				txtViewJuniorGuardian1Name.setText(selectedPlayer.getGuardian1());
				txtViewJuniorRelationship1.setText(selectedPlayer.getRelationship1());
				txtViewGuardian1Address.setText(selectedPlayer.getAddress1());
				txtViewJuniorGuardian1Phone.setText(selectedPlayer.getGuardianPhone1());
				txtViewJuniorGuardian2Name.setText(selectedPlayer.getGuardian2());
				txtViewJuniorRelationship2.setText(selectedPlayer.getRelationship2());
				txtViewGuardian2Address.setText(selectedPlayer.getAddress2());
				txtViewJuniorGuardian2Phone.setText(selectedPlayer.getGuardianPhone2());
				txtViewJuniorDoctorAddress.setText(selectedPlayer.getDoctorAddress());
			}
		});
		cmbViewJuniorPlayer.setBounds(95, 58, 143, 22);
		viewJuniorPlayerPanel.add(cmbViewJuniorPlayer);
		viewJuniorPlayerPanel.setVisible(false);
		
		JPanel viewSeniorPlayerPanel = new JPanel();
		viewSeniorPlayerPanel.setLayout(null);
		viewSeniorPlayerPanel.setBounds(205, 53, 793, 572);
		contentPane.add(viewSeniorPlayerPanel);
		
		JLabel lblNewLabel_5_2_1_1 = new JLabel("View Senior Player");
		lblNewLabel_5_2_1_1.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel_5_2_1_1.setBounds(277, 4, 297, 105);
		viewSeniorPlayerPanel.add(lblNewLabel_5_2_1_1);
		
		JLabel lblNewLabel_6_5_1 = new JLabel("First Name:");
		lblNewLabel_6_5_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_5_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_5_1.setBounds(104, 113, 75, 28);
		viewSeniorPlayerPanel.add(lblNewLabel_6_5_1);
		
		txtViewSeniorFirstName = new JTextField();
		txtViewSeniorFirstName.setEditable(false);
		txtViewSeniorFirstName.setColumns(10);
		txtViewSeniorFirstName.setBounds(189, 120, 143, 20);
		viewSeniorPlayerPanel.add(txtViewSeniorFirstName);
		
		JLabel lblNewLabel_6_1_1_1 = new JLabel("Last Name:");
		lblNewLabel_6_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_1_1_1.setBounds(104, 152, 75, 28);
		viewSeniorPlayerPanel.add(lblNewLabel_6_1_1_1);
		
		txtViewSeniorLastName = new JTextField();
		txtViewSeniorLastName.setEditable(false);
		txtViewSeniorLastName.setColumns(10);
		txtViewSeniorLastName.setBounds(189, 159, 143, 20);
		viewSeniorPlayerPanel.add(txtViewSeniorLastName);
		
		JLabel lblNewLabel_6_2_2_1 = new JLabel("Address:");
		lblNewLabel_6_2_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_2_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_2_2_1.setBounds(104, 191, 75, 28);
		viewSeniorPlayerPanel.add(lblNewLabel_6_2_2_1);
		
		JTextArea txtViewSeniorAddress = new JTextArea();
		txtViewSeniorAddress.setEditable(false);
		txtViewSeniorAddress.setBorder(UIManager.getBorder("TextField.border"));
		txtViewSeniorAddress.setBounds(189, 196, 143, 112);
		viewSeniorPlayerPanel.add(txtViewSeniorAddress);
		
		txtViewSeniorSRUNumber = new JTextField();
		txtViewSeniorSRUNumber.setEditable(false);
		txtViewSeniorSRUNumber.setColumns(10);
		txtViewSeniorSRUNumber.setBounds(507, 120, 143, 20);
		viewSeniorPlayerPanel.add(txtViewSeniorSRUNumber);
		
		JLabel lblNewLabel_6_3_4_1 = new JLabel("SRU Number:");
		lblNewLabel_6_3_4_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_4_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_4_1.setBounds(388, 113, 109, 28);
		viewSeniorPlayerPanel.add(lblNewLabel_6_3_4_1);
		
		txtViewSeniorDOB = new JTextField();
		txtViewSeniorDOB.setEditable(false);
		txtViewSeniorDOB.setColumns(10);
		txtViewSeniorDOB.setBounds(507, 159, 143, 20);
		viewSeniorPlayerPanel.add(txtViewSeniorDOB);
		
		JLabel lblNewLabel_6_3_1_1_1 = new JLabel("Date of Birth:");
		lblNewLabel_6_3_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_1_1_1.setBounds(388, 152, 109, 28);
		viewSeniorPlayerPanel.add(lblNewLabel_6_3_1_1_1);
		
		txtViewSeniorPhone = new JTextField();
		txtViewSeniorPhone.setEditable(false);
		txtViewSeniorPhone.setColumns(10);
		txtViewSeniorPhone.setBounds(507, 198, 143, 20);
		viewSeniorPlayerPanel.add(txtViewSeniorPhone);
		
		JLabel lblNewLabel_6_3_2_1_1 = new JLabel("Phone Number:");
		lblNewLabel_6_3_2_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_2_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_2_1_1.setBounds(388, 191, 109, 28);
		viewSeniorPlayerPanel.add(lblNewLabel_6_3_2_1_1);
		
		txtViewSeniorEmail = new JTextField();
		txtViewSeniorEmail.setEditable(false);
		txtViewSeniorEmail.setColumns(10);
		txtViewSeniorEmail.setBounds(507, 239, 143, 20);
		viewSeniorPlayerPanel.add(txtViewSeniorEmail);
		
		JLabel lblNewLabel_6_3_3_1_1 = new JLabel("E-mail:");
		lblNewLabel_6_3_3_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_3_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_3_1_1.setBounds(388, 232, 109, 28);
		viewSeniorPlayerPanel.add(lblNewLabel_6_3_3_1_1);
		
		JSeparator separator_1_2_1 = new JSeparator();
		separator_1_2_1.setBounds(0, 319, 793, 2);
		viewSeniorPlayerPanel.add(separator_1_2_1);
		
		JLabel lblNewLabel_6_4_3_1 = new JLabel("Next of Kin:");
		lblNewLabel_6_4_3_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_3_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_3_1.setBounds(70, 332, 109, 28);
		viewSeniorPlayerPanel.add(lblNewLabel_6_4_3_1);
		
		txtViewSeniorNOKName = new JTextField();
		txtViewSeniorNOKName.setEditable(false);
		txtViewSeniorNOKName.setColumns(10);
		txtViewSeniorNOKName.setBounds(189, 339, 143, 20);
		viewSeniorPlayerPanel.add(txtViewSeniorNOKName);
		
		JLabel lblNewLabel_6_4_1_2_1 = new JLabel("Tel:");
		lblNewLabel_6_4_1_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_1_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_1_2_1.setBounds(70, 371, 109, 28);
		viewSeniorPlayerPanel.add(lblNewLabel_6_4_1_2_1);
		
		txtViewSeniorNOKPhone = new JTextField();
		txtViewSeniorNOKPhone.setEditable(false);
		txtViewSeniorNOKPhone.setColumns(10);
		txtViewSeniorNOKPhone.setBounds(189, 378, 143, 20);
		viewSeniorPlayerPanel.add(txtViewSeniorNOKPhone);
		
		txtViewSeniorDoctorName = new JTextField();
		txtViewSeniorDoctorName.setEditable(false);
		txtViewSeniorDoctorName.setColumns(10);
		txtViewSeniorDoctorName.setBounds(507, 339, 143, 20);
		viewSeniorPlayerPanel.add(txtViewSeniorDoctorName);
		
		JLabel lblNewLabel_6_4_2_1_1 = new JLabel("Doctor:");
		lblNewLabel_6_4_2_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_2_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_2_1_1.setBounds(388, 332, 109, 28);
		viewSeniorPlayerPanel.add(lblNewLabel_6_4_2_1_1);
		
		JLabel lblNewLabel_6_4_1_1_1_1 = new JLabel("Tel:");
		lblNewLabel_6_4_1_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_4_1_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_4_1_1_1_1.setBounds(388, 371, 109, 28);
		viewSeniorPlayerPanel.add(lblNewLabel_6_4_1_1_1_1);
		
		txtViewSeniorDoctorPhone = new JTextField();
		txtViewSeniorDoctorPhone.setEditable(false);
		txtViewSeniorDoctorPhone.setColumns(10);
		txtViewSeniorDoctorPhone.setBounds(507, 378, 143, 20);
		viewSeniorPlayerPanel.add(txtViewSeniorDoctorPhone);
		
		JLabel lblNewLabel_6_2_1_1_2 = new JLabel("Known Health issues:");
		lblNewLabel_6_2_1_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_2_1_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_2_1_1_2.setBounds(27, 410, 152, 28);
		viewSeniorPlayerPanel.add(lblNewLabel_6_2_1_1_2);
		
		JTextArea txtViewSeniorHealthIssues = new JTextArea();
		txtViewSeniorHealthIssues.setEditable(false);
		txtViewSeniorHealthIssues.setBorder(UIManager.getBorder("TextField.border"));
		txtViewSeniorHealthIssues.setBounds(189, 415, 461, 64);
		viewSeniorPlayerPanel.add(txtViewSeniorHealthIssues);
		
		JSeparator separator_1_1_1_1 = new JSeparator();
		separator_1_1_1_1.setBounds(0, 490, 793, 2);
		viewSeniorPlayerPanel.add(separator_1_1_1_1);
		
		/**
		 * Button that takes the user back to the home screen
		 */
		JButton btnViewSeniorMenu = new JButton("Menu");
		btnViewSeniorMenu.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				viewSeniorPlayerPanel.setVisible(false);
				welcomePanel.setVisible(true);
			}
		});
		btnViewSeniorMenu.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		btnViewSeniorMenu.setBounds(646, 503, 118, 45);
		viewSeniorPlayerPanel.add(btnViewSeniorMenu);
		
		/**
		 * Allows the user to select a senior player to view
		 * Sets each text field to the value from the player
		 */
		JComboBox cmbViewSenior = new JComboBox(myController.getSeniorList().toArray());
		cmbViewSenior.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Player selectedPlayer = (Player) cmbViewSenior.getSelectedItem();
				LocalDate selectedDOB = selectedPlayer.getDateOfBirth();
				String formattedDate = selectedDOB.format(formatter);
				txtViewSeniorFirstName.setText(selectedPlayer.getFirstname());
				txtViewSeniorLastName.setText(selectedPlayer.getSurname());
				txtViewSeniorPostcode.setText(selectedPlayer.getPostCode());
				txtViewSeniorSRUNumber.setText(selectedPlayer.getSRUNumber());
				txtViewSeniorDOB.setText(formattedDate);
				txtViewSeniorPhone.setText(selectedPlayer.getPhone());
				txtViewSeniorEmail.setText(selectedPlayer.getEmail());
				txtViewSeniorAddress.setText(selectedPlayer.getAddress());
				try {
					txtViewSeniorSquad.setText(selectedPlayer.getSquad().toString());
				} catch (NullPointerException e1) {
					txtViewSeniorSquad.setText("No Squad");
				}
				txtViewSeniorNOKName.setText(selectedPlayer.getNextOfKin());
				txtViewSeniorNOKPhone.setText(selectedPlayer.getNextOfKinPhone());
				txtViewSeniorDoctorName.setText(selectedPlayer.getDoctor());
				txtViewSeniorDoctorPhone.setText(selectedPlayer.getDoctorPhone());
				txtViewSeniorHealthIssues.setText(selectedPlayer.getHealthIssues());
				txtViewSeniorPosition.setText(selectedPlayer.getPosition().toString());
			}
		});
		cmbViewSenior.setBounds(70, 58, 153, 22);
		viewSeniorPlayerPanel.add(cmbViewSenior);
		
		JLabel lblNewLabel_7_1 = new JLabel("Please select a player");
		lblNewLabel_7_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_7_1.setBounds(70, 33, 153, 28);
		viewSeniorPlayerPanel.add(lblNewLabel_7_1);
		
		JLabel lblNewLabel_6_2_1_1_1_2 = new JLabel("Position:");
		lblNewLabel_6_2_1_1_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_2_1_1_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_2_1_1_1_2.setBounds(27, 511, 152, 28);
		viewSeniorPlayerPanel.add(lblNewLabel_6_2_1_1_1_2);
		
		JLabel lblNewLabel_6_2_1_1_1_1_1 = new JLabel("Squad:");
		lblNewLabel_6_2_1_1_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_2_1_1_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_2_1_1_1_1_1.setBounds(243, 511, 152, 28);
		viewSeniorPlayerPanel.add(lblNewLabel_6_2_1_1_1_1_1);
		
		txtViewSeniorPosition = new JTextField();
		txtViewSeniorPosition.setEditable(false);
		txtViewSeniorPosition.setColumns(10);
		txtViewSeniorPosition.setBounds(189, 518, 143, 20);
		viewSeniorPlayerPanel.add(txtViewSeniorPosition);
		
		txtViewSeniorSquad = new JTextField();
		txtViewSeniorSquad.setEditable(false);
		txtViewSeniorSquad.setColumns(10);
		txtViewSeniorSquad.setBounds(405, 518, 143, 20);
		viewSeniorPlayerPanel.add(txtViewSeniorSquad);
		
		txtViewSeniorPostcode = new JTextField();
		txtViewSeniorPostcode.setEditable(false);
		txtViewSeniorPostcode.setColumns(10);
		txtViewSeniorPostcode.setBounds(507, 277, 143, 20);
		viewSeniorPlayerPanel.add(txtViewSeniorPostcode);
		
		JLabel lblNewLabel_6_3_3_1_1_1 = new JLabel("Postcode:");
		lblNewLabel_6_3_3_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_6_3_3_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel_6_3_3_1_1_1.setBounds(388, 270, 109, 28);
		viewSeniorPlayerPanel.add(lblNewLabel_6_3_3_1_1_1);
		viewSeniorPlayerPanel.setVisible(false);
		
		JPanel selectPlayerTypeToViewPanel = new JPanel();
		selectPlayerTypeToViewPanel.setLayout(null);
		selectPlayerTypeToViewPanel.setBounds(205, 53, 793, 572);
		contentPane.add(selectPlayerTypeToViewPanel);
		
		JLabel lblNewLabel_5_3_1 = new JLabel("View Existing Player");
		lblNewLabel_5_3_1.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel_5_3_1.setBounds(302, 11, 324, 105);
		selectPlayerTypeToViewPanel.add(lblNewLabel_5_3_1);
		
		JLabel lblNewLabel_5_1_2_1 = new JLabel("Junior");
		lblNewLabel_5_1_2_1.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel_5_1_2_1.setBounds(169, 212, 115, 105);
		selectPlayerTypeToViewPanel.add(lblNewLabel_5_1_2_1);
		
		JLabel lblNewLabel_5_1_1_1_1 = new JLabel("Senior");
		lblNewLabel_5_1_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel_5_1_1_1_1.setBounds(545, 212, 115, 105);
		selectPlayerTypeToViewPanel.add(lblNewLabel_5_1_1_1_1);
		
		/**
		 * Button to take the user to the junior player form
		 */
		JButton btnViewJunior = new JButton("Junior Form");
		btnViewJunior.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				viewJuniorPlayerPanel.setVisible(true);
				selectPlayerTypeToViewPanel.setVisible(false);
			}
		});
		btnViewJunior.setFont(new Font("Segoe UI", Font.PLAIN, 20));
		btnViewJunior.setBounds(130, 294, 160, 79);
		selectPlayerTypeToViewPanel.add(btnViewJunior);
		
		/**
		 * Button to take the user to the senior player form
		 */
		JButton btnViewSenior = new JButton("Senior Form");
		btnViewSenior.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				viewSeniorPlayerPanel.setVisible(true);
				selectPlayerTypeToViewPanel.setVisible(false);
			}
		});
		btnViewSenior.setFont(new Font("Segoe UI", Font.PLAIN, 20));
		btnViewSenior.setBounds(507, 294, 160, 79);
		selectPlayerTypeToViewPanel.add(btnViewSenior);
		
		JPanel viewCoachPanel = new JPanel();
		viewCoachPanel.setLayout(null);
		viewCoachPanel.setBounds(205, 53, 793, 572);
		contentPane.add(viewCoachPanel);
		
		JLabel lblNewLabel_3_1_1 = new JLabel("View Existing Coach");
		lblNewLabel_3_1_1.setFont(new Font("Segoe UI", Font.BOLD, 25));
		lblNewLabel_3_1_1.setBounds(265, 11, 295, 52);
		viewCoachPanel.add(lblNewLabel_3_1_1);
		
		JLabel lblNewLabel_4_4_2 = new JLabel("First Name:");
		lblNewLabel_4_4_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_4_4_2.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_4_4_2.setBounds(70, 145, 75, 25);
		viewCoachPanel.add(lblNewLabel_4_4_2);
		
		txtViewCoachFirstName = new JTextField();
		txtViewCoachFirstName.setEditable(false);
		txtViewCoachFirstName.setColumns(10);
		txtViewCoachFirstName.setBounds(155, 148, 129, 20);
		viewCoachPanel.add(txtViewCoachFirstName);
		
		JLabel lblNewLabel_4_1_2_1 = new JLabel("Last Name:");
		lblNewLabel_4_1_2_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_4_1_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_4_1_2_1.setBounds(70, 181, 75, 25);
		viewCoachPanel.add(lblNewLabel_4_1_2_1);
		
		txtViewCoachLastName = new JTextField();
		txtViewCoachLastName.setEditable(false);
		txtViewCoachLastName.setColumns(10);
		txtViewCoachLastName.setBounds(155, 184, 129, 20);
		viewCoachPanel.add(txtViewCoachLastName);
		
		JLabel lblNewLabel_4_2_1_1 = new JLabel("Address:");
		lblNewLabel_4_2_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_4_2_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_4_2_1_1.setBounds(70, 217, 75, 25);
		viewCoachPanel.add(lblNewLabel_4_2_1_1);
		
		JLabel lblNewLabel_4_1_1_1_1 = new JLabel("Postcode:");
		lblNewLabel_4_1_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_4_1_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_4_1_1_1_1.setBounds(70, 325, 75, 25);
		viewCoachPanel.add(lblNewLabel_4_1_1_1_1);
		
		txtViewCoachPostcode = new JTextField();
		txtViewCoachPostcode.setEditable(false);
		txtViewCoachPostcode.setColumns(10);
		txtViewCoachPostcode.setBounds(155, 328, 129, 20);
		viewCoachPanel.add(txtViewCoachPostcode);
		
		JLabel lblNewLabel_4_3_4_1 = new JLabel("SRU Number:");
		lblNewLabel_4_3_4_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_4_3_4_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_4_3_4_1.setBounds(424, 145, 104, 25);
		viewCoachPanel.add(lblNewLabel_4_3_4_1);
		
		txtViewCoachSRUNumber = new JTextField();
		txtViewCoachSRUNumber.setEditable(false);
		txtViewCoachSRUNumber.setColumns(10);
		txtViewCoachSRUNumber.setBounds(538, 148, 129, 20);
		viewCoachPanel.add(txtViewCoachSRUNumber);
		
		JLabel lblNewLabel_4_3_1_1_1 = new JLabel("Date of Birth:");
		lblNewLabel_4_3_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_4_3_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_4_3_1_1_1.setBounds(424, 181, 104, 25);
		viewCoachPanel.add(lblNewLabel_4_3_1_1_1);
		
		txtViewCoachDOB = new JTextField();
		txtViewCoachDOB.setEditable(false);
		txtViewCoachDOB.setColumns(10);
		txtViewCoachDOB.setBounds(538, 184, 129, 20);
		viewCoachPanel.add(txtViewCoachDOB);
		
		JLabel lblNewLabel_4_3_2_1_1 = new JLabel("Phone Number:");
		lblNewLabel_4_3_2_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_4_3_2_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_4_3_2_1_1.setBounds(424, 217, 104, 25);
		viewCoachPanel.add(lblNewLabel_4_3_2_1_1);
		
		txtViewCoachPhone = new JTextField();
		txtViewCoachPhone.setEditable(false);
		txtViewCoachPhone.setColumns(10);
		txtViewCoachPhone.setBounds(538, 220, 129, 20);
		viewCoachPanel.add(txtViewCoachPhone);
		
		JLabel lblNewLabel_4_3_3_1_2 = new JLabel("E-Mail:");
		lblNewLabel_4_3_3_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_4_3_3_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_4_3_3_1_2.setBounds(424, 253, 104, 25);
		viewCoachPanel.add(lblNewLabel_4_3_3_1_2);
		
		txtViewCoachEmail = new JTextField();
		txtViewCoachEmail.setEditable(false);
		txtViewCoachEmail.setColumns(10);
		txtViewCoachEmail.setBounds(538, 256, 129, 20);
		viewCoachPanel.add(txtViewCoachEmail);
		
		/**
		 * Button to take the user back to the home screen
		 */
		JButton btnViewCoachMenu = new JButton("Menu");
		btnViewCoachMenu.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				viewCoachPanel.setVisible(false);
				welcomePanel.setVisible(true);
			}
		});
		btnViewCoachMenu.setFont(new Font("Segoe UI", Font.BOLD, 25));
		btnViewCoachMenu.setBounds(302, 455, 157, 59);
		viewCoachPanel.add(btnViewCoachMenu);
		
		JTextArea txtViewCoachAddress = new JTextArea();
		txtViewCoachAddress.setWrapStyleWord(true);
		txtViewCoachAddress.setLineWrap(true);
		txtViewCoachAddress.setEditable(false);
		txtViewCoachAddress.setBorder(UIManager.getBorder("TextField.border"));
		txtViewCoachAddress.setBounds(155, 218, 129, 99);
		viewCoachPanel.add(txtViewCoachAddress);
		
		/**
		 * Allows the user to select a coach to view
		 * Sets text fields equal to the selected coaches values
		 */
		JComboBox cmbSelectCoach = new JComboBox(myController.getCoachList().toArray());
		cmbSelectCoach.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Member selectedCoach = (Member) cmbSelectCoach.getSelectedItem();
				LocalDate selectedDOB = selectedCoach.getDateOfBirth();
				String formattedDate = selectedDOB.format(formatter);
				txtViewCoachFirstName.setText(selectedCoach.getFirstname());
				txtViewCoachLastName.setText(selectedCoach.getSurname());
				txtViewCoachPostcode.setText(selectedCoach.getPostCode());
				txtViewCoachSRUNumber.setText(selectedCoach.getSRUNumber());
				txtViewCoachDOB.setText(formattedDate);
				txtViewCoachPhone.setText(selectedCoach.getPhone());
				txtViewCoachEmail.setText(selectedCoach.getEmail());
				txtViewCoachAddress.setText(selectedCoach.getAddress());
				try {
					txtViewCoachSquad.setText(selectedCoach.getSquad().toString());
				} catch (NullPointerException e1) {
					txtViewCoachSquad.setText("No Squad");
				}
				txtViewCoachUsername.setText(selectedCoach.getUsername());
				txtViewCoachPassword.setText(selectedCoach.getPassword());
			}
		});
		cmbSelectCoach.setBounds(155, 74, 129, 22);
		viewCoachPanel.add(cmbSelectCoach);
		
		JLabel lblNewLabel_4_4_1_1 = new JLabel("Select a Coach:");
		lblNewLabel_4_4_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_4_4_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_4_4_1_1.setBounds(28, 74, 117, 25);
		viewCoachPanel.add(lblNewLabel_4_4_1_1);
		
		JLabel lblNewLabel_4_3_3_1_1_1 = new JLabel("Squad:");
		lblNewLabel_4_3_3_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_4_3_3_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_4_3_3_1_1_1.setBounds(424, 325, 104, 25);
		viewCoachPanel.add(lblNewLabel_4_3_3_1_1_1);
		
		txtViewCoachSquad = new JTextField();
		txtViewCoachSquad.setEditable(false);
		txtViewCoachSquad.setColumns(10);
		txtViewCoachSquad.setBounds(538, 328, 129, 20);
		viewCoachPanel.add(txtViewCoachSquad);
		
		txtViewCoachPassword = new JTextField();
		txtViewCoachPassword.setEditable(false);
		txtViewCoachPassword.setColumns(10);
		txtViewCoachPassword.setBounds(538, 112, 129, 20);
		viewCoachPanel.add(txtViewCoachPassword);
		
		JLabel lblNewLabel_4_3_4_1_1 = new JLabel("Password:");
		lblNewLabel_4_3_4_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_4_3_4_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_4_3_4_1_1.setBounds(424, 109, 104, 25);
		viewCoachPanel.add(lblNewLabel_4_3_4_1_1);
		
		JLabel lblNewLabel_4_3_4_1_1_1 = new JLabel("Username:");
		lblNewLabel_4_3_4_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_4_3_4_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_4_3_4_1_1_1.setBounds(424, 74, 104, 25);
		viewCoachPanel.add(lblNewLabel_4_3_4_1_1_1);
		
		txtViewCoachUsername = new JTextField();
		txtViewCoachUsername.setEditable(false);
		txtViewCoachUsername.setColumns(10);
		txtViewCoachUsername.setBounds(538, 77, 129, 20);
		viewCoachPanel.add(txtViewCoachUsername);
		viewCoachPanel.setVisible(false);
		
		JPanel squadManagementPanel = new JPanel();
		squadManagementPanel.setLayout(null);
		squadManagementPanel.setBounds(205, 53, 793, 572);
		contentPane.add(squadManagementPanel);
		
		JLabel lblNewLabel_8 = new JLabel("Create New Squad");
		lblNewLabel_8.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_8.setFont(new Font("Segoe UI", Font.BOLD, 25));
		lblNewLabel_8.setBounds(283, 11, 263, 54);
		squadManagementPanel.add(lblNewLabel_8);
		
		txtNewSquadName = new JTextField();
		txtNewSquadName.setColumns(10);
		txtNewSquadName.setBounds(283, 124, 222, 20);
		squadManagementPanel.add(txtNewSquadName);
		
		JLabel lblNewLabel_9 = new JLabel("Enter The Name Of New Squad:");
		lblNewLabel_9.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_9.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_9.setBounds(58, 115, 215, 33);
		squadManagementPanel.add(lblNewLabel_9);
		
		JLabel lblNewLabel_9_1 = new JLabel("Age Category:");
		lblNewLabel_9_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_9_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_9_1.setBounds(58, 175, 215, 33);
		squadManagementPanel.add(lblNewLabel_9_1);
		
		JComboBox cmbNewSquadAgeCat = new JComboBox();
		cmbNewSquadAgeCat.setModel(new DefaultComboBoxModel(SquadCategory.values()));
		cmbNewSquadAgeCat.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		cmbNewSquadAgeCat.setBounds(283, 181, 222, 22);
		squadManagementPanel.add(cmbNewSquadAgeCat);
		
		JSeparator separator_3 = new JSeparator();
		separator_3.setBounds(0, 263, 793, 2);
		squadManagementPanel.add(separator_3);
		
		JLabel lblNewLabel_8_1 = new JLabel("List of Squads");
		lblNewLabel_8_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_8_1.setFont(new Font("Segoe UI", Font.BOLD, 25));
		lblNewLabel_8_1.setBounds(265, 263, 263, 54);
		squadManagementPanel.add(lblNewLabel_8_1);
		
		
		
		JList listAllSquads = new JList(squadList.toArray());
		listAllSquads.setSelectedIndex(0);
		listAllSquads.setBorder(UIManager.getBorder("TextField.border"));
		listAllSquads.setBounds(58, 325, 215, 220);
		squadManagementPanel.add(listAllSquads);
		
		JLabel lblNewLabel_9_1_1 = new JLabel("Edit Name:");
		lblNewLabel_9_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_9_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_9_1_1.setBounds(174, 325, 215, 33);
		squadManagementPanel.add(lblNewLabel_9_1_1);
		
		txtEditSquadName = new JTextField();
		txtEditSquadName.setColumns(10);
		txtEditSquadName.setBounds(398, 332, 222, 20);
		squadManagementPanel.add(txtEditSquadName);
		
		/**
		 * Button to edit a chosen squads name
		 */
		JButton btnEditSquadName = new JButton("Save Name");
		btnEditSquadName.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					Squad selectedSquad = (Squad) listAllSquads.getSelectedValue();
					message = myController.renameSquad(selectedSquad, txtEditSquadName.getText());
					displayMessage(message);
				} catch (Exception e1) {
					JFrame f = new JFrame();
					JOptionPane.showMessageDialog(f, "Please select a squad to edit!");
				}
				listAllSquads.setListData(myController.getSquadList().toArray());
			}
		});
		btnEditSquadName.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		btnEditSquadName.setBounds(398, 363, 107, 54);
		squadManagementPanel.add(btnEditSquadName);
		
		/**
		 * Button to delete a chosen squad
		 */
		JButton btnDeleteSquad = new JButton("Delete Squad");
		btnDeleteSquad.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					Squad selectedSquad = (Squad) listAllSquads.getSelectedValue();
					message = myController.deleteSquad(selectedSquad);
					displayMessage(message);
					listAllSquads.setListData(myController.getSquadList().toArray());
				} catch (NullPointerException e1) {
					displayMessage("Please select a squad to delete!");
				}
				
			}
		});
		btnDeleteSquad.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		btnDeleteSquad.setBounds(283, 491, 120, 54);
		squadManagementPanel.add(btnDeleteSquad);
		
		JLabel lblNewLabel_9_1_1_1 = new JLabel("Select a Squad to Edit");
		lblNewLabel_9_1_1_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_9_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_9_1_1_1.setBounds(58, 289, 215, 33);
		squadManagementPanel.add(lblNewLabel_9_1_1_1);
		
		/**
		 * Button to take the user back to the home screen
		 */
		JButton btnSquadCancel = new JButton("Cancel");
		btnSquadCancel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				squadManagementPanel.setVisible(false);
				welcomePanel.setVisible(true);
			}
		});
		btnSquadCancel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		btnSquadCancel.setBounds(413, 491, 120, 54);
		squadManagementPanel.add(btnSquadCancel);
		
		/**
		 * Button to create a new squad
		 */
		JButton btnCreateSquad = new JButton("Create Squad");
		btnCreateSquad.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (txtNewSquadName.getText().isBlank()) {
					JFrame f = new JFrame();
					JOptionPane.showMessageDialog(f, "Please type a name for your squad!");
				} else {
				message = myController.createSquad(txtNewSquadName.getText(), (SquadCategory) cmbNewSquadAgeCat.getSelectedItem());
				displayMessage(message);
				listAllSquads.setListData(myController.getSquadList().toArray());
				}
			}
		});
		btnCreateSquad.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		btnCreateSquad.setBounds(535, 137, 120, 54);
		squadManagementPanel.add(btnCreateSquad);
		squadManagementPanel.setVisible(false);
		
		JPanel sidePanel = new JPanel();
		sidePanel.setBackground(Color.DARK_GRAY);
		sidePanel.setBounds(0, 0, 205, 625);
		contentPane.add(sidePanel);
		sidePanel.setLayout(null);
		
		/**
		 * Button to take the user to the add coach panel
		 */
		JPanel btnAddCoach = new JPanel();
		btnAddCoach.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				welcomePanel.setVisible(false);
				newCoachPanel.setVisible(true);
				editExistingCoachPanel.setVisible(false);
				newJuniorPlayerPanel.setVisible(false);
				newSeniorPlayerPanel.setVisible(false);
				newPlayerTypePanel.setVisible(false);
				editJuniorPlayerPanel.setVisible(false);
				editSeniorPlayerPanel.setVisible(false);
				selectPlayerTypeToEditPanel.setVisible(false);
				viewCoachPanel.setVisible(false);
				viewJuniorPlayerPanel.setVisible(false);
				viewSeniorPlayerPanel.setVisible(false);
				selectPlayerTypeToViewPanel.setVisible(false);
				squadManagementPanel.setVisible(false);
				cmbNewCoachSquad.setModel(new DefaultComboBoxModel(myController.getSquadList().toArray()));
			}
		});
		
		btnAddCoach.setBorder(null);
		btnAddCoach.setBackground(Color.LIGHT_GRAY);
		btnAddCoach.setBounds(0, 111, 205, 60);
		sidePanel.add(btnAddCoach);
		btnAddCoach.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Add New Coach");
		lblNewLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		lblNewLabel.setBounds(40, 11, 130, 38);
		btnAddCoach.add(lblNewLabel);
		
		/**
		 * Button to take the user to the edit coach panel
		 */
		JPanel btnEditCoach = new JPanel();
		btnEditCoach.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				welcomePanel.setVisible(false);
				newCoachPanel.setVisible(false);
				editExistingCoachPanel.setVisible(true);
				newJuniorPlayerPanel.setVisible(false);
				newSeniorPlayerPanel.setVisible(false);
				newPlayerTypePanel.setVisible(false);
				editJuniorPlayerPanel.setVisible(false);
				editSeniorPlayerPanel.setVisible(false);
				selectPlayerTypeToEditPanel.setVisible(false);
				viewCoachPanel.setVisible(false);
				viewJuniorPlayerPanel.setVisible(false);
				viewSeniorPlayerPanel.setVisible(false);
				selectPlayerTypeToViewPanel.setVisible(false);
				squadManagementPanel.setVisible(false);
				cmbEditCoachSquad.setModel(new DefaultComboBoxModel(myController.getSquadList().toArray()));
				cmbEditCoach.setModel(new DefaultComboBoxModel(myController.getCoachList().toArray()));
			}
		});
		btnEditCoach.setBorder(null);
		btnEditCoach.setLayout(null);
		btnEditCoach.setBackground(Color.GRAY);
		btnEditCoach.setBounds(0, 171, 205, 60);
		sidePanel.add(btnEditCoach);
		
		JLabel lblNewLabel_1 = new JLabel("Edit Existing Coach");
		lblNewLabel_1.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(41, 11, 130, 38);
		btnEditCoach.add(lblNewLabel_1);
		
		/**
		 * Button to take the user to the add player panel
		 */
		JPanel btnAddPlayer = new JPanel();
		btnAddPlayer.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				welcomePanel.setVisible(false);
				newCoachPanel.setVisible(false);
				editExistingCoachPanel.setVisible(false);
				newJuniorPlayerPanel.setVisible(false);
				newSeniorPlayerPanel.setVisible(false);
				newPlayerTypePanel.setVisible(true);
				editJuniorPlayerPanel.setVisible(false);
				editSeniorPlayerPanel.setVisible(false);
				selectPlayerTypeToEditPanel.setVisible(false);
				viewCoachPanel.setVisible(false);
				viewJuniorPlayerPanel.setVisible(false);
				viewSeniorPlayerPanel.setVisible(false);
				selectPlayerTypeToViewPanel.setVisible(false);
				squadManagementPanel.setVisible(false);
				cmbNewJuniorSquad.setModel(new DefaultComboBoxModel(myController.getJuniorSquadList().toArray()));
			}
		});
		btnAddPlayer.setLayout(null);
		btnAddPlayer.setBackground(Color.LIGHT_GRAY);
		btnAddPlayer.setBounds(0, 232, 205, 60);
		sidePanel.add(btnAddPlayer);
		
		JLabel lblAddNewPlayer = new JLabel("Add New Player");
		lblAddNewPlayer.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		lblAddNewPlayer.setBounds(40, 11, 130, 38);
		btnAddPlayer.add(lblAddNewPlayer);
		
		/**
		 * Button to take the user to the edit player panel
		 */
		JPanel btnEditPlayer = new JPanel();
		btnEditPlayer.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				welcomePanel.setVisible(false);
				newCoachPanel.setVisible(false);
				editExistingCoachPanel.setVisible(false);
				newJuniorPlayerPanel.setVisible(false);
				newSeniorPlayerPanel.setVisible(false);
				newPlayerTypePanel.setVisible(false);
				editJuniorPlayerPanel.setVisible(false);
				editSeniorPlayerPanel.setVisible(false);
				selectPlayerTypeToEditPanel.setVisible(true);
				viewCoachPanel.setVisible(false);
				viewJuniorPlayerPanel.setVisible(false);
				viewSeniorPlayerPanel.setVisible(false);
				selectPlayerTypeToViewPanel.setVisible(false);
				squadManagementPanel.setVisible(false);
				cmbEditSenior.setModel(new DefaultComboBoxModel(myController.getSeniorList().toArray()));
				cmbEditJunior.setModel(new DefaultComboBoxModel(myController.getJuniorList().toArray()));
				cmbEditSeniorSquad.setModel(new DefaultComboBoxModel(myController.getSeniorSquadList().toArray()));
				cmbEditJuniorSquad.setModel(new DefaultComboBoxModel(myController.getJuniorSquadList().toArray()));
			}
		});
		btnEditPlayer.setLayout(null);
		btnEditPlayer.setBackground(Color.GRAY);
		btnEditPlayer.setBounds(0, 292, 205, 60);
		sidePanel.add(btnEditPlayer);
		
		JLabel lblNewLabel_1_1 = new JLabel("Edit Existing Player");
		lblNewLabel_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		lblNewLabel_1_1.setBounds(41, 11, 130, 38);
		btnEditPlayer.add(lblNewLabel_1_1);
		
		/**
		 * Button to take the user to the view coaches panel
		 */
		JPanel btnViewCoaches = new JPanel();
		btnViewCoaches.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				welcomePanel.setVisible(false);
				newCoachPanel.setVisible(false);
				editExistingCoachPanel.setVisible(false);
				newJuniorPlayerPanel.setVisible(false);
				newSeniorPlayerPanel.setVisible(false);
				newPlayerTypePanel.setVisible(false);
				editJuniorPlayerPanel.setVisible(false);
				editSeniorPlayerPanel.setVisible(false);
				selectPlayerTypeToEditPanel.setVisible(false);
				viewCoachPanel.setVisible(true);
				viewJuniorPlayerPanel.setVisible(false);
				viewSeniorPlayerPanel.setVisible(false);
				selectPlayerTypeToViewPanel.setVisible(false);
				squadManagementPanel.setVisible(false);
				cmbSelectCoach.setModel(new DefaultComboBoxModel(myController.getCoachList().toArray()));
			}
		});
		btnViewCoaches.setLayout(null);
		btnViewCoaches.setBackground(Color.LIGHT_GRAY);
		btnViewCoaches.setBounds(0, 353, 205, 60);
		sidePanel.add(btnViewCoaches);
		
		JLabel lblViewCoaches = new JLabel("View Coaches");
		lblViewCoaches.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		lblViewCoaches.setBounds(40, 11, 130, 38);
		btnViewCoaches.add(lblViewCoaches);
		
		/**
		 * Button to take the user to the view players panel
		 */
		JPanel btnViewPlayers = new JPanel();
		btnViewPlayers.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				welcomePanel.setVisible(false);
				newCoachPanel.setVisible(false);
				editExistingCoachPanel.setVisible(false);
				newJuniorPlayerPanel.setVisible(false);
				newSeniorPlayerPanel.setVisible(false);
				newPlayerTypePanel.setVisible(false);
				editJuniorPlayerPanel.setVisible(false);
				editSeniorPlayerPanel.setVisible(false);
				selectPlayerTypeToEditPanel.setVisible(false);
				viewCoachPanel.setVisible(false);
				viewJuniorPlayerPanel.setVisible(false);
				viewSeniorPlayerPanel.setVisible(false);
				selectPlayerTypeToViewPanel.setVisible(true);
				squadManagementPanel.setVisible(false);
				cmbViewSenior.setModel(new DefaultComboBoxModel(myController.getSeniorList().toArray()));
				cmbViewJuniorPlayer.setModel(new DefaultComboBoxModel(myController.getJuniorList().toArray()));
			}
		});
		btnViewPlayers.setLayout(null);
		btnViewPlayers.setBackground(Color.GRAY);
		btnViewPlayers.setBounds(0, 413, 205, 60);
		sidePanel.add(btnViewPlayers);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("View Players");
		lblNewLabel_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		lblNewLabel_1_1_1.setBounds(41, 11, 130, 38);
		btnViewPlayers.add(lblNewLabel_1_1_1);
		
		/**
		 * Button to take the user to the squad management panel
		 */
		JPanel btnSquadManagement = new JPanel();
		btnSquadManagement.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				welcomePanel.setVisible(false);
				newCoachPanel.setVisible(false);
				editExistingCoachPanel.setVisible(false);
				newJuniorPlayerPanel.setVisible(false);
				newSeniorPlayerPanel.setVisible(false);
				newPlayerTypePanel.setVisible(false);
				editJuniorPlayerPanel.setVisible(false);
				editSeniorPlayerPanel.setVisible(false);
				selectPlayerTypeToEditPanel.setVisible(false);
				viewCoachPanel.setVisible(false);
				viewJuniorPlayerPanel.setVisible(false);
				viewSeniorPlayerPanel.setVisible(false);
				selectPlayerTypeToViewPanel.setVisible(false);
				squadManagementPanel.setVisible(true);
				listAllSquads.setListData(myController.getSquadList().toArray());
			}
		});
		btnSquadManagement.setLayout(null);
		btnSquadManagement.setBackground(Color.LIGHT_GRAY);
		btnSquadManagement.setBounds(0, 474, 205, 60);
		sidePanel.add(btnSquadManagement);
		
		JLabel lblAddSquad = new JLabel("Squad Management");
		lblAddSquad.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		lblAddSquad.setBounds(40, 11, 130, 38);
		btnSquadManagement.add(lblAddSquad);
		
		JLabel lblNewLabel_2 = new JLabel("Simply Rugby");
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setFont(new Font("Segoe UI", Font.BOLD | Font.ITALIC, 25));
		lblNewLabel_2.setBounds(20, 42, 185, 37);
		sidePanel.add(lblNewLabel_2);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(20, 90, 161, 2);
		sidePanel.add(separator);
		
		/**
		 * Button to log the user out
		 */
		JPanel btnLogout = new JPanel();
		btnLogout.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				myController.logout();
			}
		});
		btnLogout.setLayout(null);
		btnLogout.setBackground(Color.LIGHT_GRAY);
		btnLogout.setBounds(0, 565, 205, 60);
		sidePanel.add(btnLogout);
		
		JLabel lblLogout = new JLabel("Logout");
		lblLogout.setHorizontalAlignment(SwingConstants.CENTER);
		lblLogout.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		lblLogout.setBounds(40, 11, 130, 38);
		btnLogout.add(lblLogout);
		
		welcomePanel.setVisible(true);
		newPlayerTypePanel.setVisible(false);
		selectPlayerTypeToEditPanel.setVisible(false);
		selectPlayerTypeToViewPanel.setVisible(false);
		
	}
	
	/**
	 * Display message.
	 *
	 * @param message the message
	 */
	private void displayMessage(String message) {
		JOptionPane.showMessageDialog(this, message);
	}
}

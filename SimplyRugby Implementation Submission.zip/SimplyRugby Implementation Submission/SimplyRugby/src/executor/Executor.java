package executor;

import userInterfaces.Controller;


/**
 * @author: Liam Irvine
 * The Class Executor.
 */
public class Executor {

	/**
	 * The main method.
	 * Calls the controller when the program is launched.
	 */
	public static void main(String[] args) {
		Controller myController = new Controller();
	}
}

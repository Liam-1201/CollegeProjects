package services;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.stream.Stream;

import helpers.FileHelper;
import interfaces.IMemberServiceInterface;
import models.Member;

/**
 * @author: Liam Irvine
 * The Class MemberService.
 * This class handles the creation and manipulation of Member objects.
 * Implements IMemberServiceInterface
 */
public class MemberService implements IMemberServiceInterface {
	
	/** The member list. */
	private ArrayList<Member> memberList;
	
	/** The file helper. */
	private FileHelper fileHelper;
	
	/** The file path. */
	private String filePath = "members.ser";
	
	/**
	 * Instantiates a new member service.
	 */
	public MemberService() {
		fileHelper = new FileHelper(filePath);
		this.memberList = new ArrayList<Member>();
		try {
			deserialiseMembers();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		//createUsers();
	}
	
	/**
	 * Deserialise members.
	 *
	 * @return the array list
	 */
	@SuppressWarnings("unchecked")
	public ArrayList<Member> deserialiseMembers() {
		
		try {
			FileInputStream fileIn = new FileInputStream("members.ser");
			ObjectInputStream objIn = new ObjectInputStream(fileIn);
			
			memberList = (ArrayList<Member>) objIn.readObject();
			
			objIn.close();
			fileIn.close();
		} catch (IOException e1) {
			e1.printStackTrace();
		} catch (ClassNotFoundException e2) {
			// TODO Add exception handler
		}
		return memberList;
	}
	
	/**
	 * Login.
	 *
	 * @param username the username
	 * @param password the password
	 * @return the member
	 */
	@Override
	public Member login(String username, String password) {
		Iterator<Member> iterator = memberList.iterator();
		
		while(iterator.hasNext()) {
			Member currentPerson = iterator.next();
			
			if (currentPerson.getUsername().equals(username) & currentPerson.getPassword().equals(password)) {
				return currentPerson;
			}
		}
		
		// return
		return null;
	}
	
	/**
	 * Creates the new coach.
	 *
	 * @param newCoach the new coach
	 * @return true, if successful
	 */
	@Override
	public boolean createNewCoach(Member newCoach) {
		Member isCoachExisting = convertMemberListToStream()
				.filter(x -> newCoach.getSRUNumber().equals(x.getSRUNumber()))
				.findFirst()
				.orElse(null);
		
		if (isCoachExisting != null) {
			return false;
		}
		
		this.memberList.add(newCoach);
		this.fileHelper.saveToFile(this.memberList);
		
		return true;
	}

	/**
	 * Edits the coach.
	 *
	 * @param newCoach the new coach
	 * @return true, if successful
	 */
	@Override
	public boolean editCoach(Member newCoach) {
		int i = 0;
		for (Member member: memberList) {
			if (newCoach.getSRUNumber().equals((member.getSRUNumber()))) {
				newCoach.setCoach(member.getCoach());
				newCoach.setIsAdmin(member.getIsAdmin());
				this.memberList.set(i, newCoach);
				this.fileHelper.saveToFile(this.memberList);
				return true;
			}
			i++;
		}
		return false;
	}
	
	
	/**
	 * Gets the coach list.
	 *
	 * @return the coach list
	 */
	@Override
	public ArrayList<Member> getCoachList() {
		return this.memberList;
	}

	/**
	 * Convert member list to stream.
	 *
	 * @return the stream
	 */
	private Stream<Member> convertMemberListToStream() {
		return this.memberList.stream();
	}
	
	/**
	 * Creates the users.
	 */
	/*private void createUsers() {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/MM/yyyy");
		String date = "01/01/2000";
		memberList.add(new Member("admin", "admin", "admin", "admin", true, "admin", "admin", LocalDate.parse(date, formatter), "admin", "admin", "admin", false, null));
		this.fileHelper.saveToFile(this.memberList);
	}*/
	
	
}

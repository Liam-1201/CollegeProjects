package services;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.stream.Stream;

import helpers.FileHelper;
import interfaces.IJuniorServiceInterface;
import models.JuniorPlayer;
import models.Skill;
import models.SkillCategory;



/**
 * @author: Liam Irvine
 * The Class JuniorService.
 * This class handles the creation and manipulation of JuniorPlayer objects.
 * Implements IJuniorServiceInterface
 */
public class JuniorService implements IJuniorServiceInterface{
	
	/** The junior list. */
	private ArrayList<JuniorPlayer> juniorList;
	
	/** The file helper. */
	private FileHelper fileHelper;
	
	/** The file path. */
	private String filePath = "junior.ser";
	
	/**
	 * Instantiates a new junior service.
	 */
	public JuniorService() {
		fileHelper = new FileHelper(filePath);
		this.juniorList = new ArrayList<JuniorPlayer>();
		deserialiseJuniors();
	}
	
	/**
	 * Deserialise juniors.
	 *
	 * @return the array list
	 */
	@SuppressWarnings("unchecked")
	public ArrayList<JuniorPlayer> deserialiseJuniors() {
		
		try {
			FileInputStream fileIn = new FileInputStream("junior.ser");
			ObjectInputStream objIn = new ObjectInputStream(fileIn);
			
			juniorList = (ArrayList<JuniorPlayer>) objIn.readObject();
			
			objIn.close();
			fileIn.close();
		} catch (IOException e1) {
			
		} catch (ClassNotFoundException e2) {
			
		}
		return juniorList;
	}
	
	/**
	 * Creates the new junior.
	 *
	 * @param newJunior the new junior
	 * @return true, if successful
	 */
	@Override
	public boolean createNewJunior(JuniorPlayer newJunior) {
		JuniorPlayer isSeniorExisting = convertJuniorPlayerListToStream()
				.filter(x -> newJunior.getSRUNumber().equals(x.getSRUNumber()))
				.findFirst()
				.orElse(null);
		
		if (isSeniorExisting != null) {
			return false;
		}
		
		this.juniorList.add(newJunior);
		this.fileHelper.saveToFile(this.juniorList);
		
		return true;
	}

	/**
	 * Edits the junior.
	 *
	 * @param selectedJunior the selected junior
	 * @return true, if successful
	 */
	@Override
	public boolean editJunior(JuniorPlayer selectedJunior) {
		int i = 0;
		for (JuniorPlayer player: juniorList) {
			if (selectedJunior.getSRUNumber().equals(player.getSRUNumber())) {
				this.juniorList.set(i, selectedJunior);
				this.fileHelper.saveToFile(this.juniorList);
				return true;
			}
			i++;
		}
		return false;
	}
	
	/**
	 * Save player skills.
	 *
	 * @param player the player
	 * @param standard the standard skill
	 * @param spin the spin skill
	 * @param pop the pop skill
	 * @param passingNotes the passing notes
	 * @param front the front skill
	 * @param rear the rear skill
	 * @param side the side skill
	 * @param scrabble the scrabble skill
	 * @param tacklingNotes the tackling notes
	 * @param drop the drop skill
	 * @param punt the punt skill
	 * @param grubber the grubber skill
	 * @param goal the goal skill
	 * @param kickingNotes the kicking notes
	 * @return true, if successful
	 */
	@Override
	public boolean savePlayerSkills(JuniorPlayer player, int standard, int spin, int pop, String passingNotes, int front,
			int rear, int side, int scrabble, String tacklingNotes, int drop, int punt, int grubber, int goal,
			String kickingNotes) {
		
		ArrayList<SkillCategory> skillList = player.getSkills();
		boolean checkIsNull = skillList.isEmpty();
		if (!checkIsNull) {
			player.clearSkills();
		}
		
		try {
			SkillCategory passingCategory = new SkillCategory();
			passingCategory.setCategoryName("Passing");
			passingCategory.setNotes(passingNotes);
			Skill standardSkill = new Skill("Standard", standard);
			passingCategory.addSkillToList(standardSkill);
			Skill spinSkill = new Skill("Spin", spin);
			passingCategory.addSkillToList(spinSkill);
			Skill popSkill = new Skill("Pop", pop);
			passingCategory.addSkillToList(popSkill);
			player.addSkillCat(passingCategory);
			
			SkillCategory tacklingCategory = new SkillCategory();
			tacklingCategory.setCategoryName("Tackling");
			tacklingCategory.setNotes(tacklingNotes);
			Skill frontSkill = new Skill("Front", front);
			tacklingCategory.addSkillToList(frontSkill);
			Skill rearSkill = new Skill("Rear", rear);
			tacklingCategory.addSkillToList(rearSkill);
			Skill sideSkill = new Skill("Side", side);
			tacklingCategory.addSkillToList(sideSkill);
			Skill scrabbleSkill = new Skill("Scrabble", scrabble);
			tacklingCategory.addSkillToList(scrabbleSkill);
			player.addSkillCat(tacklingCategory);
			
			SkillCategory kickingCategory = new SkillCategory();
			kickingCategory.setCategoryName("Kicking");
			kickingCategory.setNotes(kickingNotes);
			Skill dropSkill = new Skill("Drop", drop);
			kickingCategory.addSkillToList(dropSkill);
			Skill puntSkill = new Skill("Punt", punt);
			kickingCategory.addSkillToList(puntSkill);
			Skill grubberSkill = new Skill("Grubber", grubber);
			kickingCategory.addSkillToList(grubberSkill);
			Skill goalSkill = new Skill("Goal", goal);
			kickingCategory.addSkillToList(goalSkill);
			player.addSkillCat(kickingCategory);
			
			int i = 0;
			for (JuniorPlayer junior: juniorList) {
				if (junior.getSRUNumber().equals(player.getSRUNumber())) {
					juniorList.set(i, player);
					this.fileHelper.saveToFile(this.juniorList);
				}
				i++;
			}
			return true;
		} catch (Exception e1) {
			e1.printStackTrace();
			return false;
		}
	}

	/**
	 * Gets the junior list.
	 *
	 * @return the junior list
	 */
	@Override
	public ArrayList<JuniorPlayer> getJuniorList() {
		return this.juniorList;
	}

	
	/**
	 * Convert junior player list to stream.
	 *
	 * @return the stream
	 */
	private Stream<JuniorPlayer> convertJuniorPlayerListToStream() {
		return this.juniorList.stream();
	}

	
}

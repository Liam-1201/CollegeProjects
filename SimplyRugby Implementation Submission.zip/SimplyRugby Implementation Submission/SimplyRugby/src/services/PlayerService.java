package services;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.stream.Stream;

import helpers.FileHelper;
import interfaces.IPlayerServiceInterface;
import models.Player;
import models.Skill;
import models.SkillCategory;


/**
 * @author: Liam Irvine
 * The Class PlayerService.
 * This class handles the creation and manipulation of Player objects.
 * Implements IPlayerServiceInterface
 */
public class PlayerService implements IPlayerServiceInterface{
	
	/** The player list. */
	private ArrayList<Player> playerList;
	
	/** The file helper. */
	private FileHelper fileHelper;
	
	/** The file path. */
	private String filePath = "players.ser";
	
	/**
	 * Instantiates a new player service.
	 */
	public PlayerService() {
		fileHelper = new FileHelper(filePath);
		this.playerList = new ArrayList<Player>();
		deserialisePlayers();
		//createPlayers();
	}

	/**
	 * Creates the new senior.
	 *
	 * @param newSenior the new senior
	 * @return true, if successful
	 */
	@Override
	public boolean createNewSenior(Player newSenior) {
		Player isSeniorExisting = convertPlayerListToStream()
				.filter(x -> newSenior.getSRUNumber().equals(x.getSRUNumber()))
				.findFirst()
				.orElse(null);
		
		if (isSeniorExisting != null) {
			return false;
		}
		
		this.playerList.add(newSenior);
		this.fileHelper.saveToFile(this.playerList);
		
		return true;
	}

	/**
	 * Edits the senior.
	 *
	 * @param newSenior the new senior
	 * @return true, if successful
	 */
	@Override
	public boolean editSenior(Player newSenior) {
		int i = 0;
		for (Player player: playerList) {
			if (newSenior.getSRUNumber().equals(player.getSRUNumber())) {
				this.playerList.set(i, newSenior);
				this.fileHelper.saveToFile(this.playerList);
				return true;
			}
			i++;
		}
		return false;
	}

	/**
	 * Gets the senior list.
	 *
	 * @return the senior list
	 */
	@Override
	public ArrayList<Player> getSeniorList() {
		return this.playerList;
	}
	
	/**
	 * Save player skills.
	 *
	 * @param player the player
	 * @param standard the standard skill
	 * @param spin the spin skill
	 * @param pop the pop skill
	 * @param passingNotes the passing notes
	 * @param front the front skill
	 * @param rear the rear skill
	 * @param side the side skill
	 * @param scrabble the scrabble skill
	 * @param tacklingNotes the tackling notes
	 * @param drop the drop skill
	 * @param punt the punt skill
	 * @param grubber the grubber skill
	 * @param goal the goal skill
	 * @param kickingNotes the kicking notes
	 * @return true, if successful
	 */
	@Override
	public boolean savePlayerSkills(Player player, int standard, int spin, int pop, String passingNotes, int front,
			int rear, int side, int scrabble, String tacklingNotes, int drop, int punt, int grubber, int goal,
			String kickingNotes) {
		
		ArrayList<SkillCategory> skillList = player.getSkills();
		boolean checkIsNull = skillList.isEmpty();
		if (!checkIsNull) {
			player.clearSkills();
		}
		
		try {
			SkillCategory passingCategory = new SkillCategory();
			passingCategory.setCategoryName("Passing");
			passingCategory.setNotes(passingNotes);
			Skill standardSkill = new Skill("Standard", standard);
			passingCategory.addSkillToList(standardSkill);
			Skill spinSkill = new Skill("Spin", spin);
			passingCategory.addSkillToList(spinSkill);
			Skill popSkill = new Skill("Pop", pop);
			passingCategory.addSkillToList(popSkill);
			player.addSkillCat(passingCategory);
			
			SkillCategory tacklingCategory = new SkillCategory();
			tacklingCategory.setCategoryName("Tackling");
			tacklingCategory.setNotes(tacklingNotes);
			Skill frontSkill = new Skill("Front", front);
			tacklingCategory.addSkillToList(frontSkill);
			Skill rearSkill = new Skill("Rear", rear);
			tacklingCategory.addSkillToList(rearSkill);
			Skill sideSkill = new Skill("Side", side);
			tacklingCategory.addSkillToList(sideSkill);
			Skill scrabbleSkill = new Skill("Scrabble", scrabble);
			tacklingCategory.addSkillToList(scrabbleSkill);
			player.addSkillCat(tacklingCategory);
			
			SkillCategory kickingCategory = new SkillCategory();
			kickingCategory.setCategoryName("Kicking");
			kickingCategory.setNotes(kickingNotes);
			Skill dropSkill = new Skill("Drop", drop);
			kickingCategory.addSkillToList(dropSkill);
			Skill puntSkill = new Skill("Punt", punt);
			kickingCategory.addSkillToList(puntSkill);
			Skill grubberSkill = new Skill("Grubber", grubber);
			kickingCategory.addSkillToList(grubberSkill);
			Skill goalSkill = new Skill("Goal", goal);
			kickingCategory.addSkillToList(goalSkill);
			player.addSkillCat(kickingCategory);
			
			int i = 0;
			for (Player senior: playerList) {
				if (senior.getSRUNumber().equals(player.getSRUNumber())) {
					playerList.set(i, player);
					this.fileHelper.saveToFile(this.playerList);
				}
				i++;
			}
			return true;
		} catch (Exception e1) {
			return false;
		}
	}
	
	/**
	 * Deserialise players.
	 *
	 * @return the array list
	 */
	@SuppressWarnings("unchecked")
	public ArrayList<Player> deserialisePlayers() {
		
		try {
			FileInputStream fileIn = new FileInputStream("players.ser");
			ObjectInputStream objIn = new ObjectInputStream(fileIn);
			
			playerList = (ArrayList<Player>) objIn.readObject();
			
			objIn.close();
			fileIn.close();
		} catch (IOException e1) {
			
		} catch (ClassNotFoundException e2) {
			
		}
		return playerList;
	}
	
	/**
	 * Convert player list to stream.
	 *
	 * @return the stream
	 */
	private Stream<Player> convertPlayerListToStream() {
		return this.playerList.stream();
	}
	
	/**
	 * Creates the players.
	 */
	/*private void createPlayers() {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/MM/yyyy");
		String date = "01/01/2000";
		playerList.add(new Player("senior", "senior", null, null, false, "senior", "senior", LocalDate.parse(date, formatter), "senior", "senior", "senior", false, null, null, "senior", "senior", "senior", "senior", "senior", Position.Centre, SquadCategory.senior));
	}*/
}

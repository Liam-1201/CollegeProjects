package services;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.stream.Stream;

import helpers.FileHelper;
import interfaces.ISquadServiceInterface;
import models.Member;
import models.Player;
import models.Squad;


/**
 * @author: Liam Irvine
 * The Class SquadService.
 * This class handles the creation and manipulation of Squad objects.
 * Implements ISquadServiceInterface
 */
public class SquadService implements ISquadServiceInterface{
	
	/** The squad list. */
	private ArrayList<Squad> squadList;
	
	/** The file helper. */
	private FileHelper fileHelper;
	
	/** The file path. */
	private String filePath = "squads.ser";
	
	/**
	 * Instantiates a new squad service.
	 */
	public SquadService() {
		this.squadList = new ArrayList<Squad>();
		fileHelper = new FileHelper(filePath);
		//generateStaticData();
		deserialiseSquads();
	}
	
	/**
	 * Deserialise squads.
	 *
	 * @return the array list
	 */
	@SuppressWarnings("unchecked")
	public ArrayList<Squad> deserialiseSquads() {
		
		try {
			FileInputStream fileIn = new FileInputStream("squads.ser");
			ObjectInputStream objIn = new ObjectInputStream(fileIn);
			
			squadList = (ArrayList<Squad>) objIn.readObject();
			
			objIn.close();
			fileIn.close();
		} catch (IOException e1) {
			e1.printStackTrace();
		} catch (ClassNotFoundException e2) {
			// TODO Add exception handler
		}
		return squadList;
	}

	/**
	 * Creates the squad.
	 *
	 * @param newSquad the new squad
	 * @return true, if successful
	 */
	@Override
	public boolean createSquad(Squad newSquad) {
		Squad isSquadExisting = convertSquadListToStream()
				.filter(x -> newSquad.getSquadName().equals(x.getSquadName()))
				.findFirst()
				.orElse(null);
		
		if (isSquadExisting != null) {
			return false;
		}
		
		this.squadList.add(newSquad);
		this.fileHelper.saveToFile(this.squadList);
		return true;
	}
	
	/**
	 * Rename squad.
	 *
	 * @param selectedSquad the selected squad
	 * @param newName the new name
	 * @return true, if successful
	 */
	@Override
	public boolean renameSquad(Squad selectedSquad, String newName) {
		int i = 0;
		for (Squad squad: squadList) {
			if (selectedSquad.getSquadName().equals(squad.getSquadName())) {
				squad.setSquadName(newName);
				squadList.set(i, squad);
				this.fileHelper.saveToFile(this.squadList);
				return true;
			}
			i++;
		}
		return false;
	}
	
	/**
	 * Delete squad.
	 *
	 * @param selectedSquad the selected squad
	 * @return true, if successful
	 */
	@Override
	public boolean deleteSquad(Squad selectedSquad) { 
		int i = 0;
		for (Squad squad: squadList) {
			if (selectedSquad.getSquadName().equals(squad.getSquadName())) {
				squadList.remove(i);
				this.fileHelper.saveToFile(this.squadList);
				return true;
			}
			i++;
		}
		return false;
	}
	
	/**
	 * Adds the coach.
	 *
	 * @param coach the coach
	 */
	@Override
	public void addCoach(Member coach) {
		int i = 0;
		for (Squad squad: squadList) {
			if (coach.getSquad().equals(squad)) {
				squad.setCoach(coach);
				squadList.set(i, squad);
				this.fileHelper.saveToFile(this.squadList);
			}
			i++;
		}
	}
	
	/**
	 * Adds the player.
	 *
	 * @param newPlayer the new player
	 */
	@Override
	public void addPlayer(Player newPlayer) {
		for (Squad squad: squadList) {
			if (squad.equals(newPlayer.getSquad())) {
				squad.addPlayerToList(newPlayer);
				this.fileHelper.saveToFile(this.squadList);
			}
		}
	}
	
	/**
	 * Edits the player.
	 *
	 * @param newPlayer the new player
	 */
	@Override
	public void editPlayer(Player newPlayer) {
		int i = 0;
		for (Squad squad: squadList) {
			if (squad.equals(newPlayer.getSquad())) {
				squad.editPlayerToList(i, newPlayer);
				this.fileHelper.saveToFile(this.squadList);
			}
			i++;
		}
	}
	
	/**
	 * Delete player.
	 *
	 * @param delPlayer the player to delete
	 */
	@Override
	public void deletePlayer(Player delPlayer) {
		int i = 0;
		for (Squad squad: squadList) {
			if (squad.equals(delPlayer.getSquad())) {
				squad.deletePlayerFromList(i);
				this.fileHelper.saveToFile(this.squadList);
			}
			i++;
		}
	}
	
	/**
	 * Gets the squad object.
	 *
	 * @param coach the coach
	 * @return the squad object
	 */
	@Override
	public Squad getSquadObject(Member coach) {
		for (Squad squad: squadList) {
			if (squad.getCoach().equals(coach)) {
				return squad;
			}
		}
		return null;
	}
	
	/**
	 * Gets the squad list.
	 *
	 * @return the squad list
	 */
	@Override
	public ArrayList<Squad> getSquadList() {
		return this.squadList;
	}
	
	/**
	 * Convert squad list to stream.
	 *
	 * @return the stream
	 */
	private Stream<Squad> convertSquadListToStream() {
		return this.squadList.stream();
	}

	/**
	 * Generate static data.
	 */
	/*private void generateStaticData() {
		Squad squad1 = new Squad("Squad junior", null, null, SquadCategory.junior);
		Squad squad2 = new Squad("Squad senior", null, null, SquadCategory.senior);
		
		this.squadList.add(squad1);
		this.squadList.add(squad2);
	}*/

	



	

	

	

	

	



	
}

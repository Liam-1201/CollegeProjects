package interfaces;

import java.util.ArrayList;

import models.Member;
import models.Player;
import models.Squad;

/**
 * @author Liam Irvine
 * The Interface ISquadServiceInterface.
 * This interface is implemented to create the methods required by the SquadService
 */
public interface ISquadServiceInterface {
	
	/**
	 * Creates the squad.
	 *
	 * @param newSquad the new squad
	 * @return true, if successful
	 */
	boolean createSquad(Squad newSquad);
	
	/**
	 * Gets the squad list.
	 *
	 * @return the squad list
	 */
	ArrayList<Squad> getSquadList();
	
	/**
	 * Delete squad.
	 *
	 * @param selectedSquad the selected squad
	 * @return true, if successful
	 */
	boolean deleteSquad(Squad selectedSquad);
	
	/**
	 * Rename squad.
	 *
	 * @param selectedSquad the selected squad
	 * @param newName the new name
	 * @return true, if successful
	 */
	boolean renameSquad(Squad selectedSquad, String newName);
	
	/**
	 * Adds the coach.
	 *
	 * @param coach the coach
	 */
	void addCoach (Member coach);
	
	/**
	 * Adds the player.
	 *
	 * @param newPlayer the new player
	 */
	void addPlayer (Player newPlayer);
	
	/**
	 * Gets the squad object.
	 *
	 * @param coach the coach
	 * @return the squad object
	 */
	Squad getSquadObject (Member coach);
	
	/**
	 * Edits the player.
	 *
	 * @param newPlayer the new player
	 */
	void editPlayer (Player newPlayer);
	
	/**
	 * Delete player.
	 *
	 * @param delPlayer the player to delete
	 */
	void deletePlayer (Player delPlayer);
}

package interfaces;

import java.util.ArrayList;

import models.Player;

/**
 * @author: Liam Irvine
 * The Interface IPlayerServiceInterface.
 * This interface is implemented to create the methods required by the PlayerService
 */
public interface IPlayerServiceInterface {
	
	/**
	 * Creates the new senior.
	 *
	 * @param newSenior the new senior
	 * @return true, if successful
	 */
	boolean createNewSenior (Player newSenior);
	
	/**
	 * Edits the senior.
	 *
	 * @param newSenior the new senior
	 * @return true, if successful
	 */
	boolean editSenior (Player newSenior);
	
	/**
	 * Gets the senior list.
	 *
	 * @return the senior list
	 */
	ArrayList<Player> getSeniorList();
	
	/**
	 * Save player skills.
	 *
	 * @param senior the senior skill
	 * @param standard the standard skill
	 * @param spin the spin skill
	 * @param pop the pop skill
	 * @param passingNotes the passing notes
	 * @param front the front skill
	 * @param rear the rear skill
	 * @param side the side skill
	 * @param scrabble the scrabble skill
	 * @param tacklingNotes the tackling notes
	 * @param drop the drop skill
	 * @param punt the punt skill
	 * @param grubber the grubber skill
	 * @param goal the goal skill
	 * @param kickingNotes the kicking notes
	 * @return true, if successful 
	 */
	boolean savePlayerSkills(Player senior, int standard, int spin, int pop, String passingNotes, 
			int front, int rear, int side, int scrabble, String tacklingNotes, 
			int drop, int punt, int grubber, int goal, String kickingNotes);
}

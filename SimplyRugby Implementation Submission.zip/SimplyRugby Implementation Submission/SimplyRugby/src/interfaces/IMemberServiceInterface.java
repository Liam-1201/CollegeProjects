package interfaces;

import java.util.ArrayList;

import models.Member;


/**
 * @author: Liam Irvine
 * The Interface IMemberServiceInterface.
 * This interface is implemented to create the methods required by the MemberService
 */
public interface IMemberServiceInterface {
	
	/**
	 * Login.
	 *
	 * @param username the username
	 * @param password the password
	 * @return the member
	 */
	Member login (String username, String password);
	
	/**
	 * Creates the new coach.
	 *
	 * @param newCoach the new coach
	 * @return true, if successful
	 */
	boolean createNewCoach (Member newCoach);
	
	/**
	 * Edits the coach.
	 *
	 * @param newCoach the new coach
	 * @return true, if successful
	 */
	boolean editCoach (Member newCoach);
	
	/**
	 * Gets the coach list.
	 *
	 * @return the coach list
	 */
	ArrayList<Member> getCoachList();
}

﻿#include <iostream>
#include <string>
using namespace std;



struct stack
{
	int top = 0; // Variable "top" as type int is declared
	int arrSize = 0;
	string items[19]; // Variable "items" of type string is declared as an array
};

// Stack for operators is declared
stack operators;
stack* operatorPtr = &operators;

// Stacks used for the queue is declared
stack operandsQueue1;
stack* operandQueuePtr1 = &operandsQueue1;
stack operandsQueue2;
stack* operandQueuePtr2 = &operandsQueue2;

// Functions are declared
bool isEmpty(stack theStack);
void queuePush(stack queue1, stack* queue1ptr, stack queue2, stack* queue2ptr);
void queuePop(stack queue1, stack* ptr);
void add(string value, stack theStack, stack* ptr);
string remove(stack theStack, stack* ptr);
int size(stack theStack);
void init(string characters);
void enQueue(string value);
string deQueue();



// Function isEmpty is declared, returns a bool
bool isEmpty(stack theStack) {
	// If statement to check if top is <= 0
	if (theStack.top <= 0)
		return true; // Returns the value true
	else
		return false; // Returns the value false
}

// Function to the top value from queue 1 to queue 2
void queuePush(stack queue1, stack* queue1ptr, stack queue2, stack* queue2ptr) {
	queue2ptr->top = queue2.top + 1;
	queue2ptr->items[queue2.top] = queue1ptr->items[queue1ptr->top - 1];
}

// reduces the queues top value by 1
void queuePop(stack queue1, stack* ptr) {
	ptr->top = queue1.top - 1;
}

// function to add a new value to the top of the stack
void add(string value, stack theStack, stack* ptr) {
	ptr->top = theStack.top + 1;
	ptr->items[theStack.top] = value; // Sets the value of ptr.items position "top" to the value passed
	
}

// Function remove is declared, returns an int
string remove(stack theStack, stack* ptr) {
	ptr->top = theStack.top - 1; // Sets variable "top" to top -1
	string item = theStack.items[theStack.top - 1]; // String takes the top value of the stack
	return item; // Returns the value of the new value in the position of the new top
}

// Function size is declared, returns an int
int size(stack theStack) {
	return theStack.top; // Returns the top value of the stack
}

// Function enQueue is declared, takes a string value
// Function adds a new value to the queue
void enQueue(string value) {
	// If queue1 is not empty, execute code
	while (!isEmpty(operandsQueue1))
	{
		// Pushes all values from queue1 to queue2
		queuePush(operandsQueue1, operandQueuePtr1, operandsQueue2, operandQueuePtr2);
		queuePop(operandsQueue1, operandQueuePtr1);
	}

	// Add the new value to queue1
	add(value, operandsQueue1, operandQueuePtr1);

	// If queue2 is not empty, execute code
	while (!isEmpty(operandsQueue2))
	{
		// Pushes all values from queue2 to queue1
		queuePush(operandsQueue2, operandQueuePtr2, operandsQueue1, operandQueuePtr1);
		queuePop(operandsQueue2, operandQueuePtr2);
	}
}

// Function deQueue is declared, returns a string value
string deQueue() {
	// string is declared and set to the top value in the queue
	string top = operandQueuePtr1->items[operandsQueue1.top - 1];
	// top value is removed from the queue
	queuePop(operandsQueue1, operandQueuePtr1);
	return top; // top string returned
}

// Function precedence is declared, returns an integer and takes a string value
// Function decides if the passed operator should move left or right based on its priority
int precedence(string op) {
	if (op == "+"|| op == "-") {
		return 1;
	}
	if (op == "*"|| op == "/") {
		return 2;
	}
	return 0;
}

// Function init is declared, takes a string value
void init(string characters) {
	int i;

	// For loop to loop through all characters in the string value
	for (i = 0; i < characters.length(); i++) {
		// string currentChar is declared and is set to the current character in the passed value
		string currentChar = "";

		switch (characters[i]) {
		case '1':
			currentChar = "1";
			break;
		case '2':
			currentChar = "2";
			break;
		case '3':
			currentChar = "3";
			break;
		case '4':
			currentChar = "4";
			break;
		case '5':
			currentChar = "5";
			break;
		case '6':
			currentChar = "6";
			break;
		case '7':
			currentChar = "7";
			break;
		case '8':
			currentChar = "8";
			break;
		case '9':
			currentChar = "9";
			break;
		case '0':
			currentChar = "0";
			break;
		case '+':
			currentChar = "+";
			break;
		case '*':
			currentChar = "*";
			break;
		case '/':
			currentChar = "/";
			break;
		case '-':
			currentChar = "-";
			break;
		case '(':
			currentChar = "(";
			break;
		case ')':
			currentChar = ")";
			break;
		}
		if (characters[i] == ' ') {
			continue;
		}
		// if the current character is '(' then add it to the stack
		else if (characters[i] == '(') {
			string parenth = "(";
			add(parenth, operators, operatorPtr);
		}
		// if the current character is a digit then add it to the queue
		else if (isdigit(characters[i])) {
			enQueue(currentChar);
		}
		// if the current character is a ')'
		// empty the stack into the queue until a '(' is found
		else if (characters[i] == ')') {
			while (!isEmpty(operators) && operators.items[operators.top - 1] != "(") {
				string op = remove(operators, operatorPtr);
				
				enQueue(op);

			}

			// remove the '(' that is found
			if (!isEmpty(operators)) {
				remove(operators, operatorPtr);
			}
		}
		else {
			// While the current operator has a higher priority, empty the stack into the queue
			while (!isEmpty(operators) && precedence(operators.items[operators.top]) >= precedence(currentChar)) {
				string op = remove(operators, operatorPtr);
				
				enQueue(op);

			}
			// Add the operator to the stack
			add(currentChar, operators, operatorPtr);
		}
	}

	// While the operator stack has values, empty the values into the queue
	while (!isEmpty(operators)) {
		string op = remove(operators, operatorPtr);
		
		enQueue(op);
	}


}

int main()
{
	int i;
	string input = "";

	// User is prompted to enter a valid expression
	cout << "Please enter a valid arithmetic expression!" << endl;
	cin >> input;

	// Prints to the user if the stack is empty
	if (isEmpty(operators)) {
		cout << endl << "Operator stack is empty" << endl;;
	}
	
	// Prints to the user if the queue is empty
	if (isEmpty(operandsQueue1)) {
		cout << "Queue is empty" << endl;
	}

	// Initialises the stacks and performs the algorithm
	init(input);

	// Prints to the user the size of the queue
	cout << "Queue has " << size(operandsQueue1) << " Values" << endl;

	// Prints the queue to the user
	cout << "Algorithm output: ";
	for (i = 0; i <= input.length(); i++) {
		cout << deQueue();
	}

	// Prints to the user if the queue is empty
	if (isEmpty(operandsQueue1)) {
		cout << endl << "Queue is empty" << endl;
	}
}

#pragma once


bool isEmpty(stack theStack);
void queuePush(stack queue1, stack* queue1ptr, stack queue2, stack* queue2ptr);
void queuePop(stack queue1, stack* ptr);
void add(string value, stack theStack, stack* ptr);
string remove(stack theStack, stack* ptr);
int size(stack theStack);
void init(string characters);
void enQueue(string value);
string deQueue();
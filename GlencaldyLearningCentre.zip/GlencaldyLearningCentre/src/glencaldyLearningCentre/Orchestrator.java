package glencaldyLearningCentre;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;


import controllers.BorrowController;
import controllers.ReserveController;
import controllers.StockController;
import controllers.UserController;
import enums.MediaType;
import enums.Membership;
import helpers.StockMediaTypeHelper;
import models.Books;
import models.Borrow;
import models.CD;
import models.Journal;
import models.LoginSession;
import models.Stock;
import models.User;
import models.Video;
import services.BorrowService;
import services.ReserveService;
import services.StockService;
import services.UserService;

// Author: Liam Irvine
// Class used to call methods required by the Executor
public class Orchestrator {
	// Required variables are made
	private BufferedReader inputReader;
	private UserService userService;
	private StockService stockService; 
	private ReserveService reserveService; 
	private BorrowService borrowService;
	private UserController userController; 
	private StockController stockController; 
	private BorrowController borrowController; 
	private ReserveController reserveController;
	
	// Constructor to initialise each variable
	public Orchestrator() throws IOException {
		inputReader = new BufferedReader(new InputStreamReader(System.in));
		userService = new UserService();
		stockService = new StockService();
		reserveService = new ReserveService(userService, stockService);
		borrowService = new BorrowService(userService, stockService);
		userController = new UserController(userService);
		stockController = new StockController(userService, stockService);
		borrowController = new BorrowController(userService, stockService, borrowService);
		reserveController = new ReserveController(userService, stockService, reserveService);
	}
	
	// Method to deserialise all files by calling deserialise methods
	public void deserialiseFiles() {
		borrowService.deserialiseBorrow();
		userService.deserialiseUsers();
		stockService.deserialiseStock();
	}
	
	// Method to log in the user
	public User login() throws IOException {
		// Ask the user to input their details
		System.out.println("Type 'exit' to leave!");
		System.out.println("Username: ");
		String userName = inputReader.readLine();
		if (userName.equals("exit")) {
			System.out.println("Goodbye!");
			System.exit(0);
		}
		System.out.println("Password: ");
		String password = inputReader.readLine();
		if (password.equals("exit")) {
			System.out.println("Goodbye!");
			System.exit(0);
		}
		String response = userController.login(userName, password);
		User user = userController.getCurrentUser();
		return user;
	}
	
	// Method to register a new user
	public User register() throws IOException {
		System.out.println("Please select the type of membership you are creating an account for: Full Member, Casual Member, Staff Member.");
		String memberShip = inputReader.readLine().toLowerCase();
		User user;
		Membership memberShipType = null;
		// Switch case to check membership type
		switch(memberShip) {
			case "full member":
				memberShipType = Membership.fullMember;
			break;
			case "casual member":
				memberShipType = Membership.casualMember;
				break;
			case "staff member":
				memberShipType = Membership.staffMember;
				break;
			default:
				System.out.println("Unknown membership type!");
				System.out.println("Please press enter to return to the menu!");
				break;
		}
		if (memberShipType == Membership.staffMember || memberShipType == Membership.fullMember
				|| memberShipType == Membership.casualMember) {
			System.out.println("Please enter your first name!");
			String firstName = inputReader.readLine();
			System.out.println("Please enter your last name!");
			String lastName = inputReader.readLine();
			System.out.println("Please enter your username!");
			String userName = inputReader.readLine();
			System.out.println("Please enter your password!");
			String password = inputReader.readLine();
			
			// Check if the user is a staff member and input staff specific entries
			if (memberShipType == Membership.staffMember) {
				System.out.println("Please enter your email!");
				String email = inputReader.readLine();
				System.out.println("Please enter your phone extension!");
				int phoneExtension = Integer.parseInt(inputReader.readLine());
				
				// Create the new user
				user = new User(UUID.randomUUID(), firstName, lastName, memberShipType, userName, password, true, false, email, phoneExtension);
				// returns if the register was successful or not
				System.out.println(userController.registerUser(user));
				return user;
			} else {
				// if the user is not a staff member, ask the user to enter the required entries
				System.out.println("Please enter your street and house number!");
				String address1 = inputReader.readLine();
				System.out.println("Please enter your town!");
				String town = inputReader.readLine();
				System.out.println("Please enter your postcode!");
				String postcode = inputReader.readLine();
				System.out.println("Please enter your telephone number!");
				String telephoneNo = inputReader.readLine();
				System.out.println("Please enter your date of birth (yyyy-mm-dd)");
				String dateCheck = inputReader.readLine();
				LocalDate dateOfBirth;
				try {
					dateOfBirth = LocalDate.parse(dateCheck);
				} catch (DateTimeParseException e) {
					System.out.println("Invalid input!");
					System.out.println("Please press enter and try again!");
					return null;
				}
				// Create the new user
				user = new User(UUID.randomUUID(), firstName, lastName, address1, town, postcode, telephoneNo, dateOfBirth, memberShipType, userName, password, true, false);
				// returns if the register was successful or not
				System.out.println(userController.registerUser(user));
				return user;
			}
		}
		
		return null;

	}

	public void casualMemberFunctionality(User user) throws IOException {
		// Prints to the user what their options are
					System.out.println("Welcome! Please enjoy the facilities that are available to you!");
					System.out.println("If you would like to change your password, press 1!");
					System.out.println("Please type 'exit' when you would like to logout!");
					String userInput = inputReader.readLine();
					// asks the user to update their password
					if (userInput.equals("1")) {
						System.out.println("What would you like to change your password to?");
						String newPassword = inputReader.readLine();
						
						userService.updateUserPassword(newPassword);
						
						System.out.println("Password updated!");
						System.out.println("Please press enter to return to the menu!");
						// if statement to check if the user wants to logout
					} else if (userInput.equals("exit")) {
						System.out.println("Thank you for coming! Goodbye!");
						// log the user out
						userService.logout();
						System.exit(0);
					}
	}
	// Method to return a list of all options to staff users
	public void staffMemberFunctionility(User user) throws IOException {
		System.out.println("Welcome! Please enjoy the facilities that are available to you!");
		System.out.println("Please press 1 to borrow "
				+ "\n2 to reserve "
				+ "\n3 to return an item "
				+ "\n4 to view the login history "
				+ "\n5 to view the loan history "
				+ "\n6 to view all users "
				+ "\n7 to create a stock item "
				+ "\n8 to edit an existing stock item "
				+ "\n9 to update your password "
				+ "\n10 to create new user "
				+ "\nor type 'exit' to logout!");
		String userChoice = inputReader.readLine();
		switch(userChoice) {
			case "1":
				System.out.println("Are you borrowing for yourself or on behalf of someone? Option: Myself/Someone");
				userChoice = inputReader.readLine().toLowerCase();
			switch (userChoice) {
				case "myself":
					borrowing(user);
					break;
				case "someone":
					User borrowUser = borrowForSomeone();
					
						if (borrowUser != null) {
							if (borrowUser.getMembership() != Membership.casualMember) {
								borrowing(borrowUser);
							} else {
								System.out.println("That user cannot borrow!");
								System.out.println("Please press enter to return to the menu!");
							}
						} else {
							System.out.println("That user does not exist! \n");
							System.out.println("Please press enter to return to the menu!");
						}
					
					
					break;
				default: 
					System.out.println("Invalid command! Please press enter!");
					break;
			}				
			break;
			case "2":
				reserveItem(user);
				break;
			case "3":
				System.out.println("Are you returning for yourself or on behalf of someone? Option: Myself/Someone");
				userChoice = inputReader.readLine().toLowerCase();
				switch (userChoice) {
				case "myself":
					returning(user);
					break;
				case "someone":
					User returnUser = returnForSomeone();
					if (returnUser != null) {
						returning(returnUser);
					} else {
						System.out.println("That user does not exist! \n");
						System.out.println("Please press enter to return to the menu!");
					}
					
					break;
				default: 
					System.out.println("Invalid command! Please press enter!");
					break;
			}	
			break;
			case "4":
				System.out.println("\nHere is all previous login sessions!");
				// sets loginSessions to a list of all login sessions
				List<LoginSession> loginSessions = userService.getAllLoginSessions();		
				// prints the login sessions
				System.out.println(loginSessions.toString());
				System.out.println("Press enter to return to the menu!");
				break;
			case "5":
				System.out.println("\nHere is all previous items borrowed!");
				
				// sets allBorrowedStock to a list of all borrowed items
				List<Borrow> allBorrowedStock = borrowService.getAllBorrowedItems();
				
				if (allBorrowedStock.isEmpty()) {
					System.out.println("No previous borrows!");
				} else {
					// prints all borrowed items to the user
					System.out.println(allBorrowedStock.toString());
				}
				System.out.println("Press enter to return to the menu!");
			break;
			case "6":
				System.out.println("\nHere is a list of all users!");
				// sets allUsers to a list of all users
				List<User> allUsers = userService.getAllUsers();
				
				// prints all users
				System.out.println(allUsers.toString());
				System.out.println("Press enter to return to the menu!");
			break;
			case "7":
				createStock(user);
			break;
			case "8":
				editStock(user);
			break;
			case "9":
				// asks the user to input a new password
				System.out.println("What would you like to change your password to?");
				String newPassword = inputReader.readLine();
				
				// sets the new password
				userService.updateUserPassword(newPassword);
				
				// prints confirmation to the user
				System.out.println("Password updated!");
				System.out.println("Press enter to return to the menu!");
			break;
			case "10":
				register();
				break;
			case "exit":
				System.out.println(userService.logout());
				System.exit(0);
				break;
			default: 
				System.out.println("Invalid command! Please press enter!");
				break;
		}
		
	}
	
	// Method to return a list of options to full members
	public void fullMemberFunctionality(User user) throws IOException {
		System.out.println("Welcome! Please enjoy the facilities that are available to you!");
		System.out.println("Please press 1 to reserve "
				+ "\n2 to view your login history "
				+ "\n3 to view your loan history "
				+ "\n4 to update your password "
				+ "\nor type 'exit' to logout!");
		String userChoice = inputReader.readLine();
		switch(userChoice) {
			case "1":
				reserveItem(user);
				break;
			case "2":
				System.out.println("\nHere is your previous login sessions!");
				// sets loginSessions to a list of all login sessions
				List<LoginSession> loginSessions = userService.getLoginSessions();		
				// prints the login sessions
				System.out.println(loginSessions.toString());
				System.out.println("Press enter to return to the menu!");
				break;
			case "3":
				System.out.println("\nHere is your previous items borrowed!");
				
				// sets allBorrowedStock to a list of all borrowed items
				List<Borrow> allBorrowedStock = borrowService.getBorrowedItems();
				
				if (allBorrowedStock.isEmpty()) {
					System.out.println("No previous borrows!");
				} else {
					// prints all borrowed items to the user
					System.out.println(allBorrowedStock.toString());
				}
				System.out.println("Press enter to return to the menu!");
			break;
			case "4":
				// asks the user to input a new password
				System.out.println("What would you like to change your password to?");
				String newPassword = inputReader.readLine();
				
				// sets the new password
				userService.updateUserPassword(newPassword);
				
				// prints confirmation to the user
				System.out.println("Password updated!");
				System.out.println("Press enter to return to the menu!");
			break;
			case "exit":
				System.out.println(userService.logout());
				System.exit(0);
				break;
			default: 
				System.out.println("Invalid command! Please press enter!");
				break;
		}
	}
	
	//Private methods
	private void borrowing(User user) throws IOException {
		// prints a list of the available items
		System.out.println("Here is a list of items that we have available!");
		if (user != null) {
			List<Stock> stocks = stockController.getStockItems(false);
				for (Stock stock: stocks) {
						System.out.println(stock);
				}
		}
		System.out.println("\nPlease enter the title of the item you would like to borrow!");
		String input = inputReader.readLine();
		// gets a list of stock items based on the title the user inputed
		List<Stock> stockItemsFound = getStockByName(input);
		
		if (stockItemsFound.isEmpty()) {
			System.out.println("No items found with that title.");
			System.out.println("Please press enter to return to the menu!");
			return;
		}
		
		// returns the list of items to the user
		for (Stock stock: stockItemsFound) {
			System.out.println(stockItemsFound);
		}
		
		System.out.println("Please enter the ID of the item you wish to borrow!");
		
		input = inputReader.readLine();
		// sets foundStock to be equal to the stock item the user wants to borrow
		Stock foundStock = null;
		try {
			foundStock = stockController.getStockItemByID(UUID.fromString(input));
		} catch (IllegalArgumentException e) {
		}
		
		if (foundStock == null) {
			System.out.println("No stock with that ID exists!");
		} else if (foundStock.getIsBorrowed()) {
			System.out.println("That item has already been borrowed!");
		} else {
			// borrows the item and prints a confirmation to the user
			borrowService.borrowStockItem(foundStock.getStockID(), user.getUserID(), user);
			System.out.println("Item borrowed!");
		}
		System.out.println("Press enter to return to the menu!");	
	}
	
	private User borrowForSomeone() throws IOException {
		System.out.println("Please enter the username of the user that wishes to borrow!");
		String input = inputReader.readLine();
		User borrowUser = userService.getUsersByUsernameSearch(input);
		return borrowUser;
	}
	private void reserveItem(User user) throws IOException {
		// prints a list of the available items
		System.out.println("Here is a list of items that we have available!");
		if (user != null) {
			List<Stock> stocks = stockController.getStockItems(false);
				for (Stock stock: stocks) {
						System.out.println(stock);
				}
		}
		System.out.println("\nPlease enter the title of the item you would like to reserve!");
		System.out.println("\nIf you wish to return to the menu, type 'exit'!");
		String input = inputReader.readLine();
		// gets a list of stock items based on the title the user inputed
		List<Stock> stockItemsFound = getStockByName(input);
		
		// If statement to return back to menu
		if (input.equals("exit")) {
			System.out.println("Please press enter to return to the menu!");
			return;
		}
		
		if (stockItemsFound.isEmpty()) {
			System.out.println("No items found with that title.");
			System.out.println("Please press enter to return to the menu!");
			return;
		}
		
		// returns the list of items to the user
		for (Stock stock: stockItemsFound) {
			System.out.println(stockItemsFound);
		}
		
		System.out.println("Please enter the ID of the item you wish to reserve!");
		
		input = inputReader.readLine();
		
		// If statement to return back to menu
		if (input.equals("exit")) {
			System.out.println("Please press enter to return to the menu!");
			return;
		}
		
		// sets foundStock to be equal to the stock item the user wants to borrow
		Stock foundStock = null;
		try {
			foundStock = stockController.getStockItemByID(UUID.fromString(input));
		} catch (IllegalArgumentException e) {
		}
	
		if (foundStock == null) {
			System.out.println("No stock with that ID exists!");
		} else if (foundStock.getIsReserved()) {
			System.out.println("That item has already been reserved!");
		} else {
			// borrows the item and prints a confirmation to the user
			reserveService.reserveItem(foundStock.getStockID(), user.getUserID());
			System.out.println("Item reserved!");
		}
		System.out.println("Press enter to return to the menu!");
	}
	private List<Stock> getStockByName(String input) {
		return stockController.getStockByStockName(input);
	}
	private void returning(User user) throws IOException {
		System.out.println("\nHere are the items you currently have to return!");
		// sets borrowedStock the the items the user has borrowed
		ArrayList<Stock> borrowedStock = borrowService.getReturnListByUserID(user.getUserID());
		
		if (borrowedStock.isEmpty()) {
			System.out.println("You currently have no borrowed items!");
		} else {
			// prints the borrowedStock to the user
			System.out.println(borrowedStock);
		
			System.out.println("Please enter the ID of the item you wish to return!");
			
			String input = inputReader.readLine();
			
			if (input == null) {
				System.out.println("You must enter an ID!");
			} else {
				// returns the item chosen and prints confirmation + cost to the user
				try {
					System.out.println(borrowController.returnStockItem(UUID.fromString(input), borrowService.getBorrowByStockID(UUID.fromString(input)).getBorrowEndDate()));
					System.out.println("The total cost for your return is: " + borrowService.applyFine(borrowService.getBorrowByStockID(UUID.fromString(input)), LocalDate.now()).toString());
				} catch (IllegalArgumentException e) {
					System.out.println("Invalid ID!");
				}
				
			}
		}
		System.out.println("Press enter to return to the menu!");
	}
	private User returnForSomeone() throws IOException {
		System.out.println("Please enter the username of the user that wishes to return!");
		String input = inputReader.readLine();
		User returnUser = userService.getUsersByUsernameSearch(input);
		return returnUser;
	}
	private void createStock(User user) throws IOException {
		System.out.println("Would you like to create a book, video, cd or journal?");
		String mediaType = inputReader.readLine();
		// switch case to check user input
		switch(mediaType) {
			case "book":
				// creates a new instance of StockMediaTypeHelper
				StockMediaTypeHelper stockMediaHelper = new StockMediaTypeHelper();
				
				// Sets values inputed by the user for a book
				System.out.println("What is the price of the book?");
				Double price = Double.parseDouble(inputReader.readLine());
				
				System.out.println("Do you want the item to be public? Y/N");
				String isPublic = inputReader.readLine();
				boolean setPublic;
				if (isPublic.equals("Y")) {
					setPublic = true;
				} else {
					setPublic = false;
				}
				
				System.out.println("What is the title of the book?");
				String title = inputReader.readLine();
				
				System.out.println("What is the name of the publisher?");
				String publisher = inputReader.readLine();
				
				System.out.println("What is the ISBN number?");
				String ISBN = inputReader.readLine();
				
				System.out.println("What is the name of the author?");
				String author = inputReader.readLine();
				
				System.out.println("What is the subject area?");
				String subjectArea = inputReader.readLine();
				
				System.out.println("What is the number of pages?");
				int noOfPages = Integer.parseInt(inputReader.readLine());
				UUID bookID = UUID.randomUUID();
				
				// Creates the new Book object
				stockMediaHelper.book = new Books(bookID, MediaType.Book, price, 
						false, false, setPublic, null, title, publisher, ISBN, author, subjectArea, 
						noOfPages);
				stockMediaHelper.stock = new Stock(bookID, MediaType.Book, price, false, false, setPublic, null, title, publisher);
				System.out.println(stockController.createStockItem(stockMediaHelper));
				break;
				
			case "video":
				// creates a new instance of StockMediaTypeHelper
				stockMediaHelper = new StockMediaTypeHelper();
				
				// Sets values inputed by the user for a video
				System.out.println("What is the price of the video?");
				price = Double.parseDouble(inputReader.readLine());
				
				System.out.println("Do you want the item to be public? Y/N");
				isPublic = inputReader.readLine();
				
				if (isPublic.equals("Y")) {
					setPublic = true;
				} else {
					setPublic = false;
				}
				
				System.out.println("What is the title of the video?");
				title = inputReader.readLine();
				
				System.out.println("What is the name of the publisher?");
				publisher = inputReader.readLine();
				
				System.out.println("What is the running time of the video?");
				String runTime = inputReader.readLine();
				
				System.out.println("What is the video format?");
				String format = inputReader.readLine();
				
				System.out.println("What is the genre of the video?");
				String genre = inputReader.readLine();
				
				System.out.print("What is the type of storage case?");
				String typeOfStorageCase = inputReader.readLine();
				
				UUID videoID = UUID.randomUUID();
				
				// Creates the new video object
				stockMediaHelper.video = new Video(videoID, MediaType.Video, price, 
						false, false, setPublic, null, title, publisher, runTime, format, genre, 
						typeOfStorageCase);
				stockMediaHelper.stock = new Stock(videoID, MediaType.Video, price, false, false, setPublic, null, title, publisher);
				System.out.println(stockController.createStockItem(stockMediaHelper));
				break;
			
			case "cd":
				// creates a new instance of StockMediaTypeHelper
				stockMediaHelper = new StockMediaTypeHelper();
				
				// Sets values inputed by the user for a CD
				System.out.println("What is the price of the cd?");
				price = Double.parseDouble(inputReader.readLine());
				
				System.out.println("Do you want the item to be public? Y/N");
				isPublic = inputReader.readLine();
				
				if (isPublic.equals("Y")) {
					setPublic = true;
				} else {
					setPublic = false;
				}
				
				System.out.println("What is the title of the CD?");
				title = inputReader.readLine();
				
				System.out.println("What is the name of the publisher?");
				publisher = inputReader.readLine();
				
				System.out.println("What is the running time of the CD?");
				runTime = inputReader.readLine();
				
				System.out.println("What is the cd type?");
				format = inputReader.readLine();
				
				System.out.println("How many tracks are on the CD?");
				int noOfTracks = Integer.parseInt(inputReader.readLine());
				
				System.out.println("Who is the artist of the CD?");
				String artist = inputReader.readLine();
				
				System.out.print("What is the type of storage case?");
				typeOfStorageCase = inputReader.readLine();
				
				UUID cdID = UUID.randomUUID();
				
				// Creates the new video object
				stockMediaHelper.cd = new CD(cdID, MediaType.CD, price, 
						false, false, setPublic, null, title, publisher, runTime, format, noOfTracks, 
						artist, typeOfStorageCase);
				stockMediaHelper.stock = new Stock(cdID, MediaType.CD, price, false, false, setPublic, null, title, publisher);
				System.out.println(stockController.createStockItem(stockMediaHelper));
				break;
				
			case "journal":
				// creates a new instance of StockMediaTypeHelper
				stockMediaHelper = new StockMediaTypeHelper();
				
				// Sets values inputed by the user for a CD
				System.out.println("What is the price of the journal?");
				price = Double.parseDouble(inputReader.readLine());
				
				System.out.println("Do you want the item to be public? Y/N");
				isPublic = inputReader.readLine().toLowerCase();
				
				if (isPublic.equals("y")) {
					setPublic = true;
				} else {
					setPublic = false;
				}
				
				System.out.println("What is the title of the journal?");
				title = inputReader.readLine();
				
				System.out.println("What is the name of the publisher?");
				publisher = inputReader.readLine();
				
				System.out.println("What is ISSN of the journal?");
				String ISSN = inputReader.readLine();
				
				System.out.println("What is the issue number of the journal?");
				String issueNumber = inputReader.readLine();
				
				System.out.println("What is the date of issue (yyyy-mm-dd)?");
				LocalDate dateOfIssue = LocalDate.parse(inputReader.readLine());
				
				System.out.println("What is the subject area?");
				subjectArea = inputReader.readLine();
				
				System.out.println("What is the number of pages?");
				noOfPages = Integer.parseInt(inputReader.readLine());
				
				UUID journalID = UUID.randomUUID();
				
				// Creates the new video object
				stockMediaHelper.journal = new Journal(journalID, MediaType.Journal, price, 
						false, false, setPublic, null, title, publisher, ISSN, issueNumber, dateOfIssue, 
						subjectArea, noOfPages);
				stockMediaHelper.stock = new Stock(journalID, MediaType.Journal, price, false, false, setPublic, null, title, publisher);
				System.out.println(stockController.createStockItem(stockMediaHelper));
				break;
			
			default:
				System.out.println("That item doesn't exist!");
				break;
		}
		System.out.println("Press enter to return to the menu!");
	}
	private void editStock(User user) throws IOException {
		System.out.println("Here is a list of all items we have!");
		if (user != null) {
			List<Stock> stocks = stockController.getStockItems(true);
				for (Stock stock: stocks) {
						System.out.println(stock);
				}
		}
		System.out.println("\nPlease enter the title of the item you would like to update!");
		String input = inputReader.readLine();
		// sets stockItemsFound to a list of stock items with the name of the users response
		List<Stock> stockItemsFound = getStockByName(input);
		
		if (stockItemsFound.isEmpty()) {
			System.out.println("No items found with that title. Please press enter and try again!");
			return;
		}
		
		// prints the list of items to the user
		for (Stock stock: stockItemsFound) {
			System.out.println(stockItemsFound);
		}
		
		System.out.println("Please enter the ID of the item you wish to update!");
		
		input = inputReader.readLine();
		// sets foundStock to be equal to the stock with the ID given
		Stock foundStock = stockController.getStockItemByID(UUID.fromString(input));

		// Creates a new StockMediaTypeHelper object
		StockMediaTypeHelper stockMediaHelper = new StockMediaTypeHelper();
		
		// Gets the media type from foundStock
		MediaType stockType = foundStock.getMediaType();
		
		
		// switch case to check user input
		switch(stockType) {
			case Book:
				System.out.println("What would you like to edit?\n");
				System.out.println("Options: 'price', 'public', 'title', 'publisher', 'ISBN', 'author', 'subject', 'pages'");
				input = inputReader.readLine().toLowerCase();
				
				stockMediaHelper.book = (Books) foundStock;
				switch(input) {
					case "price":
						// Asks the user for the inputs for a book and sets the values
						System.out.println("What is the price of the book?");
						Double price = Double.parseDouble(inputReader.readLine());
						stockMediaHelper.book.setPrice(price);
						stockService.updateStockItem(foundStock.getStockID(), stockMediaHelper);
						break;
					
					case "public":
						System.out.println("Do you want the item to be public? Y/N");
						String isPublic = inputReader.readLine().toLowerCase();
						if (isPublic.equals("y")) {
							stockMediaHelper.book.setIsPublic(true);
							stockService.updateStockItem(foundStock.getStockID(), stockMediaHelper);
						} else if (isPublic.equals("n")) {
							stockMediaHelper.book.setIsPublic(false);
							stockService.updateStockItem(foundStock.getStockID(), stockMediaHelper);
						} else {
							System.out.println("Invalid option");
						}
						break;
						
					case "title":
						System.out.println("What is the title of the book?");
						String title = inputReader.readLine();
						stockMediaHelper.book.setTitle(title);
						stockService.updateStockItem(foundStock.getStockID(), stockMediaHelper);
						break;
					
					case "publisher":
						System.out.println("What is the name of the publisher?");
						String publisher = inputReader.readLine();
						stockMediaHelper.book.setPublisher(publisher);
						stockService.updateStockItem(foundStock.getStockID(), stockMediaHelper);
						break;
						
					case "isbn":
						System.out.println("What is the ISBN number?");
						String ISBN = inputReader.readLine();
						stockMediaHelper.book.setISBN(ISBN);
						stockService.updateStockItem(foundStock.getStockID(), stockMediaHelper);
						break;
						
					case "author":
						System.out.println("What is the name of the author?");
						String author = inputReader.readLine();
						stockMediaHelper.book.setAuthor(author);
						stockService.updateStockItem(foundStock.getStockID(), stockMediaHelper);
						break;
						
					case "subject":
						System.out.println("What is the subject area?");
						String subjectArea = inputReader.readLine();
						stockMediaHelper.book.setSubjectArea(subjectArea);
						stockService.updateStockItem(foundStock.getStockID(), stockMediaHelper);
						break;
						
					case "pages":
						System.out.println("What is the number of pages?");
						int noOfPages = Integer.parseInt(inputReader.readLine());
						stockMediaHelper.book.setNoOfPages(noOfPages);
						stockService.updateStockItem(foundStock.getStockID(), stockMediaHelper);
						break;
						
					default:
						System.out.println("Invalid input!");
				}

				// Prints the edited item to the user
				System.out.println("Here is your updated item!\n");
				System.out.println(stockMediaHelper.book);
				break;
				
			case Video:
				System.out.println("What would you like to edit?");
				System.out.println("Options: 'price', 'public', 'title', 'publisher', 'runtime', 'format', 'genre', 'storage'");
				input = inputReader.readLine().toLowerCase();
				
				// Asks the user for the inputs for a video and sets the values
				stockMediaHelper.video = (Video) foundStock;
				
				switch(input) {
					case "price":
						try {
							System.out.println("What is the price of the video?");
							Double price = Double.parseDouble(inputReader.readLine());
							stockMediaHelper.video.setPrice(price);
							stockService.updateStockItem(foundStock.getStockID(), stockMediaHelper);
						} catch (Exception e) {
							System.out.println("Please enter a valid price (10.00)");
							System.out.println("Press enter to return to the menu!");
							return;
						}
						break;
						
					case "public":
						System.out.println("Do you want the item to be public? Y/N");
						String isPublic = inputReader.readLine().toLowerCase();
						
						if (isPublic.equals("n")) {
							stockMediaHelper.video.setIsPublic(true);
							stockService.updateStockItem(foundStock.getStockID(), stockMediaHelper);
						} else if (isPublic.equals("n")){
							stockMediaHelper.video.setIsPublic(false);
							stockService.updateStockItem(foundStock.getStockID(), stockMediaHelper);
						} else {
							System.out.println("Invalid option!");
						}
						break;
					
					case "title":
						System.out.println("What is the title of the video?");
						String title = inputReader.readLine();
						stockMediaHelper.video.setTitle(title);
						stockService.updateStockItem(foundStock.getStockID(), stockMediaHelper);
						break;
						
					case "publisher":
						System.out.println("What is the name of the publisher?");
						String publisher = inputReader.readLine();
						stockMediaHelper.video.setPublisher(publisher);
						stockService.updateStockItem(foundStock.getStockID(), stockMediaHelper);
						break;
						
					case "runtime":
						System.out.println("What is the running time of the video?");
						String runTime = inputReader.readLine();
						stockMediaHelper.video.setRunningTime(runTime);
						stockService.updateStockItem(foundStock.getStockID(), stockMediaHelper);
						break;
						
					case "format":
						System.out.println("What is the video format?");
						String format = inputReader.readLine();
						stockMediaHelper.video.setVideoFormat(format);
						stockService.updateStockItem(foundStock.getStockID(), stockMediaHelper);
						break;
						
					case "genre":
						System.out.println("What is the genre of the video?");
						String genre = inputReader.readLine();
						stockMediaHelper.video.setGenre(genre);
						stockService.updateStockItem(foundStock.getStockID(), stockMediaHelper);
						break;
						
					case "storage":
						System.out.print("What is the type of storage case?");
						String typeOfStorageCase = inputReader.readLine();
						stockMediaHelper.video.setTypeOfStorageCase(typeOfStorageCase);
						stockService.updateStockItem(foundStock.getStockID(), stockMediaHelper);
						break;
						
					default:
						System.out.println("Invalid input!");
				}
				
				// Prints the edited item to the user
				System.out.println("Here is your updated item!\n");
				System.out.println(stockMediaHelper.video);
				break;
				
			case CD:
				System.out.println("What would you like to edit?");
				System.out.println("Options: 'price', 'public', 'title', 'publisher', 'runtime', 'type', 'tracks', 'artist', 'storage'");
				input = inputReader.readLine().toLowerCase();
				
				stockMediaHelper.cd = (CD) foundStock;
				
				switch(input) {
					case "price":
						// Asks the user for the inputs for a CD and sets the values
						System.out.println("What is the price of the cd?");
						Double price = Double.parseDouble(inputReader.readLine());
						stockMediaHelper.cd.setPrice(price);
						stockService.updateStockItem(foundStock.getStockID(), stockMediaHelper);
						break;
						
					case "public":
						System.out.println("Do you want the item to be public? Y/N");
						String isPublic = inputReader.readLine();
				
						if (isPublic.equals("n")) {
							stockMediaHelper.video.setIsPublic(true);
							stockService.updateStockItem(foundStock.getStockID(), stockMediaHelper);
						} else if (isPublic.equals("n")){
							stockMediaHelper.video.setIsPublic(false);
							stockService.updateStockItem(foundStock.getStockID(), stockMediaHelper);
						} else {
							System.out.println("Invalid option!");
						}
						break;
						
					case "title":
						System.out.println("What is the title of the CD?");
						String title = inputReader.readLine();
						stockMediaHelper.cd.setTitle(title);
						stockService.updateStockItem(foundStock.getStockID(), stockMediaHelper);
						break;
						
					case "publisher":
						System.out.println("What is the name of the publisher?");
						String publisher = inputReader.readLine();
						stockMediaHelper.cd.setPublisher(publisher);
						stockService.updateStockItem(foundStock.getStockID(), stockMediaHelper);
						break;
						
					case "runtime":
						System.out.println("What is the running time of the CD?");
						String runTime = inputReader.readLine();
						stockMediaHelper.cd.setRunningTime(runTime);
						
					case "type":
						System.out.println("What is the cd type?");
						String format = inputReader.readLine();
						stockMediaHelper.cd.setCdType(format);
						stockService.updateStockItem(foundStock.getStockID(), stockMediaHelper);
						break;
						
					case "tracks":
						System.out.println("How many tracks are on the CD?");
						int noOfTracks = Integer.parseInt(inputReader.readLine());
						stockMediaHelper.cd.setNoOfTracks(noOfTracks);
						stockService.updateStockItem(foundStock.getStockID(), stockMediaHelper);
						break;
						
					case "artist":
						System.out.println("Who is the artist of the CD?");
						String artist = inputReader.readLine();
						stockMediaHelper.cd.setArtist(artist);
						stockService.updateStockItem(foundStock.getStockID(), stockMediaHelper);
						break;
						
					case "storage":
						System.out.print("What is the type of storage case?");
						String typeOfStorageCase = inputReader.readLine();
						stockMediaHelper.cd.setTypeOfStorageCase(typeOfStorageCase);
						stockService.updateStockItem(foundStock.getStockID(), stockMediaHelper);
						break;
						
					default:
						System.out.println("Invalid input!");
				}
				
				// Prints the edited item to the user
				System.out.println("Here is your updated item!\n");
				System.out.println(stockMediaHelper.cd);
				break;
				
			case Journal:
				System.out.println("What would you like to edit?");
				System.out.println("Options: 'price', 'public', 'title', 'publisher', 'ISSN', 'issue', 'date', 'subject', 'pages'");
				input = inputReader.readLine().toLowerCase();
				
				stockMediaHelper.journal = (Journal) foundStock;
				
				switch(input) {
					case "price":
						// Asks the user for the inputs for a Journal and sets the values
						System.out.println("What is the price of the video?");
						Double price = Double.parseDouble(inputReader.readLine());
						stockMediaHelper.journal.setPrice(price);
						stockService.updateStockItem(foundStock.getStockID(), stockMediaHelper);
						break;
						
					case "public":
						System.out.println("Do you want the item to be public? Y/N");
						String isPublic = inputReader.readLine();
				
						if (isPublic.equals("n")) {
							stockMediaHelper.video.setIsPublic(true);
							stockService.updateStockItem(foundStock.getStockID(), stockMediaHelper);
						} else if (isPublic.equals("n")){
							stockMediaHelper.video.setIsPublic(false);
							stockService.updateStockItem(foundStock.getStockID(), stockMediaHelper);
						} else {
							System.out.println("Invalid option!");
						}
						break;
						
					case "title":
						System.out.println("What is the title of the journal?");
						String title = inputReader.readLine();
						stockMediaHelper.journal.setTitle(title);
						stockService.updateStockItem(foundStock.getStockID(), stockMediaHelper);
						break;
						
					case "publisher":
						System.out.println("What is the name of the publisher?");
						String publisher = inputReader.readLine();
						stockMediaHelper.journal.setPublisher(publisher);
						stockService.updateStockItem(foundStock.getStockID(), stockMediaHelper);
						break;
						
					case "issn":
						System.out.println("What is ISSN of the journal?");
						String ISSN = inputReader.readLine();
						stockMediaHelper.journal.setISSN(ISSN);
						stockService.updateStockItem(foundStock.getStockID(), stockMediaHelper);
						break;
						
					case "issue":
						System.out.println("What is the issue number of the journal?");
						String issueNumber = inputReader.readLine();
						stockMediaHelper.journal.setIssueNumber(issueNumber);
						stockService.updateStockItem(foundStock.getStockID(), stockMediaHelper);
						break;
						
					case "date":
						System.out.println("What is the date of issue (yyyy-mm-dd)?");
						LocalDate dateOfIssue = LocalDate.parse(inputReader.readLine());
						stockMediaHelper.journal.setDateOfIssue(dateOfIssue);
						stockService.updateStockItem(foundStock.getStockID(), stockMediaHelper);
						break;
						
					case "subject":
						System.out.println("What is the subject area?");
						String subjectArea = inputReader.readLine();
						stockMediaHelper.journal.setSubjectArea(subjectArea);
						stockService.updateStockItem(foundStock.getStockID(), stockMediaHelper);
						break;
						
					case "pages":
						System.out.println("What is the number of pages?");
						int noOfPages = Integer.parseInt(inputReader.readLine());
						stockMediaHelper.journal.setNoOfPages(noOfPages);
						stockService.updateStockItem(foundStock.getStockID(), stockMediaHelper);
						break;
					
					default:
						System.out.println("Invalid input!");
				}
				
				// Prints the edited item to the user
				System.out.println("Here is your updated item!\n");
				System.out.println(stockMediaHelper.journal);
				break;
				
			default:
				System.out.println("Invalid input!");
		}
		System.out.println("Press enter to return to the menu!");
	}
}

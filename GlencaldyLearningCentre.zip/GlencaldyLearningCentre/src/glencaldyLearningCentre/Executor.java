package glencaldyLearningCentre;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

import controllers.BorrowController;
import controllers.ReserveController;
import controllers.StockController;
import controllers.UserController;
import enums.MediaType;
import enums.Membership;
import helpers.StockMediaTypeHelper;
import models.Books;
import models.Borrow;
import models.CD;
import models.Journal;
import models.LoginSession;
import models.Stock;
import models.User;
import models.Video;
import services.BorrowService;
import services.ReserveService;
import services.StockService;
import services.UserService;
// Author: Liam Irvine
// Executor class - Executes the program
public class Executor {

	public static void main(String[] args) throws IOException {
		// Required variables are made
		BufferedReader inputReader = new BufferedReader(new InputStreamReader(System.in));
		Orchestrator orchestrator = new Orchestrator();
		orchestrator.deserialiseFiles();
		boolean loggedIn = false;
		String userInput;
		String response;
		User user = null;
		
		// While loop until user enters correct credentials or exits
		while(true) {
			if (!loggedIn && user == null) {		
				// Asks the user if they want to log in or register a new account
				System.out.println("Please, log in to the system!");
				//userInput = inputReader.readLine().toLowerCase();
				response = "";
				
				do {
					user = orchestrator.login();
					if (user != null) {
						loggedIn = true;
						response = "Welcome " + user.getFirstName();
					}
					
					if (user == null) {
						System.out.println("Incorrect login!");
					}
					
				} while (!loggedIn);
			}
			
			// If statements to check what membership type the user is
			if (user.getMembership() == Membership.staffMember) {
				orchestrator.staffMemberFunctionility(user);
			} else if (user.getMembership() == Membership.fullMember) {
				orchestrator.fullMemberFunctionality(user);
			} else if (user.getMembership() == Membership.casualMember) {
				orchestrator.casualMemberFunctionality(user);
			}
			
			// Check to exit the program if the user enters "exit"
			userInput = inputReader.readLine().toLowerCase();
			if (userInput.equals("exit")) {
				loggedIn = false;
				user = null;
				break;
			}
		}
		
	} 
}

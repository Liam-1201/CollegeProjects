package interfaces;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

import models.Borrow;
import models.User;

// Author: Liam Irvine
// Interface to declare methods required by the borrow function.
public interface IBorrowService {
	void borrowStockItem(UUID stockID, UUID userID, User user); // Method will take stockID and customerID of type UUID. Does not return a value.
	Borrow returnStockItem(UUID stockID); // Method will take stockID of type UUID. Will return type Borrow.
	Double applyFine(Borrow borrow, LocalDate returnDate); // Method will take borrow of type Borrow to access the borrow class. Method will take returnDate of type LocalDate. Will return type Double.
	List<Borrow> getBorrowedItems(); // Method will return a list of borrowed items by the user
	List<Borrow> getAllBorrowedItems(); // Method will return a list of all borrowed items
}
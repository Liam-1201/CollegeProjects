package interfaces;
import java.util.List;
import java.util.UUID;

import helpers.StockUserHelper;

// Author: Liam Irvine
// Interface to declare methods required by the reserve function.
public interface IReserveService {
	boolean reserveItem(UUID stockID, UUID customerID); // Method will take stockID and customerID, both type UUID. Will return a boolean.
	List<StockUserHelper> getReservedStockItems(); // Method will return a list of type StockUserHelper.
}


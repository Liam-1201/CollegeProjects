package interfaces;

import java.util.ArrayList;
import java.util.List;

import enums.Membership;
import helpers.UserHelper;
import models.LoginSession;
import models.User;

//Interface to declare methods required by the different functions for the user.
public interface IUserService {
	boolean login (String username, String password); // Method will take username and password of type String. Returns a boolean.
	String logout (); // Method will not return a value.
	boolean registerUser (User newUser); // Method will take newUser of type User, returns a boolean.
	void updateUserPassword (String newPassword); // Method will take newPassword of type String, does not return a value.
	void updateMembershipType (Membership membership); // Method will take membership of type Membership, does not return a value.
	User getCurrentUser(); // Method will return type User.
	User getUsersByUsernameSearch(String username); // Method will return a list of type UserHelper.
	ArrayList<LoginSession> getLoginSessions();
	ArrayList<LoginSession> getAllLoginSessions();
	ArrayList<User> getAllUsers();
	List<UserHelper> getUsersByUsername();
}
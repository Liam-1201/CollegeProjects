package interfaces;
import java.util.List;
import java.util.UUID;
import models.LoginSession;

// Author: Liam Irvine
// Interface to declare methods required by the login session function.
public interface ISessionService {
	void createLoginSession(UUID userID, String username); // Method will take userID of type UUID, does not return a value.
	String endSession(); // Method will end the current session, returns type string
	LoginSession getLoginSession(); // Method will get the login session, returns type LoginSession
	List<LoginSession> getUsersSessions(UUID userID); // Method will take userID of type UUID, returns a list of LoginSession
}
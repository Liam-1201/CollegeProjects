package interfaces;
import java.util.List;
import java.util.UUID;

//import helpers.StockHelper;
import helpers.StockMediaTypeHelper;
import models.Stock;

//Interface to declare methods required by the stock functions.
public interface IStockServiceInterface {
	boolean showHiddenItems = false; // Variable used to show hidden items.
	void createStockItem(StockMediaTypeHelper stockMediaHelper); // Method will take stockMediaHelper of type StockMediaHelper, does not return a value.
	List<Stock> getStockItems(boolean showHiddenItems); // Method will take showHiddenItems of type boolean, will return a list of type Stock.
	String updateStockItem(UUID stockID, StockMediaTypeHelper stockMediaHelper); // Method will take stockID of type UUID and stockMediaHelper of type StockMediaHelper, returns a String.
	boolean makeStockPublic(UUID stockID); // Method will take stockID of type UUID, returns a boolean.
	Stock getStockItemByID(UUID stockID); // Method will take stockID of type UUID, returns a value of type Stock.
	List<Stock> getStockByStockName(String stockTitle);
}
 
package enums;

// Author: Liam Irvine
// Enum used to declare each type of membership.
public enum Membership {
	fullMember, casualMember, staffMember
}

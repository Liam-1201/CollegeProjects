package enums;

// Author: Liam Irvine
// Enum used to declare each different media type used for the stock.
public enum MediaType {
	Unknown, Video, CD, Journal, Book
}

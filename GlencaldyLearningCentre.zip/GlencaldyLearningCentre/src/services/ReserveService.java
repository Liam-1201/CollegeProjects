package services;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import helpers.StockUserHelper;
import helpers.UserHelper;
import interfaces.IReserveService;
import models.Stock;

// Author: Liam Irvine
// Class used to create the reserve service
// Implements from interface IReserveService
public class ReserveService implements IReserveService{
	// Required variables are made
	private List<Stock> stockList;
	private StockService stockService;
	private UserService userService;
	
	// Constructor to initialise the variables, objects are created.
	public ReserveService (UserService userService, StockService stockService) throws IOException {
		this.userService = userService;
		this.stockService = stockService;
		this.stockList = stockService.getStockItems(false);
	}
	
	@Override // Method taken from interface, Takes stockID and customerID to reserve an item
	public boolean reserveItem(UUID stockID, UUID customerID) {
		// Creates a list from the current stockList
		List<Stock> foundStock = stockService.getStockItems(false);
		
		// Loops through all stock until the passed stockID is equal to the current items stockID
		for (Stock stock: foundStock) {
			if (stockID.equals(stock.getStockID())) {
				// Reserves that item and sets the customerID to the current user
				stock.setIsReserved(true);
				stock.setCustomerID(customerID);
				return true;
			}
		}
		return false;
	}

	@Override // Method taken from interface, 
	public List<StockUserHelper> getReservedStockItems() {
		// Lists are created and stored appropriate items
		List<StockUserHelper> stockUserHelper = new ArrayList<StockUserHelper>();
		List<UserHelper> usernames = this.userService.getUsersByUsername();
		List<Stock> stocks = this.stockList.stream().filter(x -> x.getIsReserved() == true & !x.getCustomerID().equals(null)).toList();
		// Loops through all stock items until the stocks userID is equal to the usersID
		for (Stock stock : stocks) {
			for (UserHelper userHelper : usernames) {
				if (stock.getCustomerID().equals(userHelper.getUserID())) {
					// Creates a new object of StockUserHelper
					StockUserHelper newStockUserHelper = new StockUserHelper(stock.getStockID(), stock.getMediaType(), stock.getPrice(),
							stock.getIsBorrowed(), stock.getIsReserved(), stock.getIsPublic(), stock.getCustomerID(),
							stock.getTitle(), stock.getPublisher(), userHelper.getUsername());
					stockUserHelper.add(newStockUserHelper);
				}
			}
		}
		
		return stockUserHelper;
	}
}

package services;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import enums.MediaType;
import helpers.FileHelper;
import helpers.StockMediaTypeHelper;
import interfaces.IStockServiceInterface;
import models.Books;
import models.CD;
import models.Journal;
import models.LoginSession;
import models.Stock;
import models.Video;

// Author: Liam Irvine
// Class used to create the stock service
// Implements from interface IStockServiceInterface
public class StockService implements IStockServiceInterface{
	// ArrayList of type Stock is created
	private ArrayList<Stock> stockList;
	private FileHelper fileHelper;
	private String filePath = "stocks.ser";
	
	// Constructor for stockList is made, object is created
	public StockService() {
		fileHelper = new FileHelper(filePath);
		this.stockList = new ArrayList<Stock>();
		//this.existingStocksFromFile = fileHelper.readFromFile(filePath);
		this.generateStaticData();
	}
	
	@Override // Method taken from interface, creates stock item
	public void createStockItem(StockMediaTypeHelper stockMediaHelper) {
		// Switch case to check the media type and to create a new object of that media type
		switch (stockMediaHelper.stock.getMediaType()) {
			case Book:
				// Creates new object of Book based on the users inputs
				Stock book = new Books(UUID.randomUUID(), MediaType.Book, stockMediaHelper.book.getPrice(), false,
						false, stockMediaHelper.book.getIsPublic(), null, stockMediaHelper.book.getTitle(), stockMediaHelper.book.getPublisher(), 
						stockMediaHelper.book.getISBN(), stockMediaHelper.book.getAuthor(), stockMediaHelper.book.getSubjectArea(), stockMediaHelper.book.getNoOfPages());
				stockList.add(book);
				this.fileHelper.saveToFile(this.stockList);
				break;
			case Video:
				// Creates new object of Video based on the users inputs
				Stock video = new Video(UUID.randomUUID(), MediaType.Video, stockMediaHelper.video.getPrice(), false,
						false, stockMediaHelper.video.getIsPublic(), null, stockMediaHelper.video.getTitle(), stockMediaHelper.video.getPublisher(), 
						stockMediaHelper.video.getRunningTime(), stockMediaHelper.video.getVideoFormat(), stockMediaHelper.video.getGenre(), stockMediaHelper.video.getTypeOfStorageCase());
				stockList.add(video);
				this.fileHelper.saveToFile(this.stockList);
				break;
			case CD: 
				// Creates new object of CD based on the users inputs
				Stock cd = new CD(UUID.randomUUID(), MediaType.CD, stockMediaHelper.cd.getPrice(), false,
						false, stockMediaHelper.cd.getIsPublic(), null, stockMediaHelper.cd.getTitle(), stockMediaHelper.cd.getPublisher(), 
						stockMediaHelper.cd.getRunningTime(), stockMediaHelper.cd.getCdType(), stockMediaHelper.cd.getNoOfTracks(), stockMediaHelper.cd.getArtist(), 
						stockMediaHelper.cd.getTypeOfStorageCase());
				stockList.add(cd);
				this.fileHelper.saveToFile(this.stockList);
				break;
			case Journal:
				// Creates new object of Journal based on the users inputs
				Stock journal = new Journal(UUID.randomUUID(), MediaType.Journal, stockMediaHelper.journal.getPrice(), false,
						false, stockMediaHelper.journal.getIsPublic(), null, stockMediaHelper.journal.getTitle(), stockMediaHelper.journal.getPublisher(), 
						stockMediaHelper.journal.getISSN(), stockMediaHelper.journal.getIssueNumber(), stockMediaHelper.journal.getDateOfIssue(), stockMediaHelper.journal.getSubjectArea(), 
						stockMediaHelper.journal.getNoOfPages());
				stockList.add(journal);
				this.fileHelper.saveToFile(this.stockList);
				break;
			default:
				// Creates new object of Stock based on the users inputs
				Stock unknown = new Stock(UUID.randomUUID(), MediaType.Unknown, stockMediaHelper.stock.getPrice(), false,
						false, stockMediaHelper.stock.getIsPublic(), null, stockMediaHelper.stock.getTitle(), stockMediaHelper.stock.getPublisher());
				stockList.add(unknown);
				this.fileHelper.saveToFile(this.stockList);
		}
	}

	@Override // Method taken from interface, returns all public stock items
	public ArrayList<Stock> getStockItems(boolean showHiddenItems) {
		// stockList of type Stock is created
		//ArrayList<Stock> stockList = (ArrayList<Stock>) this.stockList.stream().collect(Collectors.toList());
		
		// if statement to check if showHiddenItems is false
		if (!showHiddenItems) {
			stockList.stream().filter(x -> x.getIsPublic() == true);
		}
		
		return stockList;
	}

	@Override // Method updates a chosen stock item with the users inputs, takes stockID and stockMediaHelper
	public String updateStockItem(UUID stockID, StockMediaTypeHelper stockMediaHelper) {
		
		// Creates a stream of type stock equal to the stock item that the user inserted the ID for
		Stream<Stock> filterStreamOnStockID = stockList.stream()
				.filter(x -> stockID.equals(x.getStockID()));
		
		// foundStock of type Stock is declared and checked
		Stock foundStock = filterStreamOnStockID
				.findAny()
				.orElse(null);
		
		if (foundStock == null) {
			return "Item with that ID does not exist!";
		}
		// Creates a list of stock with all stock items
		List<Stock> stockList = this.getStockItems(true);
		int i = 0;
		// Switch case based on the media type of the stock
		switch (foundStock.getMediaType()) {
		case Book:
			// Loops through all stock until passed stockID is equal to the current stockID
			for (Stock stock: stockList) {
				if (stockID.equals(stock.getStockID())) {
					// Creates a new Book object and replaces the old Book
					Stock book = new Books(UUID.randomUUID(), MediaType.Book, stockMediaHelper.book.getPrice(), false,
							false, stockMediaHelper.book.getIsPublic(), null, stockMediaHelper.book.getTitle(), stockMediaHelper.book.getPublisher(), 
							stockMediaHelper.book.getISBN(), stockMediaHelper.book.getAuthor(), stockMediaHelper.book.getSubjectArea(), stockMediaHelper.book.getNoOfPages());
					this.stockList.set(i, book);
					this.fileHelper.saveToFile(this.stockList);
				}
				i++;
			}
			break;
		case Video:
			// Loops through all stock until passed stockID is equal to the current stockID
			for (Stock stock: stockList) {
				if (stockID.equals(stock.getStockID())) {
					// Creates a new Video object and replaces the old Video
					Stock video = new Video(UUID.randomUUID(), MediaType.Video, stockMediaHelper.video.getPrice(), false,
						false, stockMediaHelper.video.getIsPublic(), null, stockMediaHelper.video.getTitle(), stockMediaHelper.video.getPublisher(), 
						stockMediaHelper.video.getRunningTime(), stockMediaHelper.video.getVideoFormat(), stockMediaHelper.video.getGenre(), stockMediaHelper.video.getTypeOfStorageCase());
					this.stockList.set(i, video);
					this.fileHelper.saveToFile(this.stockList);
				}
				i++;
			}
			break;
		case CD:
			// Loops through all stock until passed stockID is equal to the current stockID
			for (Stock stock: stockList) {
				if (stockID.equals(stock.getStockID())) {
					// Creates a new CD object and replaces the old CD
					Stock CD = new CD(UUID.randomUUID(), MediaType.CD, stockMediaHelper.cd.getPrice(), false,
							false, stockMediaHelper.cd.getIsPublic(), null, stockMediaHelper.cd.getTitle(), stockMediaHelper.cd.getPublisher(), 
							stockMediaHelper.cd.getRunningTime(), stockMediaHelper.cd.getCdType(), stockMediaHelper.cd.getNoOfTracks(), stockMediaHelper.cd.getArtist(), 
							stockMediaHelper.cd.getTypeOfStorageCase());
					this.stockList.set(i, CD);
					this.fileHelper.saveToFile(this.stockList);
				}
				i++;
			}
			break;
		case Journal:
			// Loops through all stock until passed stockID is equal to the current stockID
			for (Stock stock: stockList) {
				if (stockID.equals(stock.getStockID())) {
					// Creates a new Journal object and replaces the old Journal object
					Stock journal = new Journal(UUID.randomUUID(), MediaType.Journal, stockMediaHelper.journal.getPrice(), false,
							false, stockMediaHelper.journal.getIsPublic(), null, stockMediaHelper.journal.getTitle(), stockMediaHelper.journal.getPublisher(), 
							stockMediaHelper.journal.getISSN(), stockMediaHelper.journal.getIssueNumber(), stockMediaHelper.journal.getDateOfIssue(), stockMediaHelper.journal.getSubjectArea(), 
							stockMediaHelper.journal.getNoOfPages());
					this.stockList.set(i, journal);
					this.fileHelper.saveToFile(this.stockList);
				}
				i++;
			}
			break;
		default:
			// Loops through all stock until passed stockID is equal to the current stockID
			for (Stock stock: stockList) {
				if (stockID.equals(stock.getStockID())) {
					// Creates a new Stock object and replaces the old Stock object
					Stock unknown = new Stock(UUID.randomUUID(), MediaType.Unknown, stockMediaHelper.stock.getPrice(), false,
							false, stockMediaHelper.stock.getIsPublic(), null, stockMediaHelper.stock.getTitle(), stockMediaHelper.stock.getPublisher());
					this.stockList.set(i, unknown);
					this.fileHelper.saveToFile(this.stockList);
				}
				i++;
			}
	}
		return "Item updated!";
	}

	
	@Override // Method taken from interface, makes a given stock public
	public boolean makeStockPublic(UUID stockID) {
		// foundStock variable of type Stock is created and set to the value of getStockItemByID method
		Stock foundStock = this.getStockItemByID(stockID);
		
		// if statement to check if foundStock is null
		if (foundStock == null) {
			return false;
		}
		
		
		// Set that stock item to public
		foundStock.setIsPublic(true);
		return true;
	}

	@Override // Method taken from interface, finds the stock item by the ID
	public Stock getStockItemByID(UUID stockID) {
		// Creates a list of stock of public items
		List<Stock> foundStock = this.getStockItems(false);
		
		// Loops through all stock items until the users inserted stockID is equal to the stockID in the list
		for (Stock stock: foundStock) {
			if (stockID.equals(stock.getStockID())) {
				// returns the stock item
				return stock;
			}
		}
		return null;
	}
	
	@Override // Method taken from interface, returns a list of stock items with a given title from user
	public List<Stock> getStockByStockName(String stockTitle) {
		return this.getStockItems(false).stream().filter(x -> stockTitle.equals(x.getTitle())).toList();
	}
	
	// Deserialises the stocks file and adds to the stockList
	@SuppressWarnings("unchecked")
	public ArrayList<Stock> deserialiseStock() {
		
		try {
			FileInputStream fileIn = new FileInputStream("stocks.ser");
			ObjectInputStream objIn = new ObjectInputStream(fileIn);
			
			stockList = (ArrayList<Stock>) objIn.readObject();
			
			objIn.close();
			fileIn.close();
		} catch (IOException e1) {
			e1.printStackTrace();
		} catch (ClassNotFoundException e2) {
			System.out.println("Stock class not found.");
		}
		return stockList;
	}
	
	// Method used to generate static data for all stock items
	private void generateStaticData() {
		Stock book1 = new Books(UUID.randomUUID(), MediaType.Book, 15.00, false,
				false, true, null, "Book of the Glen", "Glens Publishers", 
				"978-3-16-148410-0", "Robert Burns", "Fantasy", 1530);
		Stock book2 = new Books(UUID.randomUUID(), MediaType.Book, 18.50, false,
				false, true, null, "Murder at the Loch", "Spicy Scenes", 
				"475-7-12-126110-0", "John Mayor", "Murder Mystery", 1530);
		Stock book3 = new Books(UUID.randomUUID(), MediaType.Book, 20.00, false,
				false, true, null, "FlyMan", "Marvelous Studios", 
				"429-2-11-197810-0", "Lee Stan", "Superhero", 1530);
		
		Stock video1 = new Video(UUID.randomUUID(), MediaType.Video, 12.00, false,
				false, true, null, "Pirates of the Pacific Ocean", "Walter Dipsey", 
				"2h 40m", "VHS", "Action", "VHS Case");
		Stock video2 = new Video(UUID.randomUUID(), MediaType.Video, 5.00, false,
				false, true, null, "You've Been Setup!", "Hilly Har", 
				"1h 30m", "Betamax", "Comedy", "Wooden Box");
		Stock video3 = new Video(UUID.randomUUID(), MediaType.Video, 10.50, false,
				false, true, null, "Tooney Lunes", "Big Buck Bunny", 
				"3h 20m", "Super VHS", "Comedy", "VHS Case");
		
		Stock cd1 = new CD(UUID.randomUUID(), MediaType.CD, 15.50, false,
				false, true, null, "Thats So Naughties!", "Clubland", 
				"1h 45m", "CD-ROM", 30, "Various Artists", 
				"DVD Case");
		Stock cd2 = new CD(UUID.randomUUID(), MediaType.CD, 5.00, false,
				false, true, null, "Someone I Once Knew", "Gotya", 
				"4m 3s", "CD-ROM", 1, "Gotya", 
				"DVD Case");
		Stock cd3 = new CD(UUID.randomUUID(), MediaType.CD, 14.00, false,
				false, true, null, "The College Graduate", "Kanno West", 
				"1h 40m", "CD-ROM", 21, "Kanno West", 
				"DVD Case");
		
		Stock journal1 = new Journal(UUID.randomUUID(), MediaType.Journal, 7.99, false,
				false, true, null, "Open Biology", "Royal People", 
				"2046-2611", "10", LocalDate.parse("2013-02-21"), "Nature", 
				102);
		Stock journal2 = new Journal(UUID.randomUUID(), MediaType.Journal, 8.99, false,
				false, true, null, "Open Physics", "Science101", 
				"5146-2264", "15", LocalDate.parse("2011-05-05"), "Physics", 
				192);
		Stock journal3 = new Journal(UUID.randomUUID(), MediaType.Journal, 11.99, false,
				false, true, null, "Open Chemistry", "Chemisting", 
				"2046-2611", "3", LocalDate.parse("2013-02-21"), "Chemistry", 
				233);
		
		// Adding the stock objects to the stockList
		/*this.stockList.add(book1);
		this.stockList.add(book2);
		this.stockList.add(book3);
		
		this.stockList.add(video1);
		this.stockList.add(video2);
		this.stockList.add(video3);
		
		this.stockList.add(cd1);
		this.stockList.add(cd2);
		this.stockList.add(cd3);
		
		this.stockList.add(journal1);
		this.stockList.add(journal2);
		this.stockList.add(journal3);*/
		
		/*for (Stock s: this.stockList) {
			for(Stock s1: this.existingStocksFromFile) {
				if (s.getTitle() != s1.getTitle()) {
					this.stockList.add(s1);
				}
			}
		}*/
	
	}
	
	// Method to convert the stock list to stream
	private Stream<Stock> convertStockListToStream() {
		return this.stockList.stream();
	}

	
}

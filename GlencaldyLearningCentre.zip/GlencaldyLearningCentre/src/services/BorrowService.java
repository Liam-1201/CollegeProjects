package services;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import helpers.FileHelper;
import interfaces.IBorrowService;
import models.Borrow;
import models.Stock;
import models.User;

// Author: Liam Irvine
// Class used to create the borrow service
// Implements from interface IBorrowService
public class BorrowService implements IBorrowService{
	// Required variables are made
	private ArrayList<Stock> stockList;
	private ArrayList<Borrow> borrowList;
	private StockService stockService;
	private UserService userService;
	private List<Borrow> existingBorrowFromFile;
	private FileHelper fileHelper;
	private String filePath = "borrow.ser";
	
	// Constructor to initialise the variables, objects are created.
	public BorrowService(UserService userService, StockService stockService) {
		fileHelper = new FileHelper(filePath);
		this.userService = userService;
		this.stockService = stockService;
		this.borrowList = new ArrayList<Borrow>();
		//this.borrowList = this.deserialiseBorrow();
		this.stockList = stockService.getStockItems(false);
	}
	
	@Override // Method taken from Interface
	public void borrowStockItem(UUID stockID, UUID customerID, User user) {
		// Creates a list of Stock and sets it equal to the current stockList
		ArrayList<Stock> foundStock = stockService.getStockItems(false);
		
		// Loops through all the stock until the stock inserted by the user is equal to the found stock
		for (Stock stock: foundStock) {
			if (stockID.equals(stock.getStockID())) {
				// New borrow object is made and the item is borrowed and added to the list
				Borrow newBorrow = new Borrow(UUID.randomUUID(), stock.getTitle(), LocalDate.now(), LocalDate.now().plusDays(10),
						stock.getPrice(), 0.0, user.getUserID(), stock.getStockID(), false, false, user.getUsername());
				borrowList.add(newBorrow);
				stock.setIsBorrowed(true);
				stock.setCustomerID(customerID);
				this.fileHelper.saveToFile(this.borrowList);
			}
		}
	}

	@Override // Method taken from Interface
	public Borrow returnStockItem(UUID stockID) {
		// Variables declared to access setters from the required classes.
		Borrow borrow = this.getBorrowByStockID(stockID);
		
		Stock stock = this.stockService.getStockItemByID(stockID);
		
		// If statement to check if the item is still being borrowed
		// Updates the values of isReturned and isBorrowed appropriately
		// Sets the fine to zero and isFinePayed to true
		if (borrow != null) {
			borrow.setIsReturned(true);
			stock.setIsBorrowed(false);
			borrow.setFine(0.0);
			borrow.setIsFinePayed(true);
		}
		
		// Returns borrow value
		return borrow;
	}
	
	// Method used to obtain the borrowList from the stockID
	public Borrow getBorrowByStockID(UUID stockID) {
		return this.borrowList.stream().filter(x -> stockID.equals(x.getStockID())).findAny().orElse(null);
	}
	
	// Method that returns all borrowed items by the user, returns list of Stock
	public ArrayList<Stock> getReturnListByUserID(UUID customerID) {
		ArrayList<Stock> foundStock = stockService.getStockItems(false);
		ArrayList<Stock> borrowedStock = new ArrayList<Stock>();
		
		// Loops through all stock until the foundStock is equal to the current stock
		for (Stock stock: foundStock) {
			if (customerID.equals(stock.getCustomerID()) & stock.getIsBorrowed()) {
				borrowedStock.add(stock);
			}
		}
		return borrowedStock;
	}
	
	@Override // Method taken from Interface
	public Double applyFine(Borrow borrow, LocalDate returnDate) {
		// Variables declared
		Double totalCostWithFine = borrow.getTotalCost(); // Value set to the getTotalCost in borrow class.
		// Value set to the private method checkIfEndDateExceeded with parameters passed.
		boolean isEndDateExceeded = this.checkIfEndDateExceeded(borrow.getBorrowEndDate(), returnDate);
		
		// If statement to check if isEndDateExceeded = true
		if (isEndDateExceeded) {
			// Parameters are passed into calculateFine method, value is set and returned.
			totalCostWithFine = calculateFine(borrow.getBorrowEndDate(), returnDate, totalCostWithFine);
			borrow.setFine(totalCostWithFine);
			return totalCostWithFine;
		}
		
		// totalCostWithFine is returned.
		return totalCostWithFine;
	}
	
	@Override // Method to return a list of all borrowed items by the current user
	public List<Borrow> getBorrowedItems() {
		User user = userService.getCurrentUser();
		// Creates a list of all borrowed items from the borrow list
		List<Borrow> borrowedItems = this.borrowList.stream().collect(Collectors.toList());
		List<Borrow> prevBorrowedItems = new ArrayList<Borrow>();
		// Loops through all Borrow objects and checks for when the current userID is equal to the borrowed userID
		for (Borrow borrow: borrowedItems) {
			if (user.getUserID().equals(borrow.getCustomerID())) {
				prevBorrowedItems.add(borrow);
			}
		}
		return prevBorrowedItems;
	}
	
	@Override // Method to return the whole borrowList
	public List<Borrow> getAllBorrowedItems() {
		return this.borrowList;
	}
	
	// Method to deserialise the borrowList
	@SuppressWarnings("unchecked")
	public ArrayList<Borrow> deserialiseBorrow() {
		
		try {
			FileInputStream fileIn = new FileInputStream("borrow.ser");
			ObjectInputStream objIn = new ObjectInputStream(fileIn);
			
			borrowList = (ArrayList<Borrow>) objIn.readObject();
			
			objIn.close();
			fileIn.close();
		} catch (IOException e1) {
			e1.printStackTrace();
		} catch (ClassNotFoundException e2) {
			System.out.println("Borrow class not found.");
		}
		return borrowList;
	}
	
	// Private method to check if the end date for returning has been exceeded, will take borrowEndDate and returnDate.
	private boolean checkIfEndDateExceeded (LocalDate borrowEndDate, LocalDate returnDate) {
		// If statement to check if the returnDate exceeds the set end date
		if (returnDate.isAfter(borrowEndDate)) {
			return true;
		}
		// If end date isn't exceeded, returns false.
		return false;
	}
	
	// Private method to calculate the fine, will take borrowEndDate, returnDate and totalCost.
	private Double calculateFine (LocalDate borrowEndDate, LocalDate returnDate, Double totalCost) {
		// Variables declared
		Long countDays = ChronoUnit.DAYS.between(borrowEndDate, returnDate); // Sets countDays to the amount of days between the set endDate and the returnDate.
		Double fine = 0.5; // Fine is set to 50p
		
		// For loop to add 50p onto the total cost for each day exceeded.
		for (int i = 1; i <= countDays; i++) {
			totalCost = totalCost + fine;
		}
		
		// Returns totalCost.
		return totalCost;
	}

	

	

	

	
	
}

package services;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.time.LocalDate;
import enums.Membership;
import helpers.FileHelper;
import helpers.UserHelper;
import interfaces.IUserService;
import models.LoginSession;
import models.User;

// Author: Liam Irvine
// Class used to create the user service
// Implements from interface IUserService
public class UserService implements IUserService{
	// Required variables are made
	private ArrayList<User> userList;
	private SessionService sessionService;
	private FileHelper fileHelper;
	private String filePath = "users.ser";
	
	// Constructor to initialise variables
	public UserService () {
		fileHelper = new FileHelper(filePath);
		this.userList = new ArrayList<User>();
		this.sessionService = new SessionService();
		this.generateStaticData();
		sessionService.deserialiseSessions();
	}
	
	@Override // Method taken from interface, logs the user in
	public boolean login(String username, String password) {
		// Variable foundUser made to check if the username and password is correct
		User foundUser = convertUserListToStream()
				.filter(x -> username.equals(x.getUsername()) & password.equals(x.getPassword()))
				.findAny()
				.orElse(null);
		
		// if statement to check if the user exists
		if (foundUser == null) {
			return false;
		}
		
		// Creates a login session for the user
		sessionService.createLoginSession(foundUser.getUserID(), foundUser.getUsername());
		
		return true;
	}
	
	@Override // Method taken from the interface, logs the user out
	public String logout() {
		// ends the current session
		return this.sessionService.endSession();
	}

	@Override // Method taken from the interface, registers a new user
	public boolean registerUser(User newUser) {
		// Variable to check if the user exists is made
		User isUserExisting = convertUserListToStream()
				.filter(x -> newUser.getUsername().equals(x.getUsername()))
				.findFirst()
				.orElse(null);
		
		// if statement to check if variable isUserExisting is null
		if (isUserExisting != null) {
			return false;
		}
		
		// adds the new user to the userList
		this.userList.add(newUser);
		this.fileHelper.saveToFile(this.userList);
		sessionService.createLoginSession(newUser.getUserID(), newUser.getUsername());

		return true;
	}
	
	@Override // Method taken from interface, updates the users password
	public void updateUserPassword(String newPassword) {
		// Variable to get the current user is created
		User currentUserSession = this.getCurrentUser();
		
		// Sets the password of the current user to the new password
		currentUserSession.setPassword(newPassword);
		
		// Loops through all users and replaces the old password of the user to the new password
		for (User user: userList) {
			int i = 0;
			if (currentUserSession.getUserID().equals(user.getUserID())) {
				user.setPassword(newPassword);
				userList.set(i, user);
				this.fileHelper.saveToFile(this.userList);
			}
			i++;
		}
	}
	
	@Override // Method taken from interface, updates the users membership
	public void updateMembershipType(Membership membership) {
		// Variable to get current user is created
		User currentUserSession = getCurrentUser();
		
		// Sets the membership of the current user to the new membership
		currentUserSession.setMembership(membership);
	}
	
	@Override // Method taken from interface, returns the current user
	public User getCurrentUser() {
		// Variables created to get the current login session
		LoginSession currentSession = this.sessionService.getLoginSession();
		User currentUser = null;
		
		// if statement to check that currentSession is NOT null
		if (currentSession != null) {
			// Sets the current user to be the userID of the user on that current login session
			currentUser = convertUserListToStream()
					.filter(x -> currentSession.getUserID().equals(x.getUserID()))
					.findAny()
					.orElse(null);
			
			// if statement to check if currentUser is null
			if (currentUser == null) {
				return currentUser;
			}
		}

		return currentUser;
	}
	
	/*@Override 
	public List<UserHelper> getUsersByUsername() {
		// gets the user by the username
		return this.convertUserListToStream().map(x -> new UserHelper(x.getUserID(), x.getUsername())).toList();
	}*/
	
	@Override // Method taken from interface, takes username as type String
	public User getUsersByUsernameSearch(String username) {
		// Variable is declared
		User searchedUser;
		// For loop to loop through the userlist to find a username equal to the name passed
		for (User user: userList) {
			int i = 0;
			if (user.getUsername().equals(username)) {
				searchedUser = user;
				return searchedUser;
			}
			i++;
		}
		return null;
	}
	
	@Override // Method taken from interface
	public List<UserHelper> getUsersByUsername() {
		// gets the user by the username
		return this.convertUserListToStream().map(x -> new UserHelper(x.getUserID(), x.getUsername())).toList();
	}
	
	@Override // Method taken from interface, gets the login sessions from the current user
	public ArrayList<LoginSession> getLoginSessions() {
		// user variable is set to the values of the current user
		User user = this.getCurrentUser();
		// List is made to collect all sessions by that user
		ArrayList<LoginSession> loginSessions = (ArrayList<LoginSession>) this.sessionService.getUsersSessions(user.getUserID()).stream().collect(Collectors.toList());
		ArrayList<LoginSession> currentUserSessions = new ArrayList<LoginSession>();
		// Loops through all login sessions until the userID equals the current usersID
		for (LoginSession loginSession: loginSessions) {
			if (user.getUserID().equals(loginSession.getUserID())) {
				// adds that current session to the list
				currentUserSessions.add(loginSession);
			}
		}
		return currentUserSessions;
	}	
	
	@Override // returns a list of all login sessions
	public ArrayList<LoginSession> getAllLoginSessions() {
		return this.sessionService.getUsersSessions(null);
	}
	
	@Override // returns a list of all users
	public ArrayList<User> getAllUsers() {
		return this.userList;
	}
	
	// Deserialises the users file and adds to the userList
	@SuppressWarnings("unchecked")
	public ArrayList<User> deserialiseUsers() {
		
		try {
			FileInputStream fileIn = new FileInputStream("users.ser");
			ObjectInputStream objIn = new ObjectInputStream(fileIn);
			
			userList = (ArrayList<User>) objIn.readObject();
			
			objIn.close();
			fileIn.close();
		} catch (IOException e1) {
			e1.printStackTrace();
		} catch (ClassNotFoundException e2) {
			System.out.println("User class not found.");
		}
		return userList;
	}
	
	
	// Hard coding in users that will be added on first start-up.
	private void generateStaticData() {
		User fullMember1 = new User(UUID.randomUUID(), "Timmy", "Toe", "43 Toeland", "Foothill", "JYG 45W", "07438257468",
			LocalDate.parse("1997-05-12"), Membership.fullMember, "Bigtoe247", "bigtoeisfav", true, false);
		User fullMember2 = new User(UUID.randomUUID(), "Adam", "Apple", "62 Neckhill", "Heading", "LI4 1FD", "07572864108",
				LocalDate.parse("1992-11-20"), Membership.fullMember, "Necklump22", "Eveorange", true, false);
		User fullMember3 = new User(UUID.randomUUID(), "Phil", "Mitchy", "11 Ralph Street", "Easters", "MH5 2AS", "07574800365",
				LocalDate.parse("1962-02-04"), Membership.fullMember, "Bigphil", "Ragin247", true, false);
		
		User casualMember1 = new User(UUID.randomUUID(), "Jimmy", "Joe", "236 Big hill", "Klams", "ASD 62S", "07345627468",
				LocalDate.parse("1994-02-21"), Membership.casualMember, "JoeJim", "Klams4eva", true, false);
		User casualMember2 = new User(UUID.randomUUID(), "Stefani", "Dimmy", "62 Falafel Way", "Cat Town", "PS6 7LM", "07580104536",
				LocalDate.parse("1995-10-25"), Membership.casualMember, "Nexxy", "AinyWainy", true, false);
		User casualMember3 = new User(UUID.randomUUID(), "Jordan", "Boulton", "95 Grassy Bit", "Llanybydder", "KY9 2XL", "07370653210",
				LocalDate.parse("2000-01-09"), Membership.casualMember, "Jordangodzilla", "Robbieiscool10", true, false);
		
		User staffMember = new User(UUID.randomUUID(), "Tam", "Skinner", "93 Bosh Street", "Stellar", "BG4 5AS", "07345628348",
				LocalDate.parse("1991-02-06"), Membership.staffMember, "DirtyDonna", "Bigdon38", true, false);
		
		// Adding the users to the user list.
		/*this.userList.add(fullMember1);
		this.userList.add(fullMember2);
		this.userList.add(fullMember3);
		
		this.userList.add(casualMember1);
		this.userList.add(casualMember2);
		this.userList.add(casualMember3);
		
		this.userList.add(staffMember);*/
		
	}
	
	// Method to convert the user list to stream
	private Stream<User> convertUserListToStream() {
		return this.userList.stream();
	}
	
	
}

package services;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import helpers.ErrorHandler;
import helpers.FileHelper;
import interfaces.ISessionService;
import models.Borrow;
import models.LoginSession;
import models.User;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.time.LocalDate;

// Author: Liam Irvine
// Class used to create the session service
// Implements from interface ISessionService
public class SessionService implements ISessionService{
	// Required variables are made
	private ErrorHandler errorHandler;
	private LoginSession newSession;
	private ArrayList<LoginSession> loginSession;
	private ArrayList<LoginSession> existingSessionsFromFile;
	private FileHelper fileHelper;
	private String filePath = "sessions.ser";
	
	// Constructor to initialise variables
	public SessionService () {
		fileHelper = new FileHelper(filePath);
		this.loginSession = new ArrayList<LoginSession>();
	}

	@Override // Method taken from interface, creates the login session
	public void createLoginSession(UUID userID, String username) {
		// Object used to create a new login session
		this.newSession = new LoginSession(LocalDate.now(), null, UUID.randomUUID(), userID, username);
		this.loginSession.add(0, newSession);
		this.fileHelper.saveToFile(this.loginSession);
	}

	@Override // Method taken from interface, ends the current session
	public String endSession() {
		// If statement that will return an error message if the session does not exist.
		if (newSession == null) {
			this.errorHandler = new ErrorHandler("Session does not exist!");
			return errorHandler.getMessage();
		}
		
		// sets the logout date and writes to the file
		this.newSession.setLogoutDate(LocalDate.now());
		this.loginSession.set(0, newSession);
		this.fileHelper.saveToFile(this.loginSession);
		// Returns string "Session ended"
		return "Session ended!";
	}

	@Override // Method taken from interface, gets current login session
	public LoginSession getLoginSession() {
		// returns current login session
		if (this.newSession != null) {
			if (!this.loginSession.isEmpty()) {
			return this.loginSession.get(0);
			}
		}
		
		return null;
	}

	@Override // Gets the users login sessions
	public ArrayList<LoginSession> getUsersSessions(UUID userID) {
		return this.loginSession;
	}
	
	// deserialises the loginSessions file
	/*public void deserialiseSessions() {
		try {
			FileInputStream fis = new FileInputStream(filePath);
			ObjectInputStream inputStream = new ObjectInputStream(fis);
			inputStream.defaultReadObject();
			int size = inputStream.readInt();
			for(int i = 0; i < size; i++) {
				LoginSession ls = (LoginSession) inputStream.readObject();
				this.existingSessionsFromFile.add(ls);
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}*/
	
	@SuppressWarnings("unchecked")
	public ArrayList<LoginSession> deserialiseSessions() {
		
		try {
			FileInputStream fileIn = new FileInputStream("sessions.ser");
			ObjectInputStream objIn = new ObjectInputStream(fileIn);
			
			loginSession = (ArrayList<LoginSession>) objIn.readObject();
			
			objIn.close();
			fileIn.close();
		} catch (IOException e1) {
			e1.printStackTrace();
		} catch (ClassNotFoundException e2) {
			System.out.println("LoginSession class not found.");
		}
		return loginSession;
	}
}
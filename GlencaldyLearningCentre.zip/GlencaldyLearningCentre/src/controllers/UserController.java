package controllers;

import enums.Membership;
import helpers.ErrorHandler;
import models.User;
import services.UserService;

// Author: Liam Irvine
// Class used to control messages to the user from the User service
public class UserController {
	// Required variables are made
	private UserService userService;
	private ErrorHandler errorHandler;
	private User currentUser;	
	
	// Constructor to initialise variables
	public UserController (UserService userService) {
		this.userService = userService;
		this.currentUser = userService.getCurrentUser();
	}
	
	// Method that takes username and password of type String, returns type String
	public String login (String username, String password) {
		// if statement to check if the user has entered a username or password
		if ((username == null || password == null) & (username.isEmpty() || password.isEmpty())) {
			// Error message is returned to the user
			errorHandler = new ErrorHandler("Username/Password cannot be empty!");
			return errorHandler.getMessage();
		}
		
		// variable to check if the user is already logged in
		boolean isUserLoggedIn = this.userService.login(username, password);
		
		// if statement to check if isUserLoggedIn is false
		if (!isUserLoggedIn) {
			// Error message is returned to the user
			errorHandler = new ErrorHandler("Username / password is incorrect!");
			return errorHandler.getMessage();
		}
		
		return "Login successful!";
	}
	
	// Method that takes newUser of type User, returns a String
	public String registerUser (User newUser) {
		// if statement to check if newUser is null
		if (newUser == null) {
			// Error message is returned to the user
			errorHandler = new ErrorHandler("Request cannot be empty!");
			return errorHandler.getMessage();
		}
		
		// variable to check if a user with that username is already registered
		boolean isUserRegistered = this.userService.registerUser(newUser);
		
		// if statement to check if isUserRegistered is false
		if (!isUserRegistered) {
			// Error message is returned to the user
			errorHandler = new ErrorHandler("A user with that Username already exists!");
			return errorHandler.getMessage();
		}
		
		return "User successfully registered!";
	}
	
	// Method that takes newPassword of type String, returns a String
	public String updatePassword (String newPassword) {
		// if statement to check if currentUser is null
		if (currentUser == null) {
			// Error message is returned to the user
			errorHandler = new ErrorHandler("You must be logged in to update your password!");
			return errorHandler.getMessage();
		}
		
		// if statement to check if newPassword is null or empty
		if (newPassword == null & newPassword.isEmpty()) {
			// Error message is returned to the user
			errorHandler = new ErrorHandler("Password cannot be empty!");
			return errorHandler.getMessage();
		}
		
		// if statement to check if newPassword equals current password
		if (newPassword.equals(currentUser.getPassword())) {
			// Error message is returned to the user
			errorHandler = new ErrorHandler("Old password cannot match new password!");
			return errorHandler.getMessage();
		}
		
		// updates current password with newPassword
		this.userService.updateUserPassword(newPassword);
		return "Password updated!";
	}
	
	// Method that takes membership of type Membership
	public String updateMembershipType (Membership membership) {
		// if statement to check if currentUser is null
		if (currentUser == null) {
			// Error message is returned to the user
			errorHandler = new ErrorHandler("You must be logged in to update your membership!");
			return errorHandler.getMessage();
		}
		
		// if statement to check if membership is null
		if (membership == null) {
			// Error message is returned to the user
			errorHandler = new ErrorHandler("You must select a valid membership type!");
			return errorHandler.getMessage();		
		}
		
		// if statement to check if membership equals old membership
		if (membership.equals(currentUser.getMembership())) {
			// Error message is returned to the user
			errorHandler = new ErrorHandler("Old membership cannot match new membership!");
			return errorHandler.getMessage();
		}
		
		// updates old membership with new membership
		this.userService.updateMembershipType(membership);
		return "Membership updated!";
	}
	
	// Method to get current user, returns User
	public User getCurrentUser() {
		// returns current user
		return this.userService.getCurrentUser();
	}
	
	
}

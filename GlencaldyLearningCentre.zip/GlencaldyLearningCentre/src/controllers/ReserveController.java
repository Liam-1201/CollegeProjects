package controllers;

import java.io.IOException;
import java.util.UUID;

import enums.Membership;
import helpers.ErrorHandler;
import models.Stock;
import models.User;
import services.ReserveService;
import services.StockService;
import services.UserService;

// Author: Liam Irvine
// Class used to control the messages to the user from the reserve service
public class ReserveController {
	// Required variables are made
	private ErrorHandler errorHandler;
	private UserService userService;
	private User currentUser;
	private ReserveService reserveService;
	private StockController stockController;
	
	// Constructor to initialise variables
	public ReserveController (UserService userService, StockService stockService, ReserveService reserveService) throws IOException {
		this.userService = userService;
		this.reserveService = reserveService;
		this.stockController = new StockController(userService, stockService);
		this.currentUser = userService.getCurrentUser();
	}
	
	// Method that takes stockID of type UUID and customerID of type UUID
	public String reserveItem (UUID stockID, UUID customerID) {
		// if statement that checks if currentUser is null
		if (currentUser == null) {
			// Error message is returned to the user
			errorHandler = new ErrorHandler("You must be logged in to reserve an item!");
			return errorHandler.getMessage();
		}
		
		// if statement to check if stockID is null
		if (stockID == null) {
			// Error message is returned to the user
			errorHandler = new ErrorHandler("Request cannot be empty!");
			return errorHandler.getMessage();
		}
		
		// if statement to check if the current user is a casualMember
		if (currentUser.getMembership() == Membership.casualMember) {
			// Error message is returned to the user
			errorHandler = new ErrorHandler("Insufficient privileges!");
			return errorHandler.getMessage();
		}
		
		// foundStock variable is made and value is set to the stockID
		Stock foundStock = this.stockController.getStockItemByID(stockID);
		
		// if statement to check if foundStock is null
		if (foundStock == null) {
			// Error message is returned to the user
			errorHandler = new ErrorHandler("Item with that ID does not exist!");
			return errorHandler.getMessage();
		}
		
		// if statement to check if the current item is already reserved
		if (foundStock.getIsReserved()) {
			// Error message is returned to the user
			errorHandler = new ErrorHandler("That item is already reserved!");
			return errorHandler.getMessage();
		}
		
		// Passes the stockID and customerID to reserveItem and sets isReserved to true
		this.reserveService.reserveItem(stockID, customerID);
		
		return "Item reserved!";
	}
}

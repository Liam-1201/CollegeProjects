package controllers;

import java.util.List;
import java.util.UUID;

import enums.Membership;
import helpers.ErrorHandler;
import helpers.StockMediaTypeHelper;
import models.Stock;
import models.User;
import services.StockService;
import services.UserService;

// Author: Liam Irvine
// Class used to control messages to the user from the Stock service
public class StockController {
	// Required variables are made
	private StockService stockService;
	private UserService userService;
	private ErrorHandler errorHandler;
	private User currentUser;
	
	// Constructor to initialise variables
	public StockController (UserService userService, StockService stockService) {
		this.userService = userService;
		this.stockService = stockService;
		this.currentUser = userService.getCurrentUser();
	}
	
	// Method that takes stockMediaHelper of type StockMediaHelper
	public String createStockItem (StockMediaTypeHelper stockMediaHelper) {
		// if statement to check if stockMediaHelper is null
		if (stockMediaHelper == null) {
			// Error message is returned to the user
			errorHandler = new ErrorHandler("Request cannot be empty!");
			return errorHandler.getMessage();
		}
		
		// stockMediaHelper is passed to createStockItem and item is created
		this.stockService.createStockItem(stockMediaHelper);
		return "Stock successfully created!";
	}
	
	// Method that takes showHiddenItems of type boolean, returns a list of Stock
	public List<Stock> getStockItems (boolean showHiddenItems) {
		// returns a list of Stock
		return this.stockService.getStockItems(showHiddenItems);
	}
	
	// Method to return a list of stock by the stock name given by user
	public List<Stock> getStockByStockName(String stockTitle) {
		return this.stockService.getStockByStockName(stockTitle);
	}
	
	// Method that takes stockID of type UUID, returns a String
	public String makeStockPublic (UUID stockID) {
		// if statement to check if currentUser is null
		if (currentUser == null) {
			// Error message is returned to the user
			errorHandler = new ErrorHandler("You must be logged in!");
			return errorHandler.getMessage();
		}
		
		// if statement to check if the currentUser is NOT a staffMember
		if (currentUser.getMembership() != Membership.staffMember) {
			// Error message is returned to the user
			errorHandler = new ErrorHandler("Insufficient privileges!");
			return errorHandler.getMessage();
		}
		
		// if statement to check if stockID is null
		if (stockID == null) {
			// Error message is returned to the user
			errorHandler = new ErrorHandler("StockID must be provided!");
			return errorHandler.getMessage();
		}
		
		// variable to check if the stock item is public
		boolean isStockPublic = this.stockService.makeStockPublic(stockID);
		
		// if statement to check if isStockPublic is false
		if (!isStockPublic) {
			// Error message is returned to the user
			errorHandler = new ErrorHandler("Item with that ID does not exist!");
			return errorHandler.getMessage();
		}
		return "Success";
	}
	
	// Method that takes stockID of type UUID, returns type Stock
	public Stock getStockItemByID(UUID stockID) {
		// returns the stock item
		return this.stockService.getStockItemByID(stockID);
	}
}

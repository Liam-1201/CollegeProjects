package controllers;

import java.time.LocalDate;
import java.util.UUID;  

import enums.Membership;
import helpers.ErrorHandler;
import models.Borrow;
import models.Stock;
import models.User;
import services.BorrowService;
import services.StockService;
import services.UserService;
// Author: Liam Irvine
// Class used to control messages to the user from the borrow service
public class BorrowController {
	// Required variables are made
	private ErrorHandler errorHandler;
	private User currentUser;
	private BorrowService borrowService;
	private StockController stockController;
	private UserController userController;
	
	// Constructor to initialise variables
	public BorrowController (UserService userService, StockService stockService, BorrowService borrowService) {
		this.borrowService = borrowService;
		this.userController = new UserController(userService);
		this.stockController = new StockController(userService, stockService);
		this.currentUser = userController.getCurrentUser();
	}
	
	// Method that takes stockID and customerID of type UUID, returns a string
		public String borrowStockItem (UUID stockID, UUID customerID) {
			if (userController.getCurrentUser().getMembership() == Membership.casualMember) {
				errorHandler = new ErrorHandler("Insufficient permissions!");
				return errorHandler.getMessage();
			}
			
			// if statement to check if the stockID is null
			if (stockID == null) {
				// Error message is returned to the user
				errorHandler = new ErrorHandler("Request cannot be empty!");
				return errorHandler.getMessage();
			}
			
			// if statement to check if the user is suspended
			if (userController.getCurrentUser().getIsSuspended()) {
				errorHandler = new ErrorHandler("You cannot borrow an item as you are suspended!");
				return errorHandler.getMessage();
			}
			
			// foundStock variable is made and value is set to the stockID
			Stock foundStock = this.stockController.getStockItemByID(stockID);
			
			// if statement to check if the item has already been borrowed
			if (foundStock.getIsBorrowed()) {
				// Error message is returned to the user
				errorHandler = new ErrorHandler("That item has already been borrowed!");
				return errorHandler.getMessage();
			}
			
			// Passes the stockID to borrowStockItem and sets isBorrowed to true
			this.borrowService.borrowStockItem(stockID, customerID, null);
			
			// Confirmation is returned to the user
			return "Item borrowed!";
		}
	
	// Method that takes stockID of type UUID and returnDate of type LocalDate, returns a string
	public String returnStockItem (UUID stockID, LocalDate returnDate) {
		if (userController.getCurrentUser().getMembership() == Membership.casualMember) {
			errorHandler = new ErrorHandler("Insufficient permissions!");
			return errorHandler.getMessage();
		}
		
		// if statement to check if the stockID is null
		if (stockID == null) {
			// Error message is returned to the user
			errorHandler = new ErrorHandler("Request cannot be empty!");
			return errorHandler.getMessage();
		}
		
		// foundStock variable is made and value is set to the stockID
		Stock foundStock = this.stockController.getStockItemByID(stockID);
		
		// Variables declared 
		Borrow borrow = this.borrowService.returnStockItem(stockID); // Price required on return
		Double fine = this.borrowService.applyFine(borrow, returnDate); // Price required + fine on return
		
		// if statement to check if a fine is needed
		if (fine > borrow.getTotalCost()) {
			// Message returned to the user informing them that they must pay a fine
			errorHandler = new ErrorHandler("You are returning an item that has exceeded the borrow end date. You must pay a total cost of " + borrow.getTotalCost().toString() + ".");
			return errorHandler.getMessage();
		}
		
		return "Item successfully returned.";
	}
}

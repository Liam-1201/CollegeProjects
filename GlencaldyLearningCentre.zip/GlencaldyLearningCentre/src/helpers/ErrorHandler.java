package helpers;

// Author: Liam Irvine
// Class used to handle error messages from incorrect entries or insufficient permissions throughout the program.
// Inherits from class Exception
public class ErrorHandler extends Exception{
	private static final long serialVersionUID = 1L;

	// Constructor used to access the errorMessage from within the Exception class.
	public ErrorHandler (String errorMessage) {
		super(errorMessage);
	}
}
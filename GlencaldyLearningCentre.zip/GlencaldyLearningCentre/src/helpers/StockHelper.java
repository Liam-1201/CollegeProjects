package helpers;

import java.util.UUID;

// Author: Liam Irvine
// Class that helps handle stock items
public class StockHelper {
	// Required variables are made
	private UUID stockID;
	private String stockTitle;
	
	// Constructor to initialise variables
	public StockHelper (UUID stockID, String stockTitle) {
		this.stockID = stockID;
		this.stockTitle = stockTitle;
	}
	
	// Getters are made
	public UUID getStockID () {
		return this.stockID;
	}
	
	public String getStockTitle () {
		return this.stockTitle;
	}
}

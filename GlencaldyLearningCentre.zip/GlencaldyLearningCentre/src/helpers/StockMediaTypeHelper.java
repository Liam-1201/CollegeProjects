package helpers;
import models.Books;
import models.CD;
import models.Journal;
import models.Stock;
import models.Video;

// Author: Liam Irvine
// Class used to help access each different type of stock by their traits.
public class StockMediaTypeHelper {
	// Required variables are made
	public Books book;
	public Journal journal;
	public CD cd;
	public Video video;
	public Stock stock;
}

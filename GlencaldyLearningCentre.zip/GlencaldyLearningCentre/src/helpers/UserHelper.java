package helpers;

import java.util.UUID;

// Author: Liam Irvine
// Class used to help get the userID of that user from their username.
public class UserHelper {
	private UUID userID;
	private String username;
	
	// Constructor to initialise variables.
	public UserHelper (UUID userID, String username) {
		this.userID = userID;
		this.username = username;
	}
	
	// Getters for the variables.
	public UUID getUserID () {
		return this.userID;
	}
	
	public String getUsername () {
		return this.username;
	}
}

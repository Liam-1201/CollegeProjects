package helpers;

import java.util.UUID;

import enums.MediaType;
import models.Stock;

// Author: Liam Irvine
// Class used to help assign a user to a specific stock item for reservation, borrow, etc.
// Inherits from class Stock.
public class StockUserHelper extends Stock{
	private static final long serialVersionUID = 1L;
	private String username;
	
	// Constructor to initialise username variable.
	public StockUserHelper(UUID stockID, MediaType mediaType, Double price, boolean isBorrowed, boolean isReserved,
			boolean isPublic, UUID customerID, String title, String publisher, String username) {
		super(stockID, mediaType, price, isBorrowed, isReserved, isPublic, customerID, title, publisher);
		this.username = username;
	}
}

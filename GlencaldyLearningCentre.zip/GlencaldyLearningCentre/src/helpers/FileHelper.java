package helpers;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

// Author: Liam Irvine
// Class used to handle fine inputs and outputs
public class FileHelper {
	// Required variables are made
	private String filePath;
	
	// Constructor to initialise variables
	public FileHelper(String filePath) {
		this.filePath = filePath;
	}
	
	// Method that takes a given List of any type and saves the list to a file
	/*public <T> void saveToFile(List<T> arrayList) {
		try {
			// Creates new objects
			FileOutputStream f = new FileOutputStream(new File(this.filePath), true);
			ObjectOutputStream o = new ObjectOutputStream(f);
			
			// For loop to write each item in the list
			for (T item: arrayList) {
				o.writeObject(item);
			}
			
			// closes the files
			o.close();
			f.close();
		} catch(IOException e) {
			 e.printStackTrace();
		}	
	}	*/
	
	public <T> void saveToFile(ArrayList<T> arrayList) {
		try {
			FileOutputStream file = new FileOutputStream(filePath);
			ObjectOutputStream out = new ObjectOutputStream(file);
			
			out.writeObject(arrayList);
			
			out.close();
			file.close();
			
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
}

package models;
import java.util.UUID;
import enums.MediaType;

// Author: Liam Irvine
// Video class to include video specific traits.
// Inherits from class Stock
public class Video extends Stock{
	private static final long serialVersionUID = 1L;
	private String runningTime;
	private String videoFormat;
	private String genre;
	private String typeOfStorageCase;
	
	// Constructor to initialise Video variables.
	public Video (UUID videoID, MediaType mediaType, Double price, boolean isBorrowed, boolean isReserved,
			boolean isPublic, UUID customerID, String title, String publisher, String runningTime, String videoFormat,
			String genre, String typeOfStorageCase) {
		super(videoID, MediaType.Video, price, isBorrowed, isReserved, isPublic, customerID, title, publisher);
		this.runningTime = runningTime;
		this.videoFormat = videoFormat;
		this.genre = genre;
		this.typeOfStorageCase = typeOfStorageCase;
	}
	
	// Getters for video traits.
	public String getRunningTime() {
		return runningTime;
	}
	
	public String getVideoFormat() {
		return videoFormat;
	}
	
	public String getGenre() {
		return genre;
	}
	
	public String getTypeOfStorageCase() {
		return typeOfStorageCase;
	}
	
	// Setters for video traits.
	public void setRunningTime(String runningTime) {
		this.runningTime = runningTime;
	}
	
	public void setVideoFormat(String videoFormat) {
		this.videoFormat = videoFormat;
	}
	
	public void setGenre(String genre) {
		this.genre = genre;
	}
	
	public void setTypeOfStorageCase(String typeOfStorageCase) {
		this.typeOfStorageCase = typeOfStorageCase;
	}
}

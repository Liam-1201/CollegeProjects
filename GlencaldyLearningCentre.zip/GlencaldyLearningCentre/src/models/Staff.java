package models;

import java.util.UUID;

import enums.Membership;

// Author: Liam Irvine
// Staff class to include staff specific traits.
// Inherits from class User.
public class Staff extends User{
	private static final long serialVersionUID = 1L;
	private String email;
	private int phoneExtension;
	
	// Constructor to initialise Staff variables.
	public Staff(UUID staffID, String email, int phoneExtension, Membership membership, String firstName, String lastName, String username, String password, boolean isEnrolled, boolean isSuspended) {
		super(staffID, firstName, lastName, Membership.staffMember, username, password, isEnrolled, isSuspended, password, phoneExtension);
		this.email = email;
		this.phoneExtension = phoneExtension;
	}
}

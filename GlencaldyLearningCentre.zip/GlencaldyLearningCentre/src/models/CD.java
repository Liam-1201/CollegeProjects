package models;
import java.util.UUID;
import enums.MediaType;

// Author: Liam Irvine
// CD class to include CD specific traits.
// Inherits from Stock class
public class CD extends Stock{
	private static final long serialVersionUID = 1L;
	private String runningTime;
	private String cdType;
	private int noOfTracks;
	private String artist;
	private String typeOfStorageCase;
	
	// Constructor to initialise CD variables.
	public CD(UUID cdID, MediaType mediaType, Double price, boolean isBorrowed, boolean isReserved,
			boolean isPublic, UUID customerID, String title, String publisher, String runningTime, String cdType,
			int noOfTracks, String artist, String typeOfStorageCase) {
		super(cdID, MediaType.CD, price, isBorrowed, isReserved, isPublic, customerID, title, publisher);
		this.runningTime = runningTime;
		this.cdType = cdType;
		this.noOfTracks = noOfTracks;
		this.artist = artist;
		this.typeOfStorageCase = typeOfStorageCase;
	}
	
	// Getters for CD traits
	public String getRunningTime() {
		return runningTime;
	}
	
	public String getCdType() {
		return cdType;
	}
	
	public int getNoOfTracks() {
		return noOfTracks;
	}
	
	public String getArtist() {
		return artist;
	}
	
	public String getTypeOfStorageCase() {
		return typeOfStorageCase;
	}
	
	// Setters for CD traits
	public void setRunningTime(String runningTime) {
		this.runningTime = runningTime;
	}
	
	public void setCdType(String cdType) {
		this.cdType = cdType;
	}
	
	public void setNoOfTracks(int noOfTracks) {
		this.noOfTracks = noOfTracks;
	}
	
	public void setArtist(String artist) {
		this.artist = artist;
	}
	
	public void setTypeOfStorageCase(String typeOfStorageCase) {
		this.typeOfStorageCase = typeOfStorageCase;
	}
}

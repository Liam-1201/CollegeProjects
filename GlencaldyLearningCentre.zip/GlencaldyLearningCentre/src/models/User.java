package models;
import java.io.*;
import java.time.LocalDate;
import java.util.UUID;
import enums.Membership;

// Author: Liam Irvine
// User class to include all generic traits for a user.
public class User implements Serializable{
	private static final long serialVersionUID = 1L;
	private UUID userID;
	private String firstName;
	private String lastName;
	private String address1;
	private String town;
	private String postcode;
	private String telephoneNo;
	private LocalDate dateOfBirth;
	private Membership membership;
	private String username;
	private String password;
	private boolean isEnrolled;
	private boolean isSuspended;
	private String email;
	private int phoneExtension;
	
	// Constructor to initialise required traits for non staff members.
	public User (UUID userID, String firstName, String lastName, Membership membership, String username, String password, boolean isEnrolled,
			boolean isSuspended, String email, int phoneExtension) {
		this.userID = userID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.membership = membership;
		this.username = username;
		this.password = password;
		this.isEnrolled = isEnrolled;
		this.isSuspended = isSuspended;
		this.email = email;
		this.phoneExtension = phoneExtension;
	}
	
	// Constructor to initialise required Staff traits.
	public User (UUID userID, String firstName, String lastName, String address1, String town, String postcode, String telephoneNo,
			LocalDate dateOfBirth, Membership membership, String username, String password, boolean isEnrolled, boolean isSuspended) {
		this.userID = userID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.address1 = address1;
		this.town = town;
		this.postcode = postcode;
		this.telephoneNo = telephoneNo;
		this.dateOfBirth = dateOfBirth;
		this.membership = membership;
		this.username = username;
		this.password = password;
		this.isEnrolled = isEnrolled;
		this.isSuspended = isSuspended;
	}
	
	// Getters for each trait.
	public String getUsername() {
		return this.username;
	}
	
	public String getPassword() {
		return this.password;
	}
	
	public UUID getUserID() {
		return this.userID;
	}
	
	public String getFirstName() {
		return this.firstName;
	}
	
	public String getLastName() {
		return this.lastName;
	}
	
	public String getAddress() {
		return this.address1;
	}
	
	public String getTown() {
		return this.town;
	}
	
	public String getPostcode() {
		return this.postcode;
	}
	
	public String getTelephoneNo() {
		return this.telephoneNo;
	}
	
	public LocalDate getDateOfBirth() {
		return this.dateOfBirth;
	}
	
	public Membership getMembership() {
		return this.membership;
	}
	
	public boolean getIsEnrolled() {
		return this.isEnrolled;
	}
	
	public boolean getIsSuspended() {
		return this.isSuspended;
	}
	
	// Setters for required traits.
	public void setPassword(String newPassword) {
		this.password = newPassword;
	}

	public void setMembership(Membership membership) {
		this.membership = membership;
	}
	
	
	@Override
	public String toString() {
		return "User ID: " + this.getUserID() + ", First Name: " + this.getFirstName() +
				", Last Name: " + this.getLastName() + ", Membership: " + this.getMembership() +
				"\nUsername: " + this.getUsername() + ", Password: " + this.getPassword() +
				", Enrolled?: " + this.getIsEnrolled() + ", Suspended?: " + this.getIsSuspended() +
				", Address 1: " + this.getAddress() + ", Town: " + this.getTown() + "\n" + "---- \n";
	}
}

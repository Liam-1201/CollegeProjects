package models;
import java.time.LocalDate;
import java.util.UUID;

import enums.MediaType;

// Author: Liam Irvine
// Journal class to include Journal specific traits.
// Inherits from Stock class
public class Journal extends Stock{
	private static final long serialVersionUID = 1L;
	private String ISSN;
	private String issueNumber;
	private LocalDate dateOfIssue;
	private String subjectArea;
	private int noOfPages;
	
	// Constructor to initialise Journal variables
	public Journal(UUID journalID, MediaType mediaType, Double price, boolean isBorrowed, boolean isReserved,
			boolean isPublic, UUID customerID, String title, String publisher, String ISSN, String issueNumber, LocalDate dateOfIssue,
			String subjectArea, int noOfPages) {
		super(journalID, MediaType.Journal, price, isBorrowed, isReserved, isPublic, customerID, title, publisher);
		this.ISSN = ISSN;
		this.issueNumber = issueNumber;
		this.dateOfIssue = dateOfIssue;
		this.subjectArea = subjectArea;
		this.noOfPages = noOfPages;
	}
	
	// Getters for each trait.
	public String getISSN() {
		return ISSN;
	}
	
	public String getIssueNumber() {
		return issueNumber;
	}
	
	public LocalDate getDateOfIssue() {
		return dateOfIssue;
	}
	
	public String getSubjectArea() {
		return subjectArea;
	}
	
	public int getNoOfPages() {
		return noOfPages;
	}
	
	// Setters for each trait.
	public void setISSN(String iSSN) {
		ISSN = iSSN;
	}
	
	public void setIssueNumber(String issueNumber) {
		this.issueNumber = issueNumber;
	}
	
	public void setDateOfIssue(LocalDate dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}
	
	public void setSubjectArea(String subjectArea) {
		this.subjectArea = subjectArea;
	}
	
	public void setNoOfPages(int noOfPages) {
		this.noOfPages = noOfPages;
	}
}

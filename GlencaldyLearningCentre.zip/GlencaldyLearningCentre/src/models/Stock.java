package models;
import java.io.Serializable;
import java.util.UUID;
import enums.MediaType;

// Author: Liam Irvine
// Stock class for all generic Stock traits.
public class Stock implements Serializable{
	private static final long serialVersionUID = 1L;
	private UUID stockID;
	private MediaType mediaType;
	private Double price;
	private boolean isBorrowed;
	private boolean isReserved;
	private boolean isPublic;
	private UUID customerID;
	private String title;
	private String publisher;
	
	// Constructor to initialise all generic Stock traits.
	public Stock (UUID stockID, MediaType mediaType, Double price, boolean isBorrowed, boolean isReserved, boolean isPublic, UUID customerID, String title, String publisher) {
		this.stockID = stockID;
		this.mediaType = mediaType;
		this.price = price;
		this.isBorrowed = isBorrowed;
		this.isReserved = isReserved;
		this.isPublic = isPublic;
		this.customerID = customerID;
		this.title = title;
		this.publisher = publisher;
	}
	
	// Getters for the traits.
	public UUID getStockID() {
		return this.stockID;
	}
	
	public MediaType getMediaType() {
		return this.mediaType;
	}
	
	public Double getPrice() {
		return this.price;
	}
	
	public boolean getIsBorrowed() {
		return this.isBorrowed;
	}
	
	public boolean getIsReserved() {
		return this.isReserved;
	}
	
	public boolean getIsPublic() {
		return this.isPublic;
	}
	
	public UUID getCustomerID() {
		return this.customerID;
	}
	
	public String getTitle() {
		return title;
	}
	
	public String getPublisher() {
		return publisher;
	}
	
	// Setters for the traits.
	public void setMediaType(MediaType mediaType) {
		this.mediaType = mediaType;
	}
	
	public void setPrice(Double price) {
		this.price = price;
	}
	
	public void setIsBorrowed(boolean isBorrowed) {
		this.isBorrowed = isBorrowed;
	}
	
	public void setIsReserved(boolean isReserved) {
		this.isReserved = isReserved;
	}
	
	public void setIsPublic(boolean isPublic) {
		this.isPublic = isPublic;
	}
	
	public void setCustomerID(UUID customerID) {
		this.customerID = customerID;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	
	@Override
	public String toString() {
		return "Stock ID: " + this.getStockID() + ", Media Type: " + this.getMediaType() +
				", Price: " + this.getPrice() + ", Title: " + this.getTitle() + ", Publisher: " + this.getPublisher() + "\n";
	}
	
}

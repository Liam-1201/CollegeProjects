package models;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.UUID;

// Author: Liam Irvine
// Borrow class used for defining each trait required for borrowing.
public class Borrow implements Serializable{
	private static final long serialVersionUID = 1L;
	private UUID borrowID;
	private String stockTitle;
	private LocalDate borrowStart;
	private LocalDate borrowEnd;
	private Double totalCost;
	private Double fine;
	private UUID customerID;
	private UUID stockID;
	private boolean isFinePayed;
	private boolean isReturned;
	private String username;
	
	// Constructor to initialise variables.
	public Borrow (UUID borrowID, String stockTitle, LocalDate borrowStart, LocalDate borrowEnd, Double totalCost, 
			Double fine, UUID customerID, UUID stockID, boolean isFinePayed, boolean isReturned, String username) {
		this.borrowID = borrowID;
		this.stockTitle = stockTitle;
		this.borrowStart = borrowStart;
		this.borrowEnd = borrowEnd;
		this.totalCost = totalCost;
		this.fine = fine;
		this.customerID = customerID;
		this.stockID = stockID;
		this.isFinePayed = isFinePayed;
		this.isReturned = isReturned;
		this.username = username;
	}
	
	// Getters for the required traits.
	public UUID getStockID() {
		return this.stockID;
	}
	
	public String getStockTitle() {
		return this.stockTitle;
	}
	
	public LocalDate getBorrowStart() {
		return this.borrowStart;
	}
	
	public LocalDate getBorrowEndDate() {
		return this.borrowEnd;
	}
	
	public Double getTotalCost() {
		return this.totalCost;
	}
	
	public boolean getIsReturned() {
		return this.isReturned;
	}
	
	public UUID getCustomerID() {
		return this.customerID;
	}
	
	public String getUsername() {
		return this.username;
	}
	
	public void setFine(Double fine) {
		this.fine = fine;
	}
	
	public void setIsReturned(boolean isReturned) {
		this.isReturned = isReturned;
	}
	
	public void setIsFinePayed(boolean isFinePayed) {
		this.isFinePayed = isFinePayed;
	}
	
	@Override
	public String toString() {
		return "Username: " + this.getUsername() + ", Stock ID: " + this.getStockID() + ", Title: " + this.getStockTitle() +
				", Price: " + this.getTotalCost() + "\nBorrow Start: " + 
				this.getBorrowStart() + ", Borrow End: " + this.getBorrowEndDate() + "\n";
	}
}
package models;
import java.util.UUID;
import enums.MediaType;

// Author: Liam Irvine
// Book class to include Book specific traits.
// Inherits from Stock class.
public class Books extends Stock{
	private static final long serialVersionUID = 1L;
	private String ISBN;
	private String author;
	private String subjectArea;
	private int noOfPages;
	
	// Constructor to initialise Book variables.
	public Books (UUID bookID, MediaType mediaType, Double price, boolean isBorrowed, boolean isReserved, boolean isPublic, UUID customerID,
			String title, String publisher, String ISBN, String author, String subjectArea, int noOfPages) {
		super(bookID, MediaType.Book, price, isBorrowed, isReserved, isPublic, customerID, title, publisher);
		this.ISBN = ISBN;
		this.author = author;
		this.subjectArea = subjectArea;
		this.noOfPages = noOfPages;
	}
	
	// Getters for each trait.
	public String getISBN() {
		return ISBN;
	}
	
	public String getAuthor() {
		return author;
	}
	
	public String getSubjectArea() {
		return subjectArea;
	}
	
	public int getNoOfPages() {
		return noOfPages;
	}
	
	// Setters for each trait
	public void setISBN(String iSBN) {
		ISBN = iSBN;
	}
	
	public void setAuthor(String author) {
		this.author = author;
	}
	
	public void setSubjectArea(String subjectArea) {
		this.subjectArea = subjectArea;
	}
	
	public void setNoOfPages(int noOfPages) {
		this.noOfPages = noOfPages;
	}
}

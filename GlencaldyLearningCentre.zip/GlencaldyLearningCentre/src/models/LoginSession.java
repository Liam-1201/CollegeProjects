package models;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.UUID;

// Author: Liam Irvine
// LoginSession class to include requirements for storing the login session.
public class LoginSession implements Serializable{
	private static final long serialVersionUID = 1L;
	private LocalDate loginDate;
	private LocalDate logoutDate;
	private UUID computerID;
	private UUID userID;
	private String username;
	
	// Constructor to initialise the LoginSession variables.
	public LoginSession(LocalDate loginDate, LocalDate logoutDate, UUID computerID, UUID userID, String username) {
		this.loginDate = loginDate;
		this.logoutDate = logoutDate;
		this.computerID = computerID;
		this.userID = userID;
		this.username = username;
	}
	
	// Getter for the userID
	
	public LocalDate getLoginDate() {
		return loginDate;
	}
	
	public LocalDate getLogoutDate() {
		return logoutDate;
	}
	
	public UUID getComputerID() {
		return computerID;
	}
	
	public UUID getUserID() {
		return userID;
	}
	
	public String getUsername() {
		return username;
	}
	
	// Setter for the logoutDate
	public void setLogoutDate(LocalDate logoutDate) {
		this.logoutDate = logoutDate;
	}
	
	@Override
	public String toString() {
		return "User ID: " + this.getUserID() + ", Username: " + this.getUsername() + "\n, Computer ID: " + this.getComputerID() + 
				"Login Date: " + this.getLoginDate() + ", Logout Date: " + this.getLogoutDate() + "\n" + "-------------------------\n";
				
	}
}
